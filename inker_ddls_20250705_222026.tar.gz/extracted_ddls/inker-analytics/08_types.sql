CREATE TYPE public.content_metrics_content_type_enum AS ENUM ('stencil', 'work', 'artist_profile');
