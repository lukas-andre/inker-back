CREATE SEQUENCE public."query-result-cache_id_seq";
