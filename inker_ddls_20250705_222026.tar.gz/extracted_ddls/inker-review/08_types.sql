CREATE TYPE public.reaction_type_enum AS ENUM ('like', 'dislike', 'off');
