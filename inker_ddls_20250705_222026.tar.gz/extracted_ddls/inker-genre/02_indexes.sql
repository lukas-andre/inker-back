CREATE INDEX "IDX_3a24e6737df006b9aa30b76cca" ON public.genrer CREATE INDEX "IDX_3a24e6737df006b9aa30b76cca" ON genrer USING btree (name);
