--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.2 (Debian 16.2-1.pgdg110+2)
-- Dumped by pg_dump version 16.2 (Debian 16.2-1.pgdg110+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "inker-artist";
--
-- Name: inker-artist; Type: DATABASE; Schema: -; Owner: root
--

CREATE DATABASE "inker-artist" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE "inker-artist" OWNER TO root;

\connect -reuse-previous=on "dbname='inker-artist'"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: service_name; Type: TYPE; Schema: public; Owner: root
--

CREATE TYPE public.service_name AS ENUM (
    'Barber',
    'Tattoo Artist'
);


ALTER TYPE public.service_name OWNER TO root;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: artist; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.artist (
    id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    user_id integer NOT NULL,
    username character varying NOT NULL,
    first_name character varying NOT NULL,
    last_name character varying NOT NULL,
    short_description character varying,
    profile_thumbnail character varying,
    rating double precision DEFAULT '0'::double precision NOT NULL,
    studio_photo character varying,
    deleted_at timestamp without time zone,
    contact_id integer,
    "profileThumbnailVersion" integer DEFAULT 0 NOT NULL,
    "studioPhotoVersion" integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.artist OWNER TO root;

--
-- Name: artist_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.artist_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.artist_id_seq OWNER TO root;

--
-- Name: artist_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.artist_id_seq OWNED BY public.artist.id;


--
-- Name: artist_services_service; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.artist_services_service (
    "artistId" integer NOT NULL,
    "serviceId" integer NOT NULL
);


ALTER TABLE public.artist_services_service OWNER TO root;

--
-- Name: contact; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.contact (
    id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    email character varying NOT NULL,
    phone character varying NOT NULL,
    phone_dial_code character varying NOT NULL,
    phone_country_iso_code character varying NOT NULL
);


ALTER TABLE public.contact OWNER TO root;

--
-- Name: contact_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.contact_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.contact_id_seq OWNER TO root;

--
-- Name: contact_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.contact_id_seq OWNED BY public.contact.id;


--
-- Name: service; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.service (
    id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    name public.service_name NOT NULL,
    description character varying
);


ALTER TABLE public.service OWNER TO root;

--
-- Name: service_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.service_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.service_id_seq OWNER TO root;

--
-- Name: service_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.service_id_seq OWNED BY public.service.id;


--
-- Name: artist id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.artist ALTER COLUMN id SET DEFAULT nextval('public.artist_id_seq'::regclass);


--
-- Name: contact id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.contact ALTER COLUMN id SET DEFAULT nextval('public.contact_id_seq'::regclass);


--
-- Name: service id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.service ALTER COLUMN id SET DEFAULT nextval('public.service_id_seq'::regclass);


--
-- Data for Name: artist; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.artist (id, created_at, updated_at, user_id, username, first_name, last_name, short_description, profile_thumbnail, rating, studio_photo, deleted_at, contact_id, "profileThumbnailVersion", "studioPhotoVersion") FROM stdin;
\.
COPY public.artist (id, created_at, updated_at, user_id, username, first_name, last_name, short_description, profile_thumbnail, rating, studio_photo, deleted_at, contact_id, "profileThumbnailVersion", "studioPhotoVersion") FROM '$$PATH$$/3369.dat';

--
-- Data for Name: artist_services_service; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.artist_services_service ("artistId", "serviceId") FROM stdin;
\.
COPY public.artist_services_service ("artistId", "serviceId") FROM '$$PATH$$/3375.dat';

--
-- Data for Name: contact; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.contact (id, created_at, updated_at, email, phone, phone_dial_code, phone_country_iso_code) FROM stdin;
\.
COPY public.contact (id, created_at, updated_at, email, phone, phone_dial_code, phone_country_iso_code) FROM '$$PATH$$/3371.dat';

--
-- Data for Name: service; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.service (id, created_at, updated_at, name, description) FROM stdin;
\.
COPY public.service (id, created_at, updated_at, name, description) FROM '$$PATH$$/3374.dat';

--
-- Name: artist_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.artist_id_seq', 8, true);


--
-- Name: contact_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.contact_id_seq', 8, true);


--
-- Name: service_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.service_id_seq', 2, true);


--
-- Name: contact PK_2cbbe00f59ab6b3bb5b8d19f989; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.contact
    ADD CONSTRAINT "PK_2cbbe00f59ab6b3bb5b8d19f989" PRIMARY KEY (id);


--
-- Name: artist PK_55b76e71568b5db4d01d3e394ed; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.artist
    ADD CONSTRAINT "PK_55b76e71568b5db4d01d3e394ed" PRIMARY KEY (id);


--
-- Name: service PK_85a21558c006647cd76fdce044b; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.service
    ADD CONSTRAINT "PK_85a21558c006647cd76fdce044b" PRIMARY KEY (id);


--
-- Name: artist_services_service PK_f00052bfc04552724888fbba399; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.artist_services_service
    ADD CONSTRAINT "PK_f00052bfc04552724888fbba399" PRIMARY KEY ("artistId", "serviceId");


--
-- Name: artist REL_292e15f38dd57107d4ea27ea17; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.artist
    ADD CONSTRAINT "REL_292e15f38dd57107d4ea27ea17" UNIQUE (contact_id);


--
-- Name: service unique_service_name; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.service
    ADD CONSTRAINT unique_service_name UNIQUE (name);


--
-- Name: IDX_148af0166f8adf533482846777; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_148af0166f8adf533482846777" ON public.artist_services_service USING btree ("artistId");


--
-- Name: IDX_83c59c479d292f6a03ad842b5a; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_83c59c479d292f6a03ad842b5a" ON public.artist_services_service USING btree ("serviceId");


--
-- Name: artist_services_service FK_148af0166f8adf533482846777d; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.artist_services_service
    ADD CONSTRAINT "FK_148af0166f8adf533482846777d" FOREIGN KEY ("artistId") REFERENCES public.artist(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: artist FK_292e15f38dd57107d4ea27ea171; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.artist
    ADD CONSTRAINT "FK_292e15f38dd57107d4ea27ea171" FOREIGN KEY (contact_id) REFERENCES public.contact(id);


--
-- Name: artist_services_service FK_83c59c479d292f6a03ad842b5a0; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.artist_services_service
    ADD CONSTRAINT "FK_83c59c479d292f6a03ad842b5a0" FOREIGN KEY ("serviceId") REFERENCES public.service(id);


--
-- PostgreSQL database dump complete
--

