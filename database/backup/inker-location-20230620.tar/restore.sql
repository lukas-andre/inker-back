--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.1 (Debian 15.1-1.pgdg110+1)
-- Dumped by pg_dump version 15.1 (Debian 15.1-1.pgdg110+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "inker-location";
--
-- Name: inker-location; Type: DATABASE; Schema: -; Owner: root
--

CREATE DATABASE "inker-location" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE "inker-location" OWNER TO root;

\connect -reuse-previous=on "dbname='inker-location'"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: postgis; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis WITH SCHEMA public;


--
-- Name: EXTENSION postgis; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION postgis IS 'PostGIS geometry and geography spatial types and functions';


--
-- Name: AddressType; Type: TYPE; Schema: public; Owner: root
--

CREATE TYPE public."AddressType" AS ENUM (
    'HOME',
    'DEPARTMENT',
    'STUDIO',
    'OFFICE'
);


ALTER TYPE public."AddressType" OWNER TO root;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: artist_location; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.artist_location (
    id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    address1 character varying(100) NOT NULL,
    short_address1 character varying(100),
    address2 character varying(50) NOT NULL,
    address3 character varying(50),
    address_type public."AddressType" DEFAULT 'HOME'::public."AddressType" NOT NULL,
    state character varying(100),
    city character varying(100),
    country character varying(20),
    formatted_address character varying(255),
    lat double precision NOT NULL,
    lng double precision NOT NULL,
    viewport jsonb,
    location public.geography(Point,4326),
    artist_id integer,
    name character varying,
    profile_thumbnail character varying,
    google_place_id character varying
);


ALTER TABLE public.artist_location OWNER TO root;

--
-- Name: artist_location_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.artist_location_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.artist_location_id_seq OWNER TO root;

--
-- Name: artist_location_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.artist_location_id_seq OWNED BY public.artist_location.id;


--
-- Name: event_location; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.event_location (
    id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    address1 character varying(100) NOT NULL,
    short_address1 character varying(100),
    address2 character varying(50) NOT NULL,
    address3 character varying(50),
    address_type public."AddressType" DEFAULT 'HOME'::public."AddressType" NOT NULL,
    state character varying(100),
    city character varying(100),
    country character varying(20),
    formatted_address character varying(255),
    lat double precision NOT NULL,
    lng double precision NOT NULL,
    viewport jsonb,
    location public.geography(Point,4326)
);


ALTER TABLE public.event_location OWNER TO root;

--
-- Name: event_location_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.event_location_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.event_location_id_seq OWNER TO root;

--
-- Name: event_location_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.event_location_id_seq OWNED BY public.event_location.id;


--
-- Name: artist_location id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.artist_location ALTER COLUMN id SET DEFAULT nextval('public.artist_location_id_seq'::regclass);


--
-- Name: event_location id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.event_location ALTER COLUMN id SET DEFAULT nextval('public.event_location_id_seq'::regclass);


--
-- Data for Name: artist_location; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.artist_location (id, created_at, updated_at, address1, short_address1, address2, address3, address_type, state, city, country, formatted_address, lat, lng, viewport, location, artist_id, name, profile_thumbnail, google_place_id) FROM stdin;
\.
COPY public.artist_location (id, created_at, updated_at, address1, short_address1, address2, address3, address_type, state, city, country, formatted_address, lat, lng, viewport, location, artist_id, name, profile_thumbnail, google_place_id) FROM '$$PATH$$/4243.dat';

--
-- Data for Name: event_location; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.event_location (id, created_at, updated_at, address1, short_address1, address2, address3, address_type, state, city, country, formatted_address, lat, lng, viewport, location) FROM stdin;
\.
COPY public.event_location (id, created_at, updated_at, address1, short_address1, address2, address3, address_type, state, city, country, formatted_address, lat, lng, viewport, location) FROM '$$PATH$$/4245.dat';

--
-- Data for Name: spatial_ref_sys; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.spatial_ref_sys (srid, auth_name, auth_srid, srtext, proj4text) FROM stdin;
\.
COPY public.spatial_ref_sys (srid, auth_name, auth_srid, srtext, proj4text) FROM '$$PATH$$/4076.dat';

--
-- Name: artist_location_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.artist_location_id_seq', 8, true);


--
-- Name: event_location_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.event_location_id_seq', 1, false);


--
-- Name: artist_location PK_86c4d78b72729fe4f03e468ef55; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.artist_location
    ADD CONSTRAINT "PK_86c4d78b72729fe4f03e468ef55" PRIMARY KEY (id);


--
-- Name: event_location PK_ff5c43e186f7faf15a975004d76; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.event_location
    ADD CONSTRAINT "PK_ff5c43e186f7faf15a975004d76" PRIMARY KEY (id);


--
-- Name: IDX_1ce699acff5d40d1b7ce70b1fc; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_1ce699acff5d40d1b7ce70b1fc" ON public.artist_location USING gist (location);


--
-- Name: IDX_32b296abf35bf4c43f52239ba5; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_32b296abf35bf4c43f52239ba5" ON public.event_location USING gist (location);


--
-- Name: IDX_43b8bd2d87ace87ddad31443c4; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_43b8bd2d87ace87ddad31443c4" ON public.artist_location USING btree (artist_id);


--
-- PostgreSQL database dump complete
--

