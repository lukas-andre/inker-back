--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.2 (Debian 16.2-1.pgdg110+2)
-- Dumped by pg_dump version 16.2 (Debian 16.2-1.pgdg110+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "inker-follow";
--
-- Name: inker-follow; Type: DATABASE; Schema: -; Owner: root
--

CREATE DATABASE "inker-follow" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE "inker-follow" OWNER TO root;

\connect -reuse-previous=on "dbname='inker-follow'"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: followed; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.followed (
    id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    user_followed_id integer NOT NULL,
    user_id integer NOT NULL,
    user_type_id integer NOT NULL,
    user_type character varying NOT NULL,
    username character varying NOT NULL,
    fullname character varying NOT NULL,
    profile_thumbnail character varying
);


ALTER TABLE public.followed OWNER TO root;

--
-- Name: followed_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.followed_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.followed_id_seq OWNER TO root;

--
-- Name: followed_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.followed_id_seq OWNED BY public.followed.id;


--
-- Name: following; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.following (
    id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    user_following_id integer NOT NULL,
    user_id integer NOT NULL,
    user_type_id integer NOT NULL,
    user_type character varying NOT NULL,
    username character varying NOT NULL,
    fullname character varying NOT NULL,
    profile_thumbnail character varying
);


ALTER TABLE public.following OWNER TO root;

--
-- Name: following_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.following_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.following_id_seq OWNER TO root;

--
-- Name: following_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.following_id_seq OWNED BY public.following.id;


--
-- Name: followed id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.followed ALTER COLUMN id SET DEFAULT nextval('public.followed_id_seq'::regclass);


--
-- Name: following id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.following ALTER COLUMN id SET DEFAULT nextval('public.following_id_seq'::regclass);


--
-- Data for Name: followed; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.followed (id, created_at, updated_at, user_followed_id, user_id, user_type_id, user_type, username, fullname, profile_thumbnail) FROM stdin;
\.
COPY public.followed (id, created_at, updated_at, user_followed_id, user_id, user_type_id, user_type, username, fullname, profile_thumbnail) FROM '$$PATH$$/3344.dat';

--
-- Data for Name: following; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.following (id, created_at, updated_at, user_following_id, user_id, user_type_id, user_type, username, fullname, profile_thumbnail) FROM stdin;
\.
COPY public.following (id, created_at, updated_at, user_following_id, user_id, user_type_id, user_type, username, fullname, profile_thumbnail) FROM '$$PATH$$/3346.dat';

--
-- Name: followed_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.followed_id_seq', 3, true);


--
-- Name: following_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.following_id_seq', 3, true);


--
-- Name: followed PK_88316014cdc34a15b9a19772c5f; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.followed
    ADD CONSTRAINT "PK_88316014cdc34a15b9a19772c5f" PRIMARY KEY (id);


--
-- Name: following PK_c76c6e044bdf76ecf8bfb82a645; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.following
    ADD CONSTRAINT "PK_c76c6e044bdf76ecf8bfb82a645" PRIMARY KEY (id);


--
-- Name: IDX_0cd95f68af8a5715869acb53ff; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_0cd95f68af8a5715869acb53ff" ON public.followed USING btree (user_followed_id);


--
-- Name: IDX_3ab90b492b1f2c3d8b8f61adbd; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_3ab90b492b1f2c3d8b8f61adbd" ON public.followed USING btree (user_id);


--
-- Name: IDX_4a5bd9db5bd73571f8c4571771; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_4a5bd9db5bd73571f8c4571771" ON public.following USING btree (user_id);


--
-- Name: IDX_70994ee485be5c9afd8fa864bb; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_70994ee485be5c9afd8fa864bb" ON public.following USING btree (user_following_id);


--
-- Name: IDX_d2374b9535a0e063e8e442dec2; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_d2374b9535a0e063e8e442dec2" ON public.following USING btree (user_type_id);


--
-- Name: IDX_ea71d55e5f089a426913df2bd8; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_ea71d55e5f089a426913df2bd8" ON public.followed USING btree (user_type_id);


--
-- PostgreSQL database dump complete
--

