--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.1 (Debian 15.1-1.pgdg110+1)
-- Dumped by pg_dump version 15.1 (Debian 15.1-1.pgdg110+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "inker-post";
--
-- Name: inker-post; Type: DATABASE; Schema: -; Owner: root
--

CREATE DATABASE "inker-post" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE "inker-post" OWNER TO root;

\connect -reuse-previous=on "dbname='inker-post'"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: comment; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.comment (
    id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    content character varying NOT NULL,
    location character varying,
    user_id integer NOT NULL,
    user_type_id integer NOT NULL,
    user_type character varying NOT NULL,
    parent_type character varying NOT NULL,
    parent_id integer,
    username character varying NOT NULL,
    profile_thumbnail character varying,
    deleted_at timestamp without time zone
);


ALTER TABLE public.comment OWNER TO root;

--
-- Name: comment_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.comment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.comment_id_seq OWNER TO root;

--
-- Name: comment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.comment_id_seq OWNED BY public.comment.id;


--
-- Name: post; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.post (
    id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    content character varying NOT NULL,
    location character varying,
    user_id integer NOT NULL,
    user_type_id integer NOT NULL,
    user_type character varying NOT NULL,
    username character varying NOT NULL,
    profile_thumbnail character varying,
    multimedia jsonb,
    tags jsonb,
    genres jsonb,
    hidden boolean DEFAULT false NOT NULL,
    deleted_at timestamp without time zone
);


ALTER TABLE public.post OWNER TO root;

--
-- Name: post_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.post_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.post_id_seq OWNER TO root;

--
-- Name: post_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.post_id_seq OWNED BY public.post.id;


--
-- Name: comment id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.comment ALTER COLUMN id SET DEFAULT nextval('public.comment_id_seq'::regclass);


--
-- Name: post id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.post ALTER COLUMN id SET DEFAULT nextval('public.post_id_seq'::regclass);


--
-- Data for Name: comment; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.comment (id, created_at, updated_at, content, location, user_id, user_type_id, user_type, parent_type, parent_id, username, profile_thumbnail, deleted_at) FROM stdin;
\.
COPY public.comment (id, created_at, updated_at, content, location, user_id, user_type_id, user_type, parent_type, parent_id, username, profile_thumbnail, deleted_at) FROM '$$PATH$$/3345.dat';

--
-- Data for Name: post; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.post (id, created_at, updated_at, content, location, user_id, user_type_id, user_type, username, profile_thumbnail, multimedia, tags, genres, hidden, deleted_at) FROM stdin;
\.
COPY public.post (id, created_at, updated_at, content, location, user_id, user_type_id, user_type, username, profile_thumbnail, multimedia, tags, genres, hidden, deleted_at) FROM '$$PATH$$/3347.dat';

--
-- Name: comment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.comment_id_seq', 1, false);


--
-- Name: post_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.post_id_seq', 1, false);


--
-- Name: comment PK_0b0e4bbc8415ec426f87f3a88e2; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.comment
    ADD CONSTRAINT "PK_0b0e4bbc8415ec426f87f3a88e2" PRIMARY KEY (id);


--
-- Name: post PK_be5fda3aac270b134ff9c21cdee; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.post
    ADD CONSTRAINT "PK_be5fda3aac270b134ff9c21cdee" PRIMARY KEY (id);


--
-- Name: IDX_06786c179131975fef5fd26bfe; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_06786c179131975fef5fd26bfe" ON public.comment USING btree (location);


--
-- Name: IDX_3dd966611c859e2bb898763f4a; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_3dd966611c859e2bb898763f4a" ON public.post USING btree (location);


--
-- Name: IDX_52378a74ae3724bcab44036645; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_52378a74ae3724bcab44036645" ON public.post USING btree (user_id);


--
-- Name: IDX_62ba03774e466effeeb171af50; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_62ba03774e466effeeb171af50" ON public.post USING btree (user_type);


--
-- Name: IDX_6f2e185b854c47a5f8dfae741a; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_6f2e185b854c47a5f8dfae741a" ON public.post USING btree (user_type_id);


--
-- Name: IDX_7b65538426c45387905f0939a2; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_7b65538426c45387905f0939a2" ON public.comment USING btree (parent_type);


--
-- Name: IDX_8bd8d0985c0d077c8129fb4a20; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_8bd8d0985c0d077c8129fb4a20" ON public.comment USING btree (parent_id);


--
-- Name: IDX_bbfe153fa60aa06483ed35ff4a; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_bbfe153fa60aa06483ed35ff4a" ON public.comment USING btree (user_id);


--
-- Name: IDX_c5df8f9e8d8c44b3c3ddbdee28; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_c5df8f9e8d8c44b3c3ddbdee28" ON public.comment USING btree (user_type_id);


--
-- Name: IDX_f772ca433426f5104d3119ddd3; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_f772ca433426f5104d3119ddd3" ON public.comment USING btree (user_type);


--
-- PostgreSQL database dump complete
--

