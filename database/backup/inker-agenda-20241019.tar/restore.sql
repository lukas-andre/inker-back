--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.2 (Debian 16.2-1.pgdg110+2)
-- Dumped by pg_dump version 16.2 (Debian 16.2-1.pgdg110+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "inker-agenda";
--
-- Name: inker-agenda; Type: DATABASE; Schema: -; Owner: root
--

CREATE DATABASE "inker-agenda" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE "inker-agenda" OWNER TO root;

\connect -reuse-previous=on "dbname='inker-agenda'"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: quotation_appealed_reason; Type: TYPE; Schema: public; Owner: root
--

CREATE TYPE public.quotation_appealed_reason AS ENUM (
    'date_change',
    'price_change',
    'design_change',
    'other'
);


ALTER TYPE public.quotation_appealed_reason OWNER TO root;

--
-- Name: quotation_artist_reject_reason; Type: TYPE; Schema: public; Owner: root
--

CREATE TYPE public.quotation_artist_reject_reason AS ENUM (
    'scheduling_conflict',
    'artistic_disagreement',
    'insufficient_details',
    'beyond_expertise',
    'other'
);


ALTER TYPE public.quotation_artist_reject_reason OWNER TO root;

--
-- Name: quotation_canceled_by; Type: TYPE; Schema: public; Owner: root
--

CREATE TYPE public.quotation_canceled_by AS ENUM (
    'customer',
    'system'
);


ALTER TYPE public.quotation_canceled_by OWNER TO root;

--
-- Name: quotation_customer_cancel_reason; Type: TYPE; Schema: public; Owner: root
--

CREATE TYPE public.quotation_customer_cancel_reason AS ENUM (
    'change_of_mind',
    'found_another_artist',
    'financial_reasons',
    'personal_reasons',
    'other'
);


ALTER TYPE public.quotation_customer_cancel_reason OWNER TO root;

--
-- Name: quotation_customer_reject_reason; Type: TYPE; Schema: public; Owner: root
--

CREATE TYPE public.quotation_customer_reject_reason AS ENUM (
    'too_expensive',
    'not_what_i_wanted',
    'changed_my_mind',
    'found_another_artist',
    'other'
);


ALTER TYPE public.quotation_customer_reject_reason OWNER TO root;

--
-- Name: quotation_reject_by; Type: TYPE; Schema: public; Owner: root
--

CREATE TYPE public.quotation_reject_by AS ENUM (
    'customer',
    'artist',
    'system'
);


ALTER TYPE public.quotation_reject_by OWNER TO root;

--
-- Name: quotation_status; Type: TYPE; Schema: public; Owner: root
--

CREATE TYPE public.quotation_status AS ENUM (
    'pending',
    'quoted',
    'accepted',
    'rejected',
    'appealed',
    'canceled'
);


ALTER TYPE public.quotation_status OWNER TO root;

--
-- Name: quotation_system_cancel_reason; Type: TYPE; Schema: public; Owner: root
--

CREATE TYPE public.quotation_system_cancel_reason AS ENUM (
    'not_attended',
    'system_timeout'
);


ALTER TYPE public.quotation_system_cancel_reason OWNER TO root;

--
-- Name: quotation_user_type; Type: TYPE; Schema: public; Owner: root
--

CREATE TYPE public.quotation_user_type AS ENUM (
    'customer',
    'artist',
    'admin',
    'system'
);


ALTER TYPE public.quotation_user_type OWNER TO root;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: agenda; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.agenda (
    id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    user_id integer NOT NULL,
    artist_id integer DEFAULT 0 NOT NULL,
    working_days jsonb DEFAULT '["1", "2", "3", "4", "5"]'::jsonb NOT NULL,
    public boolean DEFAULT false NOT NULL,
    open boolean DEFAULT true NOT NULL,
    deleted_at timestamp without time zone
);


ALTER TABLE public.agenda OWNER TO root;

--
-- Name: agenda_event; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.agenda_event (
    id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    customer_id integer,
    title character varying NOT NULL,
    start timestamp without time zone NOT NULL,
    "end" timestamp without time zone NOT NULL,
    color character varying NOT NULL,
    info character varying NOT NULL,
    notification boolean DEFAULT false NOT NULL,
    done boolean DEFAULT false NOT NULL,
    deleted_at timestamp without time zone,
    agenda_id integer,
    work_evidence jsonb,
    cancelation_reason character varying,
    quotation_id integer
);


ALTER TABLE public.agenda_event OWNER TO root;

--
-- Name: agenda_event_history; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.agenda_event_history (
    id integer NOT NULL,
    title character varying NOT NULL,
    start timestamp without time zone NOT NULL,
    "end" timestamp without time zone NOT NULL,
    color character varying NOT NULL,
    info character varying NOT NULL,
    notification boolean DEFAULT false NOT NULL,
    done boolean DEFAULT false NOT NULL,
    "cancelationReason" character varying,
    recorded_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_by integer NOT NULL,
    event_id integer
);


ALTER TABLE public.agenda_event_history OWNER TO root;

--
-- Name: agenda_event_history_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.agenda_event_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.agenda_event_history_id_seq OWNER TO root;

--
-- Name: agenda_event_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.agenda_event_history_id_seq OWNED BY public.agenda_event_history.id;


--
-- Name: agenda_event_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.agenda_event_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.agenda_event_id_seq OWNER TO root;

--
-- Name: agenda_event_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.agenda_event_id_seq OWNED BY public.agenda_event.id;


--
-- Name: agenda_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.agenda_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.agenda_id_seq OWNER TO root;

--
-- Name: agenda_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.agenda_id_seq OWNED BY public.agenda.id;


--
-- Name: agenda_invitation; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.agenda_invitation (
    id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    invitee_id integer NOT NULL,
    status character varying NOT NULL,
    event_id integer
);


ALTER TABLE public.agenda_invitation OWNER TO root;

--
-- Name: agenda_invitation_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.agenda_invitation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.agenda_invitation_id_seq OWNER TO root;

--
-- Name: agenda_invitation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.agenda_invitation_id_seq OWNED BY public.agenda_invitation.id;


--
-- Name: quotation; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.quotation (
    id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    customer_id integer NOT NULL,
    artist_id integer NOT NULL,
    description character varying NOT NULL,
    estimated_cost integer,
    response_date timestamp without time zone,
    appointment_date timestamp without time zone,
    appointment_duration integer,
    appealed_date timestamp without time zone,
    canceled_date timestamp without time zone,
    reference_images jsonb,
    proposed_designs jsonb,
    cancel_reason_details text,
    reject_reason_details text,
    rejected_date timestamp without time zone,
    last_updated_by integer,
    last_updated_by_user_type public.quotation_user_type,
    status public.quotation_status DEFAULT 'pending'::public.quotation_status NOT NULL,
    reject_by public.quotation_reject_by,
    customer_reject_reason public.quotation_customer_reject_reason,
    artist_reject_reason public.quotation_artist_reject_reason,
    appealed_reason public.quotation_appealed_reason,
    canceled_by public.quotation_canceled_by,
    customer_cancel_reason public.quotation_customer_cancel_reason,
    system_cancel_reason public.quotation_system_cancel_reason
);


ALTER TABLE public.quotation OWNER TO root;

--
-- Name: COLUMN quotation.last_updated_by; Type: COMMENT; Schema: public; Owner: root
--

COMMENT ON COLUMN public.quotation.last_updated_by IS 'User ID of the last person who updated the quotation';


--
-- Name: quotation_history; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.quotation_history (
    id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    changed_at timestamp without time zone DEFAULT now() NOT NULL,
    changed_by integer NOT NULL,
    changed_by_user_type character varying NOT NULL,
    quotation_id integer,
    previous_status character varying NOT NULL,
    new_status character varying NOT NULL,
    previous_estimated_cost numeric(10,2),
    new_estimated_cost numeric(10,2),
    previous_appointment_date timestamp without time zone,
    new_appointment_date timestamp without time zone,
    previous_appointment_duration integer,
    new_appointment_duration integer,
    appealed_reason character varying,
    rejection_reason text,
    cancellation_reason text,
    additional_details text,
    last_updated_by integer,
    last_updated_by_user_type public.quotation_user_type
);


ALTER TABLE public.quotation_history OWNER TO root;

--
-- Name: COLUMN quotation_history.last_updated_by; Type: COMMENT; Schema: public; Owner: root
--

COMMENT ON COLUMN public.quotation_history.last_updated_by IS 'User ID of the last person who updated the quotation';


--
-- Name: quotation_history_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.quotation_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.quotation_history_id_seq OWNER TO root;

--
-- Name: quotation_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.quotation_history_id_seq OWNED BY public.quotation_history.id;


--
-- Name: quotation_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.quotation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.quotation_id_seq OWNER TO root;

--
-- Name: quotation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.quotation_id_seq OWNED BY public.quotation.id;


--
-- Name: agenda id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.agenda ALTER COLUMN id SET DEFAULT nextval('public.agenda_id_seq'::regclass);


--
-- Name: agenda_event id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.agenda_event ALTER COLUMN id SET DEFAULT nextval('public.agenda_event_id_seq'::regclass);


--
-- Name: agenda_event_history id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.agenda_event_history ALTER COLUMN id SET DEFAULT nextval('public.agenda_event_history_id_seq'::regclass);


--
-- Name: agenda_invitation id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.agenda_invitation ALTER COLUMN id SET DEFAULT nextval('public.agenda_invitation_id_seq'::regclass);


--
-- Name: quotation id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.quotation ALTER COLUMN id SET DEFAULT nextval('public.quotation_id_seq'::regclass);


--
-- Name: quotation_history id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.quotation_history ALTER COLUMN id SET DEFAULT nextval('public.quotation_history_id_seq'::regclass);


--
-- Data for Name: agenda; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.agenda (id, created_at, updated_at, user_id, artist_id, working_days, public, open, deleted_at) FROM stdin;
\.
COPY public.agenda (id, created_at, updated_at, user_id, artist_id, working_days, public, open, deleted_at) FROM '$$PATH$$/3428.dat';

--
-- Data for Name: agenda_event; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.agenda_event (id, created_at, updated_at, customer_id, title, start, "end", color, info, notification, done, deleted_at, agenda_id, work_evidence, cancelation_reason, quotation_id) FROM stdin;
\.
COPY public.agenda_event (id, created_at, updated_at, customer_id, title, start, "end", color, info, notification, done, deleted_at, agenda_id, work_evidence, cancelation_reason, quotation_id) FROM '$$PATH$$/3429.dat';

--
-- Data for Name: agenda_event_history; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.agenda_event_history (id, title, start, "end", color, info, notification, done, "cancelationReason", recorded_at, updated_by, event_id) FROM stdin;
\.
COPY public.agenda_event_history (id, title, start, "end", color, info, notification, done, "cancelationReason", recorded_at, updated_by, event_id) FROM '$$PATH$$/3435.dat';

--
-- Data for Name: agenda_invitation; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.agenda_invitation (id, created_at, updated_at, invitee_id, status, event_id) FROM stdin;
\.
COPY public.agenda_invitation (id, created_at, updated_at, invitee_id, status, event_id) FROM '$$PATH$$/3433.dat';

--
-- Data for Name: quotation; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.quotation (id, created_at, updated_at, customer_id, artist_id, description, estimated_cost, response_date, appointment_date, appointment_duration, appealed_date, canceled_date, reference_images, proposed_designs, cancel_reason_details, reject_reason_details, rejected_date, last_updated_by, last_updated_by_user_type, status, reject_by, customer_reject_reason, artist_reject_reason, appealed_reason, canceled_by, customer_cancel_reason, system_cancel_reason) FROM stdin;
\.
COPY public.quotation (id, created_at, updated_at, customer_id, artist_id, description, estimated_cost, response_date, appointment_date, appointment_duration, appealed_date, canceled_date, reference_images, proposed_designs, cancel_reason_details, reject_reason_details, rejected_date, last_updated_by, last_updated_by_user_type, status, reject_by, customer_reject_reason, artist_reject_reason, appealed_reason, canceled_by, customer_cancel_reason, system_cancel_reason) FROM '$$PATH$$/3437.dat';

--
-- Data for Name: quotation_history; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.quotation_history (id, created_at, updated_at, changed_at, changed_by, changed_by_user_type, quotation_id, previous_status, new_status, previous_estimated_cost, new_estimated_cost, previous_appointment_date, new_appointment_date, previous_appointment_duration, new_appointment_duration, appealed_reason, rejection_reason, cancellation_reason, additional_details, last_updated_by, last_updated_by_user_type) FROM stdin;
\.
COPY public.quotation_history (id, created_at, updated_at, changed_at, changed_by, changed_by_user_type, quotation_id, previous_status, new_status, previous_estimated_cost, new_estimated_cost, previous_appointment_date, new_appointment_date, previous_appointment_duration, new_appointment_duration, appealed_reason, rejection_reason, cancellation_reason, additional_details, last_updated_by, last_updated_by_user_type) FROM '$$PATH$$/3439.dat';

--
-- Name: agenda_event_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.agenda_event_history_id_seq', 1, false);


--
-- Name: agenda_event_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.agenda_event_id_seq', 8, true);


--
-- Name: agenda_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.agenda_id_seq', 8, true);


--
-- Name: agenda_invitation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.agenda_invitation_id_seq', 17, true);


--
-- Name: quotation_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.quotation_history_id_seq', 40, true);


--
-- Name: quotation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.quotation_id_seq', 76, true);


--
-- Name: agenda_event PK_2d1f04ea60f7ca9b758000ad5dc; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.agenda_event
    ADD CONSTRAINT "PK_2d1f04ea60f7ca9b758000ad5dc" PRIMARY KEY (id);


--
-- Name: agenda PK_49397cfc20589bebaac8b43251d; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.agenda
    ADD CONSTRAINT "PK_49397cfc20589bebaac8b43251d" PRIMARY KEY (id);


--
-- Name: agenda_event_history PK_580077f240837b5cdb035b37916; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.agenda_event_history
    ADD CONSTRAINT "PK_580077f240837b5cdb035b37916" PRIMARY KEY (id);


--
-- Name: quotation PK_596c572d5858492d10d8cf5383d; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.quotation
    ADD CONSTRAINT "PK_596c572d5858492d10d8cf5383d" PRIMARY KEY (id);


--
-- Name: agenda_invitation PK_90721b8d5e50986a26a8830b6fd; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.agenda_invitation
    ADD CONSTRAINT "PK_90721b8d5e50986a26a8830b6fd" PRIMARY KEY (id);


--
-- Name: quotation_history PK_a14a0b9bfa5bb74d3a46c0a7ee6; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.quotation_history
    ADD CONSTRAINT "PK_a14a0b9bfa5bb74d3a46c0a7ee6" PRIMARY KEY (id);


--
-- Name: agenda_invitation REL_a4be6d79f7ac6e0ff252361f5f; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.agenda_invitation
    ADD CONSTRAINT "REL_a4be6d79f7ac6e0ff252361f5f" UNIQUE (event_id);


--
-- Name: IDX_0819be156d36ead6e3a10d7391; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_0819be156d36ead6e3a10d7391" ON public.agenda_event USING btree (quotation_id);


--
-- Name: IDX_430a191d6a4bd0f4d89d55234a; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_430a191d6a4bd0f4d89d55234a" ON public.agenda_event USING btree (start, "end");


--
-- Name: IDX_95663d2c16f5445a1b677d5482; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_95663d2c16f5445a1b677d5482" ON public.quotation USING btree (artist_id);


--
-- Name: IDX_a4be6d79f7ac6e0ff252361f5f; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_a4be6d79f7ac6e0ff252361f5f" ON public.agenda_invitation USING btree (event_id);


--
-- Name: IDX_a9d713d3bd3c54be56263cb76e; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_a9d713d3bd3c54be56263cb76e" ON public.quotation USING btree (customer_id);


--
-- Name: IDX_c9083b6cdc404ea78948b7b625; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_c9083b6cdc404ea78948b7b625" ON public.agenda USING btree (artist_id);


--
-- Name: IDX_d8e23333078e7438cafd5e4535; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_d8e23333078e7438cafd5e4535" ON public.agenda USING btree (user_id);


--
-- Name: idx_agenda_id; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX idx_agenda_id ON public.agenda_event USING btree (agenda_id);


--
-- Name: quotation_history FK_17ee753f917de8c53ca06c6425f; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.quotation_history
    ADD CONSTRAINT "FK_17ee753f917de8c53ca06c6425f" FOREIGN KEY (quotation_id) REFERENCES public.quotation(id);


--
-- Name: agenda_event_history FK_23d67ae396d322090e5cc4fed29; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.agenda_event_history
    ADD CONSTRAINT "FK_23d67ae396d322090e5cc4fed29" FOREIGN KEY (event_id) REFERENCES public.agenda_event(id);


--
-- Name: agenda_event FK_52830e038af1114957b8f95a507; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.agenda_event
    ADD CONSTRAINT "FK_52830e038af1114957b8f95a507" FOREIGN KEY (agenda_id) REFERENCES public.agenda(id);


--
-- Name: agenda_invitation FK_a4be6d79f7ac6e0ff252361f5f7; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.agenda_invitation
    ADD CONSTRAINT "FK_a4be6d79f7ac6e0ff252361f5f7" FOREIGN KEY (event_id) REFERENCES public.agenda_event(id);


--
-- PostgreSQL database dump complete
--

