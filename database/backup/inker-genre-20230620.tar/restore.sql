--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.1 (Debian 15.1-1.pgdg110+1)
-- Dumped by pg_dump version 15.1 (Debian 15.1-1.pgdg110+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "inker-genre";
--
-- Name: inker-genre; Type: DATABASE; Schema: -; Owner: root
--

CREATE DATABASE "inker-genre" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE "inker-genre" OWNER TO root;

\connect -reuse-previous=on "dbname='inker-genre'"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: genrer; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.genrer (
    id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    name character varying NOT NULL,
    created_by text
);


ALTER TABLE public.genrer OWNER TO root;

--
-- Name: genrer_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.genrer_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.genrer_id_seq OWNER TO root;

--
-- Name: genrer_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.genrer_id_seq OWNED BY public.genrer.id;


--
-- Name: genrer id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.genrer ALTER COLUMN id SET DEFAULT nextval('public.genrer_id_seq'::regclass);


--
-- Data for Name: genrer; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.genrer (id, created_at, updated_at, name, created_by) FROM stdin;
\.
COPY public.genrer (id, created_at, updated_at, name, created_by) FROM '$$PATH$$/3325.dat';

--
-- Name: genrer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.genrer_id_seq', 1, false);


--
-- Name: genrer PK_8ace312a97fdc292323578bb158; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.genrer
    ADD CONSTRAINT "PK_8ace312a97fdc292323578bb158" PRIMARY KEY (id);


--
-- Name: IDX_3a24e6737df006b9aa30b76cca; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_3a24e6737df006b9aa30b76cca" ON public.genrer USING btree (name);


--
-- PostgreSQL database dump complete
--

