--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.1 (Debian 15.1-1.pgdg110+1)
-- Dumped by pg_dump version 15.1 (Debian 15.1-1.pgdg110+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "inker-review";
--
-- Name: inker-review; Type: DATABASE; Schema: -; Owner: root
--

CREATE DATABASE "inker-review" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE "inker-review" OWNER TO root;

\connect -reuse-previous=on "dbname='inker-review'"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: reaction_type_enum; Type: TYPE; Schema: public; Owner: root
--

CREATE TYPE public.reaction_type_enum AS ENUM (
    'like',
    'dislike',
    'off'
);


ALTER TYPE public.reaction_type_enum OWNER TO root;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: review; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.review (
    id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    artist_id integer NOT NULL,
    event_id integer NOT NULL,
    value real,
    header character varying(30),
    content character varying,
    review_reactions jsonb DEFAULT '{"likes": 0, "dislikes": 0}'::jsonb NOT NULL,
    created_by integer NOT NULL,
    display_name character varying NOT NULL,
    is_rated boolean DEFAULT false NOT NULL
);


ALTER TABLE public.review OWNER TO root;

--
-- Name: review_avg; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.review_avg (
    id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    artist_id integer NOT NULL,
    value real NOT NULL,
    detail jsonb DEFAULT '{"1": 0, "2": 0, "3": 0, "4": 0, "5": 0, "1.5": 0, "2.5": 0, "3.5": 0, "4.5": 0}'::jsonb NOT NULL,
    count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.review_avg OWNER TO root;

--
-- Name: review_avg_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.review_avg_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.review_avg_id_seq OWNER TO root;

--
-- Name: review_avg_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.review_avg_id_seq OWNED BY public.review_avg.id;


--
-- Name: review_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.review_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.review_id_seq OWNER TO root;

--
-- Name: review_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.review_id_seq OWNED BY public.review.id;


--
-- Name: review_reaction; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.review_reaction (
    id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    customer_id integer NOT NULL,
    reaction_type public.reaction_type_enum NOT NULL,
    review_id integer NOT NULL
);


ALTER TABLE public.review_reaction OWNER TO root;

--
-- Name: review_reaction_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.review_reaction_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.review_reaction_id_seq OWNER TO root;

--
-- Name: review_reaction_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.review_reaction_id_seq OWNED BY public.review_reaction.id;


--
-- Name: review id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.review ALTER COLUMN id SET DEFAULT nextval('public.review_id_seq'::regclass);


--
-- Name: review_avg id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.review_avg ALTER COLUMN id SET DEFAULT nextval('public.review_avg_id_seq'::regclass);


--
-- Name: review_reaction id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.review_reaction ALTER COLUMN id SET DEFAULT nextval('public.review_reaction_id_seq'::regclass);


--
-- Data for Name: review; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.review (id, created_at, updated_at, artist_id, event_id, value, header, content, review_reactions, created_by, display_name, is_rated) FROM stdin;
\.
COPY public.review (id, created_at, updated_at, artist_id, event_id, value, header, content, review_reactions, created_by, display_name, is_rated) FROM '$$PATH$$/3356.dat';

--
-- Data for Name: review_avg; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.review_avg (id, created_at, updated_at, artist_id, value, detail, count) FROM stdin;
\.
COPY public.review_avg (id, created_at, updated_at, artist_id, value, detail, count) FROM '$$PATH$$/3358.dat';

--
-- Data for Name: review_reaction; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.review_reaction (id, created_at, updated_at, customer_id, reaction_type, review_id) FROM stdin;
\.
COPY public.review_reaction (id, created_at, updated_at, customer_id, reaction_type, review_id) FROM '$$PATH$$/3360.dat';

--
-- Name: review_avg_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.review_avg_id_seq', 2, true);


--
-- Name: review_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.review_id_seq', 8, true);


--
-- Name: review_reaction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.review_reaction_id_seq', 8, true);


--
-- Name: review PK_2e4299a343a81574217255c00ca; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.review
    ADD CONSTRAINT "PK_2e4299a343a81574217255c00ca" PRIMARY KEY (id);


--
-- Name: review_reaction PK_7e099e5dc661aed762a9554c02f; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.review_reaction
    ADD CONSTRAINT "PK_7e099e5dc661aed762a9554c02f" PRIMARY KEY (id);


--
-- Name: review_avg PK_c7cf0ad3df57a93c8d47bbf750b; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.review_avg
    ADD CONSTRAINT "PK_c7cf0ad3df57a93c8d47bbf750b" PRIMARY KEY (id);


--
-- Name: IDX_005b84b7e7dd19d28f1c36eb7c; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_005b84b7e7dd19d28f1c36eb7c" ON public.review USING btree (event_id);


--
-- Name: IDX_66bf56ba69663e8d8aeac98c6a; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_66bf56ba69663e8d8aeac98c6a" ON public.review USING btree (artist_id);


--
-- Name: IDX_a563b6be744b9227034603ea8e; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_a563b6be744b9227034603ea8e" ON public.review_reaction USING btree (review_id);


--
-- Name: IDX_c9b1734cc444c093517d27ae6b; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_c9b1734cc444c093517d27ae6b" ON public.review_avg USING btree (artist_id);


--
-- Name: IDX_e054028c75449a8ecae0fcf21b; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_e054028c75449a8ecae0fcf21b" ON public.review_reaction USING btree (customer_id);


--
-- PostgreSQL database dump complete
--

