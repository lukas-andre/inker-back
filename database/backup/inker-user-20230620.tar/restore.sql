--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.1 (Debian 15.1-1.pgdg110+1)
-- Dumped by pg_dump version 15.1 (Debian 15.1-1.pgdg110+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "inker-user";
--
-- Name: inker-user; Type: DATABASE; Schema: -; Owner: root
--

CREATE DATABASE "inker-user" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE "inker-user" OWNER TO root;

\connect -reuse-previous=on "dbname='inker-user'"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: permission; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.permission (
    id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    controller character varying NOT NULL,
    action character varying NOT NULL,
    description character varying
);


ALTER TABLE public.permission OWNER TO root;

--
-- Name: permission_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.permission_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.permission_id_seq OWNER TO root;

--
-- Name: permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.permission_id_seq OWNED BY public.permission.id;


--
-- Name: role; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.role (
    id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    name character varying NOT NULL,
    description character varying NOT NULL
);


ALTER TABLE public.role OWNER TO root;

--
-- Name: role_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.role_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.role_id_seq OWNER TO root;

--
-- Name: role_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.role_id_seq OWNED BY public.role.id;


--
-- Name: role_permission; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.role_permission (
    "roleId" integer NOT NULL,
    "permissionId" integer NOT NULL
);


ALTER TABLE public.role_permission OWNER TO root;

--
-- Name: user; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public."user" (
    id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    username character varying(100) NOT NULL,
    email character varying NOT NULL,
    password character varying NOT NULL,
    user_type character varying NOT NULL,
    active boolean DEFAULT false NOT NULL,
    deleted_at timestamp without time zone,
    "roleId" integer
);


ALTER TABLE public."user" OWNER TO root;

--
-- Name: user_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_id_seq OWNER TO root;

--
-- Name: user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.user_id_seq OWNED BY public."user".id;


--
-- Name: verification_hash; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.verification_hash (
    id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    user_id integer NOT NULL,
    hash character varying NOT NULL,
    tries integer NOT NULL,
    notification_type character varying NOT NULL,
    verification_type character varying NOT NULL
);


ALTER TABLE public.verification_hash OWNER TO root;

--
-- Name: verification_hash_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.verification_hash_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.verification_hash_id_seq OWNER TO root;

--
-- Name: verification_hash_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.verification_hash_id_seq OWNED BY public.verification_hash.id;


--
-- Name: permission id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.permission ALTER COLUMN id SET DEFAULT nextval('public.permission_id_seq'::regclass);


--
-- Name: role id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.role ALTER COLUMN id SET DEFAULT nextval('public.role_id_seq'::regclass);


--
-- Name: user id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."user" ALTER COLUMN id SET DEFAULT nextval('public.user_id_seq'::regclass);


--
-- Name: verification_hash id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.verification_hash ALTER COLUMN id SET DEFAULT nextval('public.verification_hash_id_seq'::regclass);


--
-- Data for Name: permission; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.permission (id, created_at, updated_at, controller, action, description) FROM stdin;
\.
COPY public.permission (id, created_at, updated_at, controller, action, description) FROM '$$PATH$$/3370.dat';

--
-- Data for Name: role; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.role (id, created_at, updated_at, name, description) FROM stdin;
\.
COPY public.role (id, created_at, updated_at, name, description) FROM '$$PATH$$/3372.dat';

--
-- Data for Name: role_permission; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.role_permission ("roleId", "permissionId") FROM stdin;
\.
COPY public.role_permission ("roleId", "permissionId") FROM '$$PATH$$/3377.dat';

--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public."user" (id, created_at, updated_at, username, email, password, user_type, active, deleted_at, "roleId") FROM stdin;
\.
COPY public."user" (id, created_at, updated_at, username, email, password, user_type, active, deleted_at, "roleId") FROM '$$PATH$$/3374.dat';

--
-- Data for Name: verification_hash; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.verification_hash (id, created_at, updated_at, user_id, hash, tries, notification_type, verification_type) FROM stdin;
\.
COPY public.verification_hash (id, created_at, updated_at, user_id, hash, tries, notification_type, verification_type) FROM '$$PATH$$/3376.dat';

--
-- Name: permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.permission_id_seq', 14, true);


--
-- Name: role_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.role_id_seq', 5, true);


--
-- Name: user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.user_id_seq', 15, true);


--
-- Name: verification_hash_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.verification_hash_id_seq', 8, true);


--
-- Name: verification_hash PK_2c717c842fd23dc4f75ab5e2fbd; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.verification_hash
    ADD CONSTRAINT "PK_2c717c842fd23dc4f75ab5e2fbd" PRIMARY KEY (id);


--
-- Name: permission PK_3b8b97af9d9d8807e41e6f48362; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.permission
    ADD CONSTRAINT "PK_3b8b97af9d9d8807e41e6f48362" PRIMARY KEY (id);


--
-- Name: role PK_b36bcfe02fc8de3c57a8b2391c2; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.role
    ADD CONSTRAINT "PK_b36bcfe02fc8de3c57a8b2391c2" PRIMARY KEY (id);


--
-- Name: role_permission PK_b42bbacb8402c353df822432544; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.role_permission
    ADD CONSTRAINT "PK_b42bbacb8402c353df822432544" PRIMARY KEY ("roleId", "permissionId");


--
-- Name: user PK_cace4a159ff9f2512dd42373760; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT "PK_cace4a159ff9f2512dd42373760" PRIMARY KEY (id);


--
-- Name: permission UQ_9573e71191df070245e24255230; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.permission
    ADD CONSTRAINT "UQ_9573e71191df070245e24255230" UNIQUE (controller);


--
-- Name: IDX_60e71e288bab95a5ac05f58a84; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_60e71e288bab95a5ac05f58a84" ON public."user" USING btree (user_type);


--
-- Name: IDX_72e80be86cab0e93e67ed1a7a9; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_72e80be86cab0e93e67ed1a7a9" ON public.role_permission USING btree ("permissionId");


--
-- Name: IDX_ae4578dcaed5adff96595e6166; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_ae4578dcaed5adff96595e6166" ON public.role USING btree (name);


--
-- Name: IDX_e3130a39c1e4a740d044e68573; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_e3130a39c1e4a740d044e68573" ON public.role_permission USING btree ("roleId");


--
-- Name: role_permission FK_72e80be86cab0e93e67ed1a7a9a; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.role_permission
    ADD CONSTRAINT "FK_72e80be86cab0e93e67ed1a7a9a" FOREIGN KEY ("permissionId") REFERENCES public.permission(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user FK_c28e52f758e7bbc53828db92194; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT "FK_c28e52f758e7bbc53828db92194" FOREIGN KEY ("roleId") REFERENCES public.role(id);


--
-- Name: role_permission FK_e3130a39c1e4a740d044e685730; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.role_permission
    ADD CONSTRAINT "FK_e3130a39c1e4a740d044e685730" FOREIGN KEY ("roleId") REFERENCES public.role(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

