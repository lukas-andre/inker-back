--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.2 (Debian 16.2-1.pgdg110+2)
-- Dumped by pg_dump version 16.2 (Debian 16.2-1.pgdg110+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "inker-reaction";
--
-- Name: inker-reaction; Type: DATABASE; Schema: -; Owner: root
--

CREATE DATABASE "inker-reaction" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE "inker-reaction" OWNER TO root;

\connect -reuse-previous=on "dbname='inker-reaction'"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: activity; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.activity (
    id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    activity_id integer NOT NULL,
    reaction_type character varying NOT NULL,
    activity_type character varying NOT NULL,
    reactions integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.activity OWNER TO root;

--
-- Name: activity_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.activity_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.activity_id_seq OWNER TO root;

--
-- Name: activity_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.activity_id_seq OWNED BY public.activity.id;


--
-- Name: reaction; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.reaction (
    id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    activity_id integer NOT NULL,
    activity_type character varying NOT NULL,
    reaction_type character varying NOT NULL,
    active boolean NOT NULL,
    location character varying NOT NULL,
    user_id integer NOT NULL,
    user_type_id integer NOT NULL,
    user_type character varying NOT NULL,
    profile_thumbnail character varying,
    username character varying NOT NULL
);


ALTER TABLE public.reaction OWNER TO root;

--
-- Name: reaction_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.reaction_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.reaction_id_seq OWNER TO root;

--
-- Name: reaction_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.reaction_id_seq OWNED BY public.reaction.id;


--
-- Name: activity id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.activity ALTER COLUMN id SET DEFAULT nextval('public.activity_id_seq'::regclass);


--
-- Name: reaction id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.reaction ALTER COLUMN id SET DEFAULT nextval('public.reaction_id_seq'::regclass);


--
-- Data for Name: activity; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.activity (id, created_at, updated_at, activity_id, reaction_type, activity_type, reactions) FROM stdin;
\.
COPY public.activity (id, created_at, updated_at, activity_id, reaction_type, activity_type, reactions) FROM '$$PATH$$/3346.dat';

--
-- Data for Name: reaction; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.reaction (id, created_at, updated_at, activity_id, activity_type, reaction_type, active, location, user_id, user_type_id, user_type, profile_thumbnail, username) FROM stdin;
\.
COPY public.reaction (id, created_at, updated_at, activity_id, activity_type, reaction_type, active, location, user_id, user_type_id, user_type, profile_thumbnail, username) FROM '$$PATH$$/3348.dat';

--
-- Name: activity_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.activity_id_seq', 1, false);


--
-- Name: reaction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.reaction_id_seq', 1, false);


--
-- Name: activity PK_24625a1d6b1b089c8ae206fe467; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.activity
    ADD CONSTRAINT "PK_24625a1d6b1b089c8ae206fe467" PRIMARY KEY (id);


--
-- Name: reaction PK_41fbb346da22da4df129f14b11e; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.reaction
    ADD CONSTRAINT "PK_41fbb346da22da4df129f14b11e" PRIMARY KEY (id);


--
-- Name: IDX_0e33ea8cf21e7355c152b18f2b; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_0e33ea8cf21e7355c152b18f2b" ON public.reaction USING btree (activity_id);


--
-- Name: IDX_2230e00a30a1c3423ed26b5d08; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_2230e00a30a1c3423ed26b5d08" ON public.reaction USING btree (active);


--
-- Name: IDX_678281c99a36ba76bbcd4baa82; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_678281c99a36ba76bbcd4baa82" ON public.activity USING btree (activity_type);


--
-- Name: IDX_7c457b73b6917a019a31b9a8c8; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_7c457b73b6917a019a31b9a8c8" ON public.reaction USING btree (user_type_id);


--
-- Name: IDX_978c984f412d09b43304e41ae9; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_978c984f412d09b43304e41ae9" ON public.reaction USING btree (user_id);


--
-- Name: IDX_ace7dee1643c316f016d8b8204; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_ace7dee1643c316f016d8b8204" ON public.reaction USING btree (activity_type);


--
-- Name: IDX_f4d42df90549af0a27dcefb3a1; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_f4d42df90549af0a27dcefb3a1" ON public.reaction USING btree (reaction_type);


--
-- PostgreSQL database dump complete
--

