--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.1 (Debian 15.1-1.pgdg110+1)
-- Dumped by pg_dump version 15.1 (Debian 15.1-1.pgdg110+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "inker-agenda";
--
-- Name: inker-agenda; Type: DATABASE; Schema: -; Owner: root
--

CREATE DATABASE "inker-agenda" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE "inker-agenda" OWNER TO root;

\connect -reuse-previous=on "dbname='inker-agenda'"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: agenda; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.agenda (
    id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    user_id integer NOT NULL,
    artist_id integer DEFAULT 0 NOT NULL,
    working_days jsonb DEFAULT '["1", "2", "3", "4", "5"]'::jsonb NOT NULL,
    public boolean DEFAULT false NOT NULL,
    open boolean DEFAULT true NOT NULL,
    deleted_at timestamp without time zone
);


ALTER TABLE public.agenda OWNER TO root;

--
-- Name: agenda_event; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.agenda_event (
    id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    customer_id integer,
    title character varying NOT NULL,
    start timestamp without time zone NOT NULL,
    "end" timestamp without time zone NOT NULL,
    color character varying NOT NULL,
    info character varying NOT NULL,
    notification boolean DEFAULT false NOT NULL,
    done boolean DEFAULT false NOT NULL,
    deleted_at timestamp without time zone,
    agenda_id integer,
    work_evidence jsonb
);


ALTER TABLE public.agenda_event OWNER TO root;

--
-- Name: agenda_event_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.agenda_event_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.agenda_event_id_seq OWNER TO root;

--
-- Name: agenda_event_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.agenda_event_id_seq OWNED BY public.agenda_event.id;


--
-- Name: agenda_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.agenda_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.agenda_id_seq OWNER TO root;

--
-- Name: agenda_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.agenda_id_seq OWNED BY public.agenda.id;


--
-- Name: agenda id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.agenda ALTER COLUMN id SET DEFAULT nextval('public.agenda_id_seq'::regclass);


--
-- Name: agenda_event id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.agenda_event ALTER COLUMN id SET DEFAULT nextval('public.agenda_event_id_seq'::regclass);


--
-- Data for Name: agenda; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.agenda (id, created_at, updated_at, user_id, artist_id, working_days, public, open, deleted_at) FROM stdin;
\.
COPY public.agenda (id, created_at, updated_at, user_id, artist_id, working_days, public, open, deleted_at) FROM '$$PATH$$/3345.dat';

--
-- Data for Name: agenda_event; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.agenda_event (id, created_at, updated_at, customer_id, title, start, "end", color, info, notification, done, deleted_at, agenda_id, work_evidence) FROM stdin;
\.
COPY public.agenda_event (id, created_at, updated_at, customer_id, title, start, "end", color, info, notification, done, deleted_at, agenda_id, work_evidence) FROM '$$PATH$$/3343.dat';

--
-- Name: agenda_event_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.agenda_event_id_seq', 8, true);


--
-- Name: agenda_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.agenda_id_seq', 8, true);


--
-- Name: agenda_event PK_2d1f04ea60f7ca9b758000ad5dc; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.agenda_event
    ADD CONSTRAINT "PK_2d1f04ea60f7ca9b758000ad5dc" PRIMARY KEY (id);


--
-- Name: agenda PK_49397cfc20589bebaac8b43251d; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.agenda
    ADD CONSTRAINT "PK_49397cfc20589bebaac8b43251d" PRIMARY KEY (id);


--
-- Name: IDX_c9083b6cdc404ea78948b7b625; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_c9083b6cdc404ea78948b7b625" ON public.agenda USING btree (artist_id);


--
-- Name: IDX_d8e23333078e7438cafd5e4535; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_d8e23333078e7438cafd5e4535" ON public.agenda USING btree (user_id);


--
-- Name: agenda_event FK_52830e038af1114957b8f95a507; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.agenda_event
    ADD CONSTRAINT "FK_52830e038af1114957b8f95a507" FOREIGN KEY (agenda_id) REFERENCES public.agenda(id);


--
-- PostgreSQL database dump complete
--

