--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.2 (Debian 16.2-1.pgdg110+2)
-- Dumped by pg_dump version 16.2 (Debian 16.2-1.pgdg110+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "inker-customer-feed";
--
-- Name: inker-customer-feed; Type: DATABASE; Schema: -; Owner: root
--

CREATE DATABASE "inker-customer-feed" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE "inker-customer-feed" OWNER TO root;

\connect -reuse-previous=on "dbname='inker-customer-feed'"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: customer_feed; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.customer_feed (
    id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    "userId" character varying NOT NULL,
    feed jsonb NOT NULL,
    "maxItems" integer DEFAULT 50 NOT NULL
);


ALTER TABLE public.customer_feed OWNER TO root;

--
-- Name: customer_feed_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.customer_feed_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.customer_feed_id_seq OWNER TO root;

--
-- Name: customer_feed_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.customer_feed_id_seq OWNED BY public.customer_feed.id;


--
-- Name: customer_feed id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.customer_feed ALTER COLUMN id SET DEFAULT nextval('public.customer_feed_id_seq'::regclass);


--
-- Data for Name: customer_feed; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.customer_feed (id, created_at, updated_at, "userId", feed, "maxItems") FROM stdin;
\.
COPY public.customer_feed (id, created_at, updated_at, "userId", feed, "maxItems") FROM '$$PATH$$/3330.dat';

--
-- Name: customer_feed_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.customer_feed_id_seq', 1, false);


--
-- Name: customer_feed PK_0ea45282db360536f96375c8ae7; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.customer_feed
    ADD CONSTRAINT "PK_0ea45282db360536f96375c8ae7" PRIMARY KEY (id);


--
-- Name: IDX_54a4e7dee8f1ae70885954f2f5; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_54a4e7dee8f1ae70885954f2f5" ON public.customer_feed USING btree ("userId");


--
-- PostgreSQL database dump complete
--

