--
-- PostgreSQL database dump
--

-- Dumped from database version 17.2 (Debian 17.2-1.pgdg110+1)
-- Dumped by pg_dump version 17.2 (Debian 17.2-1.pgdg110+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: quotation_appealed_reason; Type: TYPE; Schema: public; Owner: root
--

CREATE TYPE public.quotation_appealed_reason AS ENUM (
    'date_change',
    'price_change',
    'design_change',
    'other'
);


ALTER TYPE public.quotation_appealed_reason OWNER TO root;

--
-- Name: quotation_artist_reject_reason; Type: TYPE; Schema: public; Owner: root
--

CREATE TYPE public.quotation_artist_reject_reason AS ENUM (
    'scheduling_conflict',
    'artistic_disagreement',
    'insufficient_details',
    'beyond_expertise',
    'other'
);


ALTER TYPE public.quotation_artist_reject_reason OWNER TO root;

--
-- Name: quotation_canceled_by; Type: TYPE; Schema: public; Owner: root
--

CREATE TYPE public.quotation_canceled_by AS ENUM (
    'customer',
    'system'
);


ALTER TYPE public.quotation_canceled_by OWNER TO root;

--
-- Name: quotation_customer_cancel_reason; Type: TYPE; Schema: public; Owner: root
--

CREATE TYPE public.quotation_customer_cancel_reason AS ENUM (
    'change_of_mind',
    'found_another_artist',
    'financial_reasons',
    'personal_reasons',
    'other'
);


ALTER TYPE public.quotation_customer_cancel_reason OWNER TO root;

--
-- Name: quotation_customer_reject_reason; Type: TYPE; Schema: public; Owner: root
--

CREATE TYPE public.quotation_customer_reject_reason AS ENUM (
    'too_expensive',
    'not_what_i_wanted',
    'changed_my_mind',
    'found_another_artist',
    'other'
);


ALTER TYPE public.quotation_customer_reject_reason OWNER TO root;

--
-- Name: quotation_reject_by; Type: TYPE; Schema: public; Owner: root
--

CREATE TYPE public.quotation_reject_by AS ENUM (
    'customer',
    'artist',
    'system'
);


ALTER TYPE public.quotation_reject_by OWNER TO root;

--
-- Name: quotation_status; Type: TYPE; Schema: public; Owner: root
--

CREATE TYPE public.quotation_status AS ENUM (
    'pending',
    'quoted',
    'accepted',
    'rejected',
    'appealed',
    'canceled'
);


ALTER TYPE public.quotation_status OWNER TO root;

--
-- Name: quotation_system_cancel_reason; Type: TYPE; Schema: public; Owner: root
--

CREATE TYPE public.quotation_system_cancel_reason AS ENUM (
    'not_attended',
    'system_timeout'
);


ALTER TYPE public.quotation_system_cancel_reason OWNER TO root;

--
-- Name: quotation_user_type; Type: TYPE; Schema: public; Owner: root
--

CREATE TYPE public.quotation_user_type AS ENUM (
    'customer',
    'artist',
    'admin',
    'system'
);


ALTER TYPE public.quotation_user_type OWNER TO root;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: agenda; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.agenda (
    id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    user_id integer NOT NULL,
    artist_id integer DEFAULT 0 NOT NULL,
    working_days jsonb DEFAULT '["1", "2", "3", "4", "5"]'::jsonb NOT NULL,
    public boolean DEFAULT false NOT NULL,
    open boolean DEFAULT true NOT NULL,
    deleted_at timestamp without time zone,
    working_hours_start time without time zone,
    working_hours_end time without time zone
);


ALTER TABLE public.agenda OWNER TO root;

--
-- Name: agenda_event; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.agenda_event (
    id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    customer_id integer,
    title character varying NOT NULL,
    start_date timestamp without time zone NOT NULL,
    end_date timestamp without time zone NOT NULL,
    color character varying NOT NULL,
    info character varying NOT NULL,
    notification boolean DEFAULT false NOT NULL,
    done boolean DEFAULT false NOT NULL,
    work_evidence jsonb,
    cancelation_reason character varying,
    deleted_at timestamp without time zone,
    quotation_id integer,
    agenda_id integer,
    status character varying DEFAULT 'scheduled'::character varying NOT NULL,
    reschedule_reason character varying,
    notes text,
    preparation_time integer,
    cleanup_time integer,
    last_status_change timestamp without time zone,
    customer_notified boolean DEFAULT false NOT NULL
);


ALTER TABLE public.agenda_event OWNER TO root;

--
-- Name: agenda_event_history; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.agenda_event_history (
    id integer NOT NULL,
    title character varying NOT NULL,
    start_date timestamp without time zone NOT NULL,
    end_date timestamp without time zone NOT NULL,
    color character varying NOT NULL,
    info character varying NOT NULL,
    notification boolean DEFAULT false NOT NULL,
    done boolean DEFAULT false NOT NULL,
    cancelation_reason character varying,
    recorded_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_by integer NOT NULL,
    event_id integer,
    status character varying
);


ALTER TABLE public.agenda_event_history OWNER TO root;

--
-- Name: agenda_event_history_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.agenda_event_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.agenda_event_history_id_seq OWNER TO root;

--
-- Name: agenda_event_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.agenda_event_history_id_seq OWNED BY public.agenda_event_history.id;


--
-- Name: agenda_event_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.agenda_event_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.agenda_event_id_seq OWNER TO root;

--
-- Name: agenda_event_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.agenda_event_id_seq OWNED BY public.agenda_event.id;


--
-- Name: agenda_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.agenda_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.agenda_id_seq OWNER TO root;

--
-- Name: agenda_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.agenda_id_seq OWNED BY public.agenda.id;


--
-- Name: agenda_invitation; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.agenda_invitation (
    id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    invitee_id integer NOT NULL,
    status character varying NOT NULL,
    event_id integer
);


ALTER TABLE public.agenda_invitation OWNER TO root;

--
-- Name: agenda_invitation_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.agenda_invitation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.agenda_invitation_id_seq OWNER TO root;

--
-- Name: agenda_invitation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.agenda_invitation_id_seq OWNED BY public.agenda_invitation.id;


--
-- Name: agenda_unavailable_time; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.agenda_unavailable_time (
    id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    agenda_id integer NOT NULL,
    start_date timestamp without time zone NOT NULL,
    end_date timestamp without time zone NOT NULL,
    reason character varying,
    deleted_at timestamp without time zone
);


ALTER TABLE public.agenda_unavailable_time OWNER TO root;

--
-- Name: agenda_unavailable_time_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.agenda_unavailable_time_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.agenda_unavailable_time_id_seq OWNER TO root;

--
-- Name: agenda_unavailable_time_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.agenda_unavailable_time_id_seq OWNED BY public.agenda_unavailable_time.id;


--
-- Name: quotation; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.quotation (
    id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    customer_id integer NOT NULL,
    artist_id integer NOT NULL,
    description character varying NOT NULL,
    reference_images jsonb,
    proposed_designs jsonb,
    status public.quotation_status DEFAULT 'pending'::public.quotation_status NOT NULL,
    response_date timestamp without time zone,
    appointment_date timestamp without time zone,
    appointment_duration integer,
    reject_by public.quotation_reject_by,
    customer_reject_reason public.quotation_customer_reject_reason,
    artist_reject_reason public.quotation_artist_reject_reason,
    reject_reason_details text,
    rejected_date timestamp without time zone,
    appealed_reason public.quotation_appealed_reason,
    appealed_date timestamp without time zone,
    canceled_by public.quotation_canceled_by,
    customer_cancel_reason public.quotation_customer_cancel_reason,
    system_cancel_reason public.quotation_system_cancel_reason,
    cancel_reason_details text,
    canceled_date timestamp without time zone,
    last_updated_by integer,
    last_updated_by_user_type public.quotation_user_type,
    estimated_cost jsonb,
    read_by_artist boolean DEFAULT false NOT NULL,
    read_by_customer boolean DEFAULT false NOT NULL,
    artist_read_at timestamp without time zone,
    customer_read_at timestamp without time zone,
    stencil_id integer
);


ALTER TABLE public.quotation OWNER TO root;

--
-- Name: COLUMN quotation.last_updated_by; Type: COMMENT; Schema: public; Owner: root
--

COMMENT ON COLUMN public.quotation.last_updated_by IS 'User ID of the last person who updated the quotation';


--
-- Name: quotation_backup; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.quotation_backup (
    id integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    customer_id integer,
    artist_id integer,
    description character varying,
    reference_images jsonb,
    proposed_designs jsonb,
    status public.quotation_status,
    response_date timestamp without time zone,
    appointment_date timestamp without time zone,
    appointment_duration integer,
    reject_by public.quotation_reject_by,
    customer_reject_reason public.quotation_customer_reject_reason,
    artist_reject_reason public.quotation_artist_reject_reason,
    reject_reason_details text,
    rejected_date timestamp without time zone,
    appealed_reason public.quotation_appealed_reason,
    appealed_date timestamp without time zone,
    canceled_by public.quotation_canceled_by,
    customer_cancel_reason public.quotation_customer_cancel_reason,
    system_cancel_reason public.quotation_system_cancel_reason,
    cancel_reason_details text,
    canceled_date timestamp without time zone,
    last_updated_by integer,
    last_updated_by_user_type public.quotation_user_type,
    estimated_cost jsonb
);


ALTER TABLE public.quotation_backup OWNER TO root;

--
-- Name: quotation_history; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.quotation_history (
    id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    previous_status character varying NOT NULL,
    new_status character varying NOT NULL,
    changed_at timestamp without time zone DEFAULT now() NOT NULL,
    changed_by integer NOT NULL,
    changed_by_user_type character varying NOT NULL,
    previous_appointment_date timestamp without time zone,
    new_appointment_date timestamp without time zone,
    previous_appointment_duration integer,
    new_appointment_duration integer,
    appealed_reason character varying,
    rejection_reason text,
    cancellation_reason text,
    additional_details text,
    last_updated_by integer,
    last_updated_by_user_type public.quotation_user_type,
    quotation_id integer,
    previous_estimated_cost jsonb,
    new_estimated_cost jsonb
);


ALTER TABLE public.quotation_history OWNER TO root;

--
-- Name: COLUMN quotation_history.last_updated_by; Type: COMMENT; Schema: public; Owner: root
--

COMMENT ON COLUMN public.quotation_history.last_updated_by IS 'User ID of the last person who updated the quotation';


--
-- Name: quotation_history_backup; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.quotation_history_backup (
    id integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    previous_status character varying,
    new_status character varying,
    changed_at timestamp without time zone,
    changed_by integer,
    changed_by_user_type character varying,
    previous_appointment_date timestamp without time zone,
    new_appointment_date timestamp without time zone,
    previous_appointment_duration integer,
    new_appointment_duration integer,
    appealed_reason character varying,
    rejection_reason text,
    cancellation_reason text,
    additional_details text,
    last_updated_by integer,
    last_updated_by_user_type public.quotation_user_type,
    quotation_id integer,
    previous_estimated_cost jsonb,
    new_estimated_cost jsonb
);


ALTER TABLE public.quotation_history_backup OWNER TO root;

--
-- Name: quotation_history_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.quotation_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.quotation_history_id_seq OWNER TO root;

--
-- Name: quotation_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.quotation_history_id_seq OWNED BY public.quotation_history.id;


--
-- Name: quotation_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.quotation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.quotation_id_seq OWNER TO root;

--
-- Name: quotation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.quotation_id_seq OWNED BY public.quotation.id;


--
-- Name: agenda id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.agenda ALTER COLUMN id SET DEFAULT nextval('public.agenda_id_seq'::regclass);


--
-- Name: agenda_event id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.agenda_event ALTER COLUMN id SET DEFAULT nextval('public.agenda_event_id_seq'::regclass);


--
-- Name: agenda_event_history id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.agenda_event_history ALTER COLUMN id SET DEFAULT nextval('public.agenda_event_history_id_seq'::regclass);


--
-- Name: agenda_invitation id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.agenda_invitation ALTER COLUMN id SET DEFAULT nextval('public.agenda_invitation_id_seq'::regclass);


--
-- Name: agenda_unavailable_time id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.agenda_unavailable_time ALTER COLUMN id SET DEFAULT nextval('public.agenda_unavailable_time_id_seq'::regclass);


--
-- Name: quotation id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.quotation ALTER COLUMN id SET DEFAULT nextval('public.quotation_id_seq'::regclass);


--
-- Name: quotation_history id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.quotation_history ALTER COLUMN id SET DEFAULT nextval('public.quotation_history_id_seq'::regclass);


--
-- Data for Name: agenda; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.agenda (id, created_at, updated_at, user_id, artist_id, working_days, public, open, deleted_at, working_hours_start, working_hours_end) FROM stdin;
2	2023-01-10 00:08:58.532959	2023-01-10 00:08:58.532959	2	2	["2", "3", "4", "5", "6"]	t	t	\N	\N	\N
3	2023-01-10 00:12:53.697313	2023-01-10 00:12:53.697313	3	3	["2", "3", "4", "5", "6"]	t	t	\N	\N	\N
8	2023-05-05 17:01:28.794976	2023-05-05 17:01:28.794976	15	8	["2", "3", "4", "5", "6"]	t	t	\N	\N	\N
9	2024-10-27 04:29:07.574794	2024-10-27 04:29:07.574794	29	9	["2", "3", "4", "5", "6"]	t	t	\N	\N	\N
10	2024-10-27 18:30:22.647543	2024-10-27 18:30:22.647543	30	10	["2", "3", "4", "5", "6"]	t	t	\N	\N	\N
11	2024-11-12 02:16:38.614904	2024-11-12 02:16:38.614904	31	11	["2", "3", "4", "5", "6"]	t	t	\N	\N	\N
12	2024-12-22 00:15:41.850011	2024-12-22 00:15:41.850011	38	12	["2", "3", "4", "5", "6"]	t	t	\N	\N	\N
1	2023-01-10 00:03:20.581767	2025-03-08 17:57:40.402941	1	1	["2", "3", "4", "5", "6"]	t	t	\N	09:00:00	18:00:00
\.


--
-- Data for Name: agenda_event; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.agenda_event (id, created_at, updated_at, customer_id, title, start_date, end_date, color, info, notification, done, work_evidence, cancelation_reason, deleted_at, quotation_id, agenda_id, status, reschedule_reason, notes, preparation_time, cleanup_time, last_status_change, customer_notified) FROM stdin;
2	2024-12-16 23:49:32.702	2024-12-16 23:49:32.702	1	Agenda Event	2024-12-02 20:45:00	2024-12-02 21:00:00	#000000	Agenda Event	f	f	\N	\N	\N	160	8	scheduled	\N	\N	\N	\N	\N	f
3	2024-12-16 23:50:19.161	2024-12-16 23:50:19.161	1	Agenda Event Title	2024-12-02 09:00:00	2024-12-02 09:15:00	#000000	Agenda Event Info	f	f	\N	\N	\N	134	8	scheduled	\N	\N	\N	\N	\N	f
4	2024-12-17 00:08:15.354	2024-12-17 00:08:15.354	1	Agenda Event Title	2024-12-17 10:00:00	2024-12-17 11:00:00	#000000	Agenda Event Info	f	f	\N	\N	\N	238	8	scheduled	\N	\N	\N	\N	\N	f
5	2024-12-20 00:41:49.408	2024-12-20 00:41:49.408	3	Agenda Event Title	2024-12-20 04:41:00	2024-12-20 05:41:00	#000000	Agenda Event Info	f	f	\N	\N	\N	239	1	scheduled	\N	\N	\N	\N	\N	f
6	2024-12-20 00:55:38.931	2024-12-20 00:55:38.931	3	Agenda Event Title	2025-01-01 09:54:00	2025-01-01 10:54:00	#000000	Agenda Event Info	f	f	\N	\N	\N	242	9	scheduled	\N	\N	\N	\N	\N	f
7	2024-12-21 21:17:48.403	2024-12-21 21:17:48.403	26	Agenda Event Title	2025-01-14 16:16:00	2025-01-14 17:16:00	#000000	Agenda Event Info	f	f	\N	\N	\N	244	10	scheduled	\N	\N	\N	\N	\N	f
8	2025-03-06 23:01:25.838	2025-03-06 23:01:25.838	3	Agenda Event Title	2025-03-06 12:00:00	2025-03-06 12:15:00	#000000	Agenda Event Info	f	f	\N	\N	\N	259	9	scheduled	\N	\N	\N	\N	\N	f
9	2025-03-06 23:12:24.69	2025-03-06 23:12:24.69	3	Agenda Event Title	2025-03-06 23:11:10.478	2025-03-07 00:11:10.478	#000000	Agenda Event Info	f	f	\N	\N	\N	262	9	scheduled	\N	\N	\N	\N	\N	f
10	2025-03-07 18:19:04.12	2025-03-07 18:19:04.12	3	Agenda Event Title	2025-03-07 10:45:00	2025-03-07 11:00:00	#000000	Agenda Event Info	f	f	\N	\N	\N	264	9	scheduled	\N	\N	\N	\N	\N	f
11	2025-03-11 03:10:20.40208	2025-03-11 03:10:20.40208	1	Appointment with Lucas	2025-03-11 09:00:00	2025-03-11 10:00:00	#000000		t	f	\N	\N	\N	\N	9	scheduled	\N	\N	\N	\N	\N	f
12	2025-03-11 03:13:32.528563	2025-03-11 03:13:32.528563	1	Appointment with Lucas	2025-03-12 09:00:00	2025-03-12 10:00:00	#000000		t	f	\N	\N	\N	\N	9	scheduled	\N	\N	\N	\N	\N	f
14	2025-03-11 03:27:00.986977	2025-03-11 03:27:00.986977	1	Appointment with Lucas	2025-03-14 09:00:00	2025-03-14 10:00:00	#0000FF		t	f	\N	\N	\N	\N	9	scheduled	\N	\N	\N	\N	\N	f
15	2025-03-12 01:31:58.298353	2025-03-12 01:41:23.684243	1	Appointment with Lucas	2025-03-12 11:00:00	2025-03-12 13:00:00	#0000FF	prueba 1	t	f	\N	\N	\N	\N	9	scheduled	\N	\N	\N	\N	\N	f
13	2025-03-11 03:16:47.895392	2025-03-12 01:45:42.802304	1	Appointment with Lucas	2025-03-14 15:00:00	2025-03-14 16:00:00	#000000	prueba de nota\n\n12	t	f	\N	\N	\N	\N	9	scheduled	\N	\N	\N	\N	\N	f
\.


--
-- Data for Name: agenda_event_history; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.agenda_event_history (id, title, start_date, end_date, color, info, notification, done, cancelation_reason, recorded_at, updated_by, event_id, status) FROM stdin;
1	Appointment with Lucas	2025-03-12 12:00:00	2025-03-12 13:00:00	#0000FF	prueba 1	t	f	\N	2025-03-12 01:31:58.298353	9	15	scheduled
2	Appointment with Lucas	2025-03-12 12:00:00	2025-03-12 13:00:00	#0000FF	prueba 1	t	f	\N	2025-03-12 01:40:09.435058	2	15	\N
3	Appointment with Lucas	2025-03-12 17:00:00	2025-03-12 18:00:00	#0000FF	prueba 1	t	f	\N	2025-03-12 01:41:23.664126	2	15	\N
4	Appointment with Lucas	2025-03-11 09:00:00	2025-03-11 10:00:00	#000000		t	f	\N	2025-03-12 01:43:35.918346	2	11	\N
5	Appointment with Lucas	2025-03-13 09:00:00	2025-03-13 10:00:00	#000000		t	f	\N	2025-03-12 01:44:18.561635	2	13	\N
6	Appointment with Lucas	2025-03-13 12:00:00	2025-03-13 13:00:00	#000000	prueba de nota\n\n12	t	f	\N	2025-03-12 01:45:42.779824	2	13	\N
\.


--
-- Data for Name: agenda_invitation; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.agenda_invitation (id, created_at, updated_at, invitee_id, status, event_id) FROM stdin;
1	2025-03-11 03:10:20.40208	2025-03-11 03:10:20.40208	1	pending	11
2	2025-03-11 03:13:32.528563	2025-03-11 03:13:32.528563	1	pending	12
3	2025-03-11 03:16:47.895392	2025-03-11 03:16:47.895392	1	pending	13
4	2025-03-11 03:27:00.986977	2025-03-11 03:27:00.986977	1	pending	14
5	2025-03-12 01:31:58.298353	2025-03-12 01:31:58.298353	1	pending	15
\.


--
-- Data for Name: agenda_unavailable_time; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.agenda_unavailable_time (id, created_at, updated_at, agenda_id, start_date, end_date, reason, deleted_at) FROM stdin;
2	2025-03-08 18:01:33.954464	2025-03-08 18:01:33.954464	1	2025-03-09 00:00:00	2025-03-15 00:00:00	h Go fghh	\N
\.


--
-- Data for Name: quotation; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.quotation (id, created_at, updated_at, customer_id, artist_id, description, reference_images, proposed_designs, status, response_date, appointment_date, appointment_duration, reject_by, customer_reject_reason, artist_reject_reason, reject_reason_details, rejected_date, appealed_reason, appealed_date, canceled_by, customer_cancel_reason, system_cancel_reason, cancel_reason_details, canceled_date, last_updated_by, last_updated_by_user_type, estimated_cost, read_by_artist, read_by_customer, artist_read_at, customer_read_at, stencil_id) FROM stdin;
6	2024-08-22 03:39:54.78399	2024-08-22 03:39:54.78399	1	3	djjdkkd	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N
7	2024-08-22 03:42:21.899824	2024-08-22 03:42:21.899824	1	3	ekjdkjf	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N
8	2024-08-22 03:46:20.591907	2024-08-22 03:46:20.591907	1	3	ejemplo\n	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N
40	2024-09-15 04:58:51.511797	2024-09-15 04:58:51.511797	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N
26	2024-08-23 04:12:16.024625	2024-09-02 04:03:22.331327	1	8	dnjdjd	\N	\N	canceled	2024-09-02 04:03:22.331327	\N	\N	\N	\N	\N	\N	\N	\N	\N	customer	other	\N	\N	2024-09-02 04:03:22.331327	4	customer	\N	f	f	\N	\N	\N
25	2024-08-23 03:58:34.622775	2024-09-02 04:07:46.580578	1	8	q\n	\N	\N	canceled	2024-09-02 04:07:46.580578	\N	\N	\N	\N	\N	\N	\N	\N	\N	customer	other	\N	\N	2024-09-02 04:07:46.580578	4	customer	\N	f	f	\N	\N	\N
30	2024-08-23 04:27:32.728119	2024-09-02 03:54:28.740468	1	8	lslslsllsllala\nmxldkdd	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	canceled	2024-09-02 03:54:28.740468	\N	\N	\N	\N	\N	\N	\N	\N	\N	customer	other	\N	\N	2024-09-02 03:54:28.740468	4	customer	\N	f	f	\N	\N	\N
38	2024-09-15 04:58:50.944261	2024-09-15 04:58:50.944261	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N
135	2024-12-01 05:05:33.545919	2024-12-01 05:07:17.228485	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	accepted	2024-12-01 05:07:17.228485	2024-12-02 09:15:00	15	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	4	customer	{"scale": 0, "amount": 150, "currency": "CLP"}	f	f	\N	\N	\N
43	2024-09-15 04:58:53.627148	2024-09-15 04:58:53.627148	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N
41	2024-09-15 04:58:52.375169	2024-09-15 04:58:52.375169	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N
44	2024-09-15 04:58:53.797238	2024-09-15 04:58:53.797238	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N
20	2024-08-23 03:31:08.359593	2024-09-02 04:20:05.135533	1	8	xd\n	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	canceled	2024-09-02 04:20:05.135533	\N	\N	\N	\N	\N	\N	\N	\N	\N	customer	other	\N	\N	2024-09-02 04:20:05.135533	4	customer	\N	f	f	\N	\N	\N
22	2024-08-23 03:41:05.770501	2024-09-02 04:25:38.056818	1	8	g\n	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	canceled	2024-09-02 04:25:38.056818	\N	\N	\N	\N	\N	\N	\N	\N	\N	customer	other	\N	\N	2024-09-02 04:25:38.056818	4	customer	\N	f	f	\N	\N	\N
45	2024-09-15 04:58:53.976603	2024-09-15 04:58:53.976603	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N
52	2024-09-15 04:58:54.966367	2024-09-15 04:58:54.966367	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N
53	2024-09-15 04:58:55.123442	2024-09-15 04:58:55.123442	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N
59	2024-09-15 04:58:55.918055	2024-09-15 04:58:55.918055	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N
116	2024-11-30 20:43:01.34924	2024-11-30 23:42:59.717138	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	rejected	2024-11-30 23:42:59.717138	\N	\N	artist	\N	other	Test additional details	2024-11-30 23:42:59.717138	\N	\N	\N	\N	\N	\N	\N	15	artist	\N	f	f	\N	\N	\N
122	2024-12-01 04:22:41.84804	2024-12-01 04:23:46.175377	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	quoted	2024-12-01 04:23:46.175377	2024-12-02 08:45:00	15	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	15	artist	{"scale": 0, "amount": 150, "currency": "CLP"}	f	f	\N	\N	\N
128	2024-12-01 04:32:45.541371	2024-12-01 04:32:45.541371	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N
129	2024-12-01 04:32:58.390161	2024-12-01 04:32:58.390161	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N
164	2024-12-02 01:56:58.624902	2024-12-02 01:57:11.107684	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	canceled	2024-12-02 01:57:11.107684	\N	\N	\N	\N	\N	\N	\N	\N	\N	customer	other	\N	\N	2024-12-02 01:57:11.107684	4	customer	\N	f	f	\N	\N	\N
225	2024-12-12 02:23:01.642364	2024-12-12 03:21:05.024845	1	8	asdadas	\N	\N	canceled	2024-12-12 03:21:05.024845	\N	\N	\N	\N	\N	\N	\N	\N	\N	customer	\N	\N	\N	2024-12-12 03:21:05.024845	4	customer	\N	f	f	\N	\N	\N
151	2024-12-02 01:18:36.655513	2024-12-13 01:49:10.325698	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	rejected	2024-12-13 01:49:10.325698	\N	\N	artist	\N	artistic_disagreement		2024-12-13 01:49:10.325698	\N	\N	\N	\N	\N	\N	\N	15	artist	\N	f	f	\N	\N	\N
144	2024-12-02 01:09:26.698919	2024-12-14 03:40:16.250651	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	rejected	2024-12-14 03:40:16.250651	\N	\N	artist	\N	artistic_disagreement		2024-12-14 03:40:16.250651	\N	\N	\N	\N	\N	\N	\N	15	artist	\N	f	f	\N	\N	\N
64	2024-09-15 04:58:56.539704	2024-09-15 04:58:56.539704	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N
65	2024-09-15 04:58:56.786527	2024-09-15 04:58:56.786527	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N
62	2024-09-15 04:58:56.374203	2024-09-15 04:58:56.374203	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N
136	2024-12-02 01:06:30.682561	2024-12-02 01:06:30.682561	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N
70	2024-09-15 04:58:57.543628	2024-09-16 03:10:50.511062	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	rejected	2024-09-16 03:10:50.511062	\N	0	artist	\N	insufficient_details		2024-09-16 03:10:50.511062	\N	\N	\N	\N	\N	\N	\N	1	artist	\N	f	f	\N	\N	\N
63	2024-09-15 04:58:56.488542	2024-09-15 04:58:56.488542	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N
68	2024-09-15 04:58:57.078022	2024-09-16 03:22:50.650955	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	rejected	2024-09-16 03:22:50.650955	\N	0	artist	\N	insufficient_details		2024-09-16 03:22:50.650955	\N	\N	\N	\N	\N	\N	\N	1	artist	\N	f	f	\N	\N	\N
18	2024-08-23 03:23:59.074837	2024-09-02 04:33:11.078061	1	8	j\n	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	canceled	2024-09-02 04:33:11.078061	\N	\N	\N	\N	\N	\N	\N	\N	\N	customer	other	\N	\N	2024-09-02 04:33:11.078061	4	customer	\N	f	f	\N	\N	\N
17	2024-08-23 03:20:53.728877	2024-09-03 02:13:50.140335	1	8	y\n	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	canceled	2024-09-03 02:13:50.140335	\N	\N	\N	\N	\N	\N	\N	\N	\N	customer	other	\N	\N	2024-09-03 02:13:50.140335	4	customer	\N	f	f	\N	\N	\N
152	2024-12-02 01:19:53.362444	2024-12-02 01:20:05.752818	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	canceled	2024-12-02 01:20:05.752818	\N	\N	\N	\N	\N	\N	\N	\N	\N	customer	other	\N	\N	2024-12-02 01:20:05.752818	4	customer	\N	f	f	\N	\N	\N
158	2024-12-02 01:44:24.350999	2024-12-02 01:45:22.424885	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	rejected	2024-12-02 01:45:22.424885	\N	\N	artist	\N	other	Test additional details	2024-12-02 01:45:22.424885	\N	\N	\N	\N	\N	\N	\N	15	artist	\N	f	f	\N	\N	\N
69	2024-09-15 04:58:57.292838	2024-09-16 03:22:21.720119	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/69/artist/1/proposed-designs/design_0", "size": 147911, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "proposedDesigns", "originalname": "design_0.jpg"}]}	quoted	2024-09-16 03:22:21.720119	2024-09-16 01:22:00	60	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	artist	{"scale": 0, "amount": 50000, "currency": "CLP"}	f	f	\N	\N	\N
9	2024-08-22 03:46:44.906062	2024-11-20 02:57:26.309641	1	3	djjdjdjkd	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	canceled	2024-11-20 02:57:26.309641	\N	\N	\N	\N	\N	\N	\N	\N	\N	customer	other	\N	\N	2024-11-20 02:57:26.309641	4	customer	\N	f	f	\N	\N	\N
117	2024-11-30 23:43:34.784119	2024-11-30 23:44:34.027967	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	rejected	2024-11-30 23:44:34.027967	\N	\N	artist	\N	other	Test additional details	2024-11-30 23:44:34.027967	\N	\N	\N	\N	\N	\N	\N	15	artist	\N	f	f	\N	\N	\N
123	2024-12-01 04:25:20.025539	2024-12-01 04:26:26.491366	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	quoted	2024-12-01 04:26:26.491366	2024-12-02 08:45:00	15	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	15	artist	{"scale": 0, "amount": 150, "currency": "CLP"}	f	f	\N	\N	\N
130	2024-12-01 04:33:17.42212	2024-12-01 04:33:32.070554	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	canceled	2024-12-01 04:33:32.070554	\N	\N	\N	\N	\N	\N	\N	\N	\N	customer	other	\N	\N	2024-12-01 04:33:32.070554	4	customer	\N	f	f	\N	\N	\N
165	2024-12-02 01:57:30.212439	2024-12-02 01:58:28.820662	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	rejected	2024-12-02 01:58:28.820662	\N	\N	artist	\N	other	Test additional details	2024-12-02 01:58:28.820662	\N	\N	\N	\N	\N	\N	\N	15	artist	\N	f	f	\N	\N	\N
173	2024-12-02 02:31:38.208314	2024-12-02 02:31:51.805898	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	canceled	2024-12-02 02:31:51.805898	\N	\N	\N	\N	\N	\N	\N	\N	\N	customer	other	\N	\N	2024-12-02 02:31:51.805898	4	customer	\N	f	f	\N	\N	\N
178	2024-12-02 03:12:39.294484	2024-12-02 03:14:35.797338	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	accepted	2024-12-02 03:14:35.797338	2024-12-03 21:15:00	15	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	4	customer	{"scale": 0, "amount": 150, "currency": "CLP"}	f	f	\N	\N	\N
183	2024-12-02 03:25:09.758138	2024-12-02 03:25:22.000641	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	canceled	2024-12-02 03:25:22.000641	\N	\N	\N	\N	\N	\N	\N	\N	\N	customer	other	\N	\N	2024-12-02 03:25:22.000641	4	customer	\N	f	f	\N	\N	\N
188	2024-12-02 03:31:47.204474	2024-12-02 03:32:45.071072	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	rejected	2024-12-02 03:32:45.071072	\N	\N	artist	\N	other	Test additional details	2024-12-02 03:32:45.071072	\N	\N	\N	\N	\N	\N	\N	15	artist	\N	f	f	\N	\N	\N
192	2024-12-04 01:34:31.378994	2024-12-04 01:34:31.378994	3	1	I want a tatto bla bla bla bla ba	{"count": 2, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/192/artist/1/reference-images/reference_0", "size": 37, "type": "image/png", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "rocket1.png"}, {"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/192/artist/1/reference-images/reference_1", "size": 37, "type": "image/png", "encoding": "7bit", "position": 1, "fieldname": "files[]", "originalname": "rocket2.png"}]}	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N
231	2024-12-12 02:32:47.234853	2024-12-14 01:33:22.802007	1	8	asdsadadas	\N	\N	canceled	2024-12-12 02:37:08.713893	\N	\N	\N	\N	\N	\N	\N	\N	\N	customer	other	\N	\N	2024-12-12 02:37:08.713893	4	customer	\N	t	t	2024-12-14 01:33:22.802007	2024-12-14 01:33:13.022241	\N
226	2024-12-12 02:24:20.650196	2024-12-12 03:19:54.526709	1	8	asdsadsad	\N	\N	canceled	2024-12-12 03:19:54.526709	\N	\N	\N	\N	\N	\N	\N	\N	\N	customer	\N	\N	\N	2024-12-12 03:19:54.526709	4	customer	\N	f	f	\N	\N	\N
153	2024-12-02 01:20:24.067183	2024-12-13 01:48:35.064118	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	rejected	2024-12-13 01:48:35.064118	\N	\N	artist	\N	artistic_disagreement		2024-12-13 01:48:35.064118	\N	\N	\N	\N	\N	\N	\N	15	artist	\N	f	f	\N	\N	\N
145	2024-12-02 01:10:16.918886	2024-12-14 02:11:44.059014	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	rejected	2024-12-14 02:11:44.059014	\N	\N	artist	\N	insufficient_details		2024-12-14 02:11:44.059014	\N	\N	\N	\N	\N	\N	\N	15	artist	\N	f	f	\N	\N	\N
248	2025-03-06 01:08:17.632789	2025-03-06 01:08:17.632789	3	1	asdasdsa	\N	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N
28	2024-08-23 04:18:36.097704	2024-09-02 03:58:08.521864	1	8	ejemplos \ndjjdjdjd\nd\nde\nd\nd\nd\n\nd	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	canceled	2024-09-02 03:58:08.521864	\N	\N	\N	\N	\N	\N	\N	\N	\N	customer	other	\N	\N	2024-09-02 03:58:08.521864	4	customer	\N	f	f	\N	\N	\N
27	2024-08-23 04:12:24.730255	2024-09-02 04:03:09.780408	1	8	dnjdjd	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	canceled	2024-09-02 04:03:09.780408	\N	\N	\N	\N	\N	\N	\N	\N	\N	customer	other	\N	\N	2024-09-02 04:03:09.780408	4	customer	\N	f	f	\N	\N	\N
24	2024-08-23 03:53:19.752031	2024-09-02 04:12:38.015529	1	8	q\n	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	canceled	2024-09-02 04:12:38.015529	\N	\N	\N	\N	\N	\N	\N	\N	\N	customer	other	\N	\N	2024-09-02 04:12:38.015529	4	customer	\N	f	f	\N	\N	\N
29	2024-08-23 04:19:14.623966	2024-09-02 04:19:53.317099	1	8	esto es un ejemplo de descripción 	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	canceled	2024-09-02 04:19:53.317099	\N	\N	\N	\N	\N	\N	\N	\N	\N	customer	other	\N	\N	2024-09-02 04:19:53.317099	4	customer	\N	f	f	\N	\N	\N
74	2024-09-15 04:58:58.074581	2024-09-15 23:05:46.423641	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	rejected	2024-09-15 23:05:46.423641	\N	0	artist	\N	artistic_disagreement		2024-09-15 23:05:46.423641	\N	\N	\N	\N	\N	\N	\N	1	artist	\N	f	f	\N	\N	\N
23	2024-08-23 03:49:34.903059	2024-09-02 04:29:01.881133	1	8	q	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	canceled	2024-09-02 04:29:01.881133	\N	\N	\N	\N	\N	\N	\N	\N	\N	customer	other	\N	\N	2024-09-02 04:29:01.881133	4	customer	\N	f	f	\N	\N	\N
21	2024-08-23 03:35:19.525674	2024-09-02 04:32:32.870413	1	8	q\n	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	canceled	2024-09-02 04:32:32.870413	\N	\N	\N	\N	\N	\N	\N	\N	\N	customer	other	\N	\N	2024-09-02 04:32:32.870413	4	customer	\N	f	f	\N	\N	\N
19	2024-08-23 03:26:10.148782	2024-09-02 04:32:44.226685	1	8	w\n	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	canceled	2024-09-02 04:32:44.226685	\N	\N	\N	\N	\N	\N	\N	\N	\N	customer	other	\N	\N	2024-09-02 04:32:44.226685	4	customer	\N	f	f	\N	\N	\N
137	2024-12-02 01:06:59.739852	2024-12-02 01:07:15.92576	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	canceled	2024-12-02 01:07:15.92576	\N	\N	\N	\N	\N	\N	\N	\N	\N	customer	other	\N	\N	2024-12-02 01:07:15.92576	4	customer	\N	f	f	\N	\N	\N
33	2024-09-14 21:07:03.835709	2024-09-15 03:54:21.491803	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	quoted	2024-09-15 03:54:21.491803	2024-09-15 01:54:00	60	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	artist	\N	f	f	\N	\N	\N
36	2024-09-14 21:07:16.459737	2024-09-15 03:36:52.87781	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/36/artist/1/proposed-designs/design_0", "size": 5619070, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "proposedDesigns", "originalname": "design_0.jpg"}]}	quoted	2024-09-15 03:36:52.87781	2024-09-15 14:36:00	60	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	artist	\N	f	f	\N	\N	\N
37	2024-09-14 21:07:19.796047	2024-09-14 21:32:41.867685	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	quoted	2024-09-14 21:32:41.867685	2024-09-14 19:31:00	60	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	artist	\N	f	f	\N	\N	\N
35	2024-09-14 21:07:12.403848	2024-09-15 03:30:26.737254	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	quoted	2024-09-15 03:30:26.737254	2024-09-17 02:31:00	60	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	artist	\N	f	f	\N	\N	\N
10	2024-08-22 03:47:33.818354	2024-09-12 03:20:17.925579	1	8	ejemplo	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	quoted	2024-09-12 03:20:17.925579	2024-09-24 09:19:00	120	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	15	artist	{"scale": 0, "amount": 50000, "currency": "CLP"}	f	f	\N	\N	\N
159	2024-12-02 01:47:17.156595	2024-12-02 01:49:03.128949	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	accepted	2024-12-02 01:49:03.128949	2024-12-02 21:00:00	15	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	4	customer	{"scale": 0, "amount": 150, "currency": "CLP"}	f	f	\N	\N	\N
167	2024-12-02 01:59:01.617677	2024-12-02 01:59:08.128348	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	canceled	2024-12-02 01:59:08.128348	\N	\N	\N	\N	\N	\N	\N	\N	\N	customer	other	\N	\N	2024-12-02 01:59:08.128348	4	customer	\N	f	f	\N	\N	\N
146	2024-12-02 01:12:17.651594	2024-12-14 02:10:51.088458	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	rejected	2024-12-14 02:10:51.088458	\N	\N	artist	\N	artistic_disagreement		2024-12-14 02:10:51.088458	\N	\N	\N	\N	\N	\N	\N	15	artist	\N	f	f	\N	\N	\N
174	2024-12-02 02:32:16.688893	2024-12-02 02:33:14.659356	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	rejected	2024-12-02 02:33:14.659356	\N	\N	artist	\N	other	Test additional details	2024-12-02 02:33:14.659356	\N	\N	\N	\N	\N	\N	\N	15	artist	\N	f	f	\N	\N	\N
180	2024-12-02 03:22:44.402769	2024-12-02 03:22:48.059842	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	canceled	2024-12-02 03:22:48.059842	\N	\N	\N	\N	\N	\N	\N	\N	\N	customer	other	\N	\N	2024-12-02 03:22:48.059842	4	customer	\N	f	f	\N	\N	\N
184	2024-12-02 03:25:41.335681	2024-12-02 03:26:40.51477	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	rejected	2024-12-02 03:26:40.51477	\N	\N	artist	\N	other	Test additional details	2024-12-02 03:26:40.51477	\N	\N	\N	\N	\N	\N	\N	15	artist	\N	f	f	\N	\N	\N
39	2024-09-15 04:58:51.321699	2024-09-15 04:58:51.321699	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N
249	2025-03-06 01:10:57.207472	2025-03-06 01:10:57.207472	3	1	12313	\N	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N
261	2025-03-07 02:10:08.248395	2025-03-07 02:10:43.239824	3	9	asdada	\N	\N	rejected	2025-03-07 02:10:29.508052	\N	\N	artist	\N	insufficient_details		2025-03-07 02:10:29.508052	\N	\N	\N	\N	\N	\N	\N	29	artist	\N	t	f	2025-03-07 02:10:43.239824	\N	\N
51	2024-09-15 04:58:54.814486	2024-09-15 04:58:54.814486	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N
57	2024-09-15 04:58:55.591567	2024-09-15 04:58:55.591567	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N
58	2024-09-15 04:58:55.823367	2024-09-15 04:58:55.823367	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N
66	2024-09-15 04:58:56.821306	2024-09-15 04:58:56.821306	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N
138	2024-12-02 01:07:31.249714	2024-12-02 01:07:31.249714	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N
42	2024-09-15 04:58:53.173262	2024-09-15 04:58:53.173262	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N
46	2024-09-15 04:58:54.260237	2024-09-15 04:58:54.260237	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N
47	2024-09-15 04:58:54.254972	2024-09-15 04:58:54.254972	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N
48	2024-09-15 04:58:54.355304	2024-09-15 04:58:54.355304	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N
49	2024-09-15 04:58:54.580356	2024-09-15 04:58:54.580356	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N
50	2024-09-15 04:58:54.708226	2024-09-15 04:58:54.708226	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N
54	2024-09-15 04:58:55.196444	2024-09-15 04:58:55.196444	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N
55	2024-09-15 04:58:55.385053	2024-09-15 04:58:55.385053	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N
56	2024-09-15 04:58:55.440861	2024-09-15 04:58:55.440861	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N
60	2024-09-15 04:58:56.009994	2024-09-15 04:58:56.009994	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N
61	2024-09-15 04:58:56.223341	2024-09-15 04:58:56.223341	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N
72	2024-09-15 04:58:57.883113	2024-09-16 02:08:59.715166	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	rejected	2024-09-16 02:08:59.715166	\N	0	artist	\N	other		2024-09-16 02:08:59.715166	\N	\N	\N	\N	\N	\N	\N	1	artist	\N	f	f	\N	\N	\N
113	2024-11-30 20:35:21.438586	2024-11-30 23:46:15.999982	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	rejected	2024-11-30 23:46:15.999982	\N	\N	artist	\N	other	asdsadad	2024-11-30 23:46:15.999982	\N	\N	\N	\N	\N	\N	\N	15	artist	\N	f	f	\N	\N	\N
124	2024-12-01 04:28:25.600046	2024-12-01 04:28:25.600046	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N
131	2024-12-01 04:33:41.439797	2024-12-01 04:34:42.382599	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	rejected	2024-12-01 04:34:42.382599	\N	\N	artist	\N	other	Test additional details	2024-12-01 04:34:42.382599	\N	\N	\N	\N	\N	\N	\N	15	artist	\N	f	f	\N	\N	\N
139	2024-12-02 01:07:34.970064	2024-12-02 01:08:34.421631	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	rejected	2024-12-02 01:08:34.421631	\N	\N	artist	\N	other	Test additional details	2024-12-02 01:08:34.421631	\N	\N	\N	\N	\N	\N	\N	15	artist	\N	f	f	\N	\N	\N
67	2024-09-15 04:58:57.020302	2024-09-20 17:50:56.738516	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	rejected	2024-09-20 17:50:56.738516	\N	0	artist	\N	artistic_disagreement		2024-09-20 17:50:56.738516	\N	\N	\N	\N	\N	\N	\N	1	artist	\N	f	f	\N	\N	\N
140	2024-12-02 01:07:59.868927	2024-12-02 01:07:59.868927	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N
154	2024-12-02 01:21:40.728314	2024-12-02 01:22:38.87474	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	rejected	2024-12-02 01:22:38.87474	\N	\N	artist	\N	other	Test additional details	2024-12-02 01:22:38.87474	\N	\N	\N	\N	\N	\N	\N	15	artist	\N	f	f	\N	\N	\N
148	2024-12-02 01:13:14.492626	2024-12-13 02:58:38.572473	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	rejected	2024-12-13 02:58:38.572473	\N	\N	artist	\N	insufficient_details	adasda	2024-12-13 02:58:38.572473	\N	\N	\N	\N	\N	\N	\N	15	artist	\N	f	f	\N	\N	\N
244	2024-12-22 00:15:09.540004	2024-12-22 00:18:19.196466	26	10	hola! quiero realizarme un tatto de 20x10	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/244/artist/10/reference-images/reference_0", "size": 4854620, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	accepted	2024-12-22 00:17:48.352191	2025-01-14 16:16:00	60	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	37	customer	{"scale": 0, "amount": 50, "currency": "CLP"}	t	f	2024-12-22 00:18:19.196466	\N	\N
181	2024-12-02 03:23:06.988453	2024-12-02 03:24:13.635958	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	rejected	2024-12-02 03:24:13.635958	\N	\N	artist	\N	other	Test additional details	2024-12-02 03:24:13.635958	\N	\N	\N	\N	\N	\N	\N	15	artist	\N	f	f	\N	\N	\N
185	2024-12-02 03:27:54.669802	2024-12-02 03:28:07.227354	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	canceled	2024-12-02 03:28:07.227354	\N	\N	\N	\N	\N	\N	\N	\N	\N	customer	other	\N	\N	2024-12-02 03:28:07.227354	4	customer	\N	f	f	\N	\N	\N
83	2024-10-20 02:48:58.358766	2024-10-27 18:49:25.386346	1	8	opppa	\N	\N	canceled	2024-10-27 18:49:25.386346	\N	\N	\N	\N	\N	\N	\N	\N	\N	customer	other	\N	\N	2024-10-27 18:49:25.386346	4	customer	\N	f	f	\N	\N	\N
84	2024-10-27 18:50:08.624	2024-10-27 18:50:31.840535	1	1	ejemplo 1	\N	\N	canceled	2024-10-27 18:50:31.840535	\N	\N	\N	\N	\N	\N	\N	\N	\N	customer	other	\N	\N	2024-10-27 18:50:31.840535	4	customer	\N	f	f	\N	\N	\N
85	2024-10-27 18:55:18.559945	2024-10-27 18:55:34.832549	1	1	asdasdfasd	\N	\N	rejected	2024-10-27 18:55:34.832549	\N	0	artist	\N	scheduling_conflict		2024-10-27 18:55:34.832549	\N	\N	\N	\N	\N	\N	\N	1	artist	\N	f	f	\N	\N	\N
86	2024-10-27 19:30:16.564295	2024-10-28 01:48:11.623327	1	1	ejemplxx	\N	\N	accepted	2024-10-28 01:48:11.623327	2024-11-06 18:30:00	0	\N	\N	\N	\N	\N	\N	2024-10-27 19:31:00.823381	\N	\N	\N	\N	\N	1	artist	{"scale": 0, "amount": 50000, "currency": "CLP"}	f	f	\N	\N	\N
87	2024-11-04 02:11:10.06657	2024-11-20 02:55:56.64279	1	1	example y weas	\N	\N	canceled	2024-11-20 02:55:56.64279	\N	\N	\N	\N	\N	\N	\N	\N	\N	customer	other	\N	\N	2024-11-20 02:55:56.64279	4	customer	\N	f	f	\N	\N	\N
118	2024-11-30 23:57:23.465426	2024-11-30 23:58:24.303266	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	rejected	2024-11-30 23:58:24.303266	\N	\N	artist	\N	other	Test additional details	2024-11-30 23:58:24.303266	\N	\N	\N	\N	\N	\N	\N	15	artist	\N	f	f	\N	\N	\N
232	2024-12-14 01:38:34.938559	2024-12-14 01:44:47.878625	1	8	quioro un tatto	\N	\N	canceled	2024-12-14 01:44:47.878625	\N	\N	\N	\N	\N	\N	\N	\N	\N	customer	\N	\N	\N	2024-12-14 01:44:47.878625	4	customer	\N	t	t	2024-12-14 01:44:35.189516	2024-12-14 01:39:49.23092	\N
193	2024-12-04 01:36:10.784756	2024-12-04 01:36:10.784756	3	1	I want a tatto bla bla bla bla ba	{"count": 2, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/193/artist/1/reference-images/reference_0", "size": 37, "type": "image/png", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "rocket1.png"}, {"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/193/artist/1/reference-images/reference_1", "size": 37, "type": "image/png", "encoding": "7bit", "position": 1, "fieldname": "files[]", "originalname": "rocket2.png"}]}	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N
196	2024-12-04 01:43:21.045749	2024-12-04 01:43:21.045749	3	1	I want a tatto bla bla bla bla ba	{"count": 2, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/196/artist/1/reference-images/reference_0", "size": 37, "type": "image/png", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "rocket1.png"}, {"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/196/artist/1/reference-images/reference_1", "size": 37, "type": "image/png", "encoding": "7bit", "position": 1, "fieldname": "files[]", "originalname": "rocket2.png"}]}	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N
125	2024-12-01 04:29:02.300369	2024-12-01 04:30:03.058264	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	rejected	2024-12-01 04:30:03.058264	\N	\N	artist	\N	other	Test additional details	2024-12-01 04:30:03.058264	\N	\N	\N	\N	\N	\N	\N	15	artist	\N	f	f	\N	\N	\N
132	2024-12-01 04:35:00.491566	2024-12-01 04:36:07.046215	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	quoted	2024-12-01 04:36:07.046215	2024-12-02 09:00:00	15	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	15	artist	{"scale": 0, "amount": 150, "currency": "CLP"}	f	f	\N	\N	\N
199	2024-12-04 01:55:58.495762	2024-12-04 01:55:58.495762	1	1	I want a tatto bla bla bla bla ba	{"count": 2, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/199/artist/1/reference-images/reference_0", "size": 37, "type": "image/png", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "rocket1.png"}, {"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/199/artist/1/reference-images/reference_1", "size": 37, "type": "image/png", "encoding": "7bit", "position": 1, "fieldname": "files[]", "originalname": "rocket2.png"}]}	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N
203	2024-12-04 02:12:29.426362	2024-12-04 02:12:29.426362	1	1	I want a tatto bla bla bla bla ba	{"count": 2, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/203/artist/1/reference-images/reference_0", "size": 37, "type": "image/png", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "rocket1.png"}, {"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/203/artist/1/reference-images/reference_1", "size": 37, "type": "image/png", "encoding": "7bit", "position": 1, "fieldname": "files[]", "originalname": "rocket2.png"}]}	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N
227	2024-12-12 02:25:27.671456	2024-12-12 03:19:33.509712	1	8	asdada	\N	\N	canceled	2024-12-12 03:19:33.509712	\N	\N	\N	\N	\N	\N	\N	\N	\N	customer	\N	\N	\N	2024-12-12 03:19:33.509712	4	customer	\N	f	f	\N	\N	\N
189	2024-12-02 03:33:19.553595	2024-12-14 01:37:42.563949	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	accepted	2024-12-02 03:35:09.047121	2024-12-03 21:00:00	15	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	4	customer	{"scale": 0, "amount": 150, "currency": "CLP"}	t	f	2024-12-14 01:37:42.563949	\N	\N
160	2024-12-02 01:49:32.304431	2024-12-17 02:47:57.140547	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	accepted	2024-12-17 02:47:57.140547	2024-12-02 20:45:00	15	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	4	customer	{"scale": 0, "amount": 150, "currency": "CLP"}	f	f	\N	\N	\N
236	2024-12-14 03:46:19.095372	2024-12-14 03:52:56.37862	1	8	asdadsada	\N	\N	rejected	2024-12-14 03:46:30.468633	\N	\N	artist	\N	insufficient_details	111111	2024-12-14 03:46:30.468633	\N	\N	\N	\N	\N	\N	\N	15	artist	\N	t	f	2024-12-14 03:52:56.37862	\N	\N
239	2024-12-20 03:36:41.271677	2024-12-20 03:55:13.121637	3	1	holis	\N	\N	accepted	2024-12-20 03:41:49.331365	2024-12-20 04:41:00	60	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	6	customer	{"scale": 0, "amount": 50, "currency": "CLP"}	t	t	2024-12-20 03:46:51.264011	2024-12-20 03:55:13.121637	\N
71	2024-09-15 04:58:57.616667	2024-12-20 03:46:47.582659	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	quoted	2024-09-16 02:13:11.029973	2024-09-16 17:13:00	357	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	artist	{"scale": 0, "amount": 50000, "currency": "CLP"}	t	f	2024-12-20 03:46:47.582659	\N	\N
141	2024-12-02 01:08:28.578569	2024-12-02 01:08:28.578569	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N
161	2024-12-02 01:51:10.798705	2024-12-02 01:52:09.019873	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	rejected	2024-12-02 01:52:09.019873	\N	\N	artist	\N	other	Test additional details	2024-12-02 01:52:09.019873	\N	\N	\N	\N	\N	\N	\N	15	artist	\N	f	f	\N	\N	\N
170	2024-12-02 02:00:41.727949	2024-12-02 02:01:39.474225	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	rejected	2024-12-02 02:01:39.474225	\N	\N	artist	\N	other	Test additional details	2024-12-02 02:01:39.474225	\N	\N	\N	\N	\N	\N	\N	15	artist	\N	f	f	\N	\N	\N
176	2024-12-02 02:35:23.223433	2024-12-14 01:35:43.111647	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	accepted	2024-12-14 01:35:43.111647	2024-12-12 23:46:53.686	60	\N	\N	\N	\N	\N	\N	2024-12-13 01:56:01.972607	\N	\N	\N	\N	\N	4	customer	{"scale": 0, "amount": 123, "currency": "CLP"}	f	t	\N	2024-12-14 01:35:40.418207	\N
179	2024-12-02 03:22:35.054557	2024-12-02 03:24:40.696262	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	accepted	2024-12-02 03:24:40.696262	2024-12-03 21:15:00	15	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	4	customer	{"scale": 0, "amount": 150, "currency": "CLP"}	f	f	\N	\N	\N
250	2025-03-06 01:12:18.429835	2025-03-06 01:12:18.429835	3	9	dasda	\N	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N
16	2024-08-23 03:19:29.617101	2024-11-20 02:57:44.10209	1	8	Prueba de cotizacion 1	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/16/artist/8/proposed-designs/design_0", "size": 2481850, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "proposedDesigns", "originalname": "design_0.jpg"}]}	accepted	2024-11-20 02:57:44.10209	2024-11-12 21:11:00	120	\N	\N	\N	\N	\N	\N	2024-11-11 02:52:51.410946	\N	\N	\N	\N	\N	4	customer	{"scale": 0, "amount": 40, "currency": "CLP"}	f	f	\N	\N	\N
119	2024-12-01 00:00:12.051964	2024-12-01 00:01:11.425911	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	rejected	2024-12-01 00:01:11.425911	\N	\N	artist	\N	other	Test additional details	2024-12-01 00:01:11.425911	\N	\N	\N	\N	\N	\N	\N	15	artist	\N	f	f	\N	\N	\N
15	2024-08-23 03:18:03.83863	2024-10-21 01:39:27.374201	1	8	g\n	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/15/artist/8/proposed-designs/design_0", "size": 2454907, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "proposedDesigns", "originalname": "design_0.jpg"}]}	rejected	2024-10-21 01:39:27.374201	2024-09-25 21:00:00	\N	customer	too_expensive	\N	muy caro man	2024-10-21 01:39:27.374201	\N	\N	\N	\N	\N	\N	\N	4	customer	{"scale": 0, "amount": 50000, "currency": "CLP"}	f	f	\N	\N	\N
14	2024-08-23 03:16:31.393674	2024-10-21 01:39:57.536438	1	8	jkdjd	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	accepted	2024-10-21 01:39:57.536438	2024-09-22 21:00:00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	4	customer	{"scale": 0, "amount": 50000, "currency": "CLP"}	f	f	\N	\N	\N
126	2024-12-01 04:30:23.57265	2024-12-01 04:31:29.088795	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	quoted	2024-12-01 04:31:29.088795	2024-12-02 08:45:00	15	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	15	artist	{"scale": 0, "amount": 150, "currency": "CLP"}	f	f	\N	\N	\N
186	2024-12-02 03:28:27.601279	2024-12-02 03:29:25.328336	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	rejected	2024-12-02 03:29:25.328336	\N	\N	artist	\N	other	Test additional details	2024-12-02 03:29:25.328336	\N	\N	\N	\N	\N	\N	\N	15	artist	\N	f	f	\N	\N	\N
133	2024-12-01 04:46:21.151773	2024-12-01 05:02:41.235276	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	accepted	2024-12-01 05:02:41.235276	2024-12-02 09:00:00	15	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	4	customer	{"scale": 0, "amount": 150, "currency": "CLP"}	f	f	\N	\N	\N
190	2024-12-03 23:29:58.072995	2024-12-03 23:30:05.937485	1	9	asdsa	\N	\N	canceled	2024-12-03 23:30:05.937485	\N	\N	\N	\N	\N	\N	\N	\N	\N	customer	other	\N	\N	2024-12-03 23:30:05.937485	4	customer	\N	f	f	\N	\N	\N
194	2024-12-04 01:40:37.688636	2024-12-04 01:40:37.688636	3	1	I want a tatto bla bla bla bla ba	{"count": 2, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/194/artist/1/reference-images/reference_0", "size": 37, "type": "image/png", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "rocket1.png"}, {"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/194/artist/1/reference-images/reference_1", "size": 37, "type": "image/png", "encoding": "7bit", "position": 1, "fieldname": "files[]", "originalname": "rocket2.png"}]}	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N
245	2024-12-22 00:20:40.007918	2024-12-22 00:22:11.493705	25	12	Visión board \nAHORA	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/245/artist/12/reference-images/reference_0", "size": 1301382, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	2024-12-22 00:22:11.493705	\N	\N
200	2024-12-04 01:57:38.860138	2024-12-04 01:57:38.860138	1	1	I want a tatto bla bla bla bla ba	{"count": 2, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/200/artist/1/reference-images/reference_0", "size": 37, "type": "image/png", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "rocket1.png"}, {"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/200/artist/1/reference-images/reference_1", "size": 37, "type": "image/png", "encoding": "7bit", "position": 1, "fieldname": "files[]", "originalname": "rocket2.png"}]}	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N
204	2024-12-04 02:15:19.960495	2024-12-04 02:15:19.960495	1	1	I want a tatto bla bla bla bla ba	{"count": 2, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/204/artist/1/reference-images/reference_0", "size": 37, "type": "image/png", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "rocket1.png"}, {"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/204/artist/1/reference-images/reference_1", "size": 37, "type": "image/png", "encoding": "7bit", "position": 1, "fieldname": "files[]", "originalname": "rocket2.png"}]}	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N
228	2024-12-12 02:27:37.426408	2024-12-12 03:18:47.938881	1	8	asdada	\N	\N	canceled	2024-12-12 03:18:47.938881	\N	\N	\N	\N	\N	\N	\N	\N	\N	customer	\N	\N	\N	2024-12-12 03:18:47.938881	4	customer	\N	f	f	\N	\N	\N
149	2024-12-02 01:13:44.064781	2024-12-13 02:47:08.811388	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	rejected	2024-12-13 02:47:08.811388	\N	\N	artist	\N	artistic_disagreement	asdsad	2024-12-13 02:47:08.811388	\N	\N	\N	\N	\N	\N	\N	15	artist	\N	f	f	\N	\N	\N
233	2024-12-14 02:03:05.87933	2024-12-14 02:04:28.821329	1	8	adasdsa	\N	\N	canceled	2024-12-14 02:03:42.434909	\N	\N	\N	\N	\N	\N	\N	\N	\N	customer	\N	\N	\N	2024-12-14 02:03:42.434909	4	customer	\N	t	t	2024-12-14 02:03:30.555557	2024-12-14 02:04:28.821329	\N
237	2024-12-15 22:36:42.063074	2024-12-17 00:38:53.450458	1	8	adsada	\N	\N	canceled	2024-12-17 00:38:41.195095	\N	\N	\N	\N	\N	\N	\N	\N	\N	customer	\N	\N	\N	2024-12-17 00:38:41.195095	4	customer	\N	f	t	\N	2024-12-17 00:38:53.450458	\N
240	2024-12-20 03:37:57.959468	2024-12-20 03:40:46.064989	3	1	hola mundo	\N	\N	rejected	2024-12-20 03:40:46.064989	\N	\N	artist	\N	insufficient_details	nope	2024-12-20 03:40:46.064989	\N	\N	\N	\N	\N	\N	\N	1	artist	\N	f	f	\N	\N	\N
142	2024-12-02 01:08:57.298586	2024-12-02 01:08:57.298586	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N
201	2024-12-04 02:09:34.493471	2024-12-04 02:09:34.493471	1	1	I want a tatto bla bla bla bla ba	{"count": 2, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/201/artist/1/reference-images/reference_0", "size": 37, "type": "image/png", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "rocket1.png"}, {"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/201/artist/1/reference-images/reference_1", "size": 37, "type": "image/png", "encoding": "7bit", "position": 1, "fieldname": "files[]", "originalname": "rocket2.png"}]}	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N
163	2024-12-02 01:56:41.008869	2024-12-02 01:58:26.652954	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	accepted	2024-12-02 01:58:26.652954	2024-12-02 20:45:00	15	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	4	customer	{"scale": 0, "amount": 150, "currency": "CLP"}	f	f	\N	\N	\N
31	2024-09-14 21:06:50.374983	2024-09-15 04:56:18.057887	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	quoted	2024-09-15 04:56:18.057887	2024-09-15 02:56:00	60	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	artist	{"scale": 0, "amount": 50000, "currency": "CLP"}	f	f	\N	\N	\N
251	2025-03-06 01:19:57.845019	2025-03-06 01:19:57.845019	3	9	asdad	\N	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N
32	2024-09-14 21:07:01.582281	2024-09-15 04:55:14.892063	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	quoted	2024-09-15 04:55:14.892063	2024-09-15 02:55:00	60	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	artist	{"scale": 0, "amount": 50000, "currency": "CLP"}	f	f	\N	\N	\N
75	2024-09-15 04:58:58.201617	2024-09-15 05:25:00.539654	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	quoted	2024-09-15 05:25:00.539654	2024-09-15 05:24:00	60	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	artist	{"scale": 0, "amount": 50000, "currency": "CLP"}	f	f	\N	\N	\N
13	2024-08-23 03:15:59.952299	2024-11-11 01:09:42.117134	1	8	y\n	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	rejected	2024-11-11 01:09:42.117134	2024-09-22 21:00:00	0	artist	\N	\N	lo siento bro no Tengo tiempo	2024-11-11 01:09:42.117134	\N	2024-11-04 02:06:02.653841	\N	\N	\N	\N	\N	15	artist	{"scale": 0, "amount": 0, "currency": "CLP"}	f	f	\N	\N	\N
121	2024-12-01 00:50:11.77186	2024-12-01 04:19:59.509804	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	quoted	2024-12-01 04:19:59.509804	2024-12-02 08:45:00	15	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	15	artist	{"scale": 0, "amount": 150, "currency": "CLP"}	f	f	\N	\N	\N
127	2024-12-01 04:32:07.094927	2024-12-01 04:32:07.094927	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N
187	2024-12-02 03:31:15.536618	2024-12-02 03:31:28.011099	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	canceled	2024-12-02 03:31:28.011099	\N	\N	\N	\N	\N	\N	\N	\N	\N	customer	other	\N	\N	2024-12-02 03:31:28.011099	4	customer	\N	f	f	\N	\N	\N
182	2024-12-02 03:24:44.930407	2024-12-03 23:26:14.43989	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	canceled	2024-12-03 23:26:14.43989	\N	\N	\N	\N	\N	\N	\N	\N	\N	customer	other	\N	\N	2024-12-03 23:26:14.43989	4	customer	\N	f	f	\N	\N	\N
177	2024-12-02 03:07:04.473806	2024-12-03 23:28:36.768494	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	canceled	2024-12-03 23:28:36.768494	\N	\N	\N	\N	\N	\N	\N	\N	\N	customer	other	\N	\N	2024-12-03 23:28:36.768494	4	customer	\N	f	f	\N	\N	\N
191	2024-12-04 01:32:54.8928	2024-12-04 01:32:54.8928	3	1	I want a tatto bla bla bla bla ba	{"count": 2, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/191/artist/1/reference-images/reference_0", "size": 37, "type": "image/png", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "rocket1.png"}, {"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/191/artist/1/reference-images/reference_1", "size": 37, "type": "image/png", "encoding": "7bit", "position": 1, "fieldname": "files[]", "originalname": "rocket2.png"}]}	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N
195	2024-12-04 01:41:05.435435	2024-12-04 01:41:05.435435	3	1	I want a tatto bla bla bla bla ba	{"count": 2, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/195/artist/1/reference-images/reference_0", "size": 37, "type": "image/png", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "rocket1.png"}, {"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/195/artist/1/reference-images/reference_1", "size": 37, "type": "image/png", "encoding": "7bit", "position": 1, "fieldname": "files[]", "originalname": "rocket2.png"}]}	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N
198	2024-12-04 01:47:01.424179	2024-12-04 01:47:01.424179	1	1	I want a tatto bla bla bla bla ba	{"count": 2, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/198/artist/1/reference-images/reference_0", "size": 37, "type": "image/png", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "rocket1.png"}, {"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/198/artist/1/reference-images/reference_1", "size": 37, "type": "image/png", "encoding": "7bit", "position": 1, "fieldname": "files[]", "originalname": "rocket2.png"}]}	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N
205	2024-12-04 02:17:13.82433	2024-12-04 02:17:13.82433	1	1	I want a tatto bla bla bla bla ba	{"count": 2, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/205/artist/1/reference-images/reference_0", "size": 37, "type": "image/png", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "rocket1.png"}, {"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/205/artist/1/reference-images/reference_1", "size": 37, "type": "image/png", "encoding": "7bit", "position": 1, "fieldname": "files[]", "originalname": "rocket2.png"}]}	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N
229	2024-12-12 02:30:40.300114	2024-12-12 03:17:41.183873	1	8	asdasdasda	\N	\N	canceled	2024-12-12 03:17:41.183873	\N	\N	\N	\N	\N	\N	\N	\N	\N	customer	\N	\N	\N	2024-12-12 03:17:41.183873	4	customer	\N	f	f	\N	\N	\N
224	2024-12-12 02:22:15.024443	2024-12-12 03:21:58.685049	1	8	asdsada	\N	\N	canceled	2024-12-12 03:21:58.685049	\N	\N	\N	\N	\N	\N	\N	\N	\N	customer	\N	\N	\N	2024-12-12 03:21:58.685049	4	customer	\N	f	f	\N	\N	\N
223	2024-12-09 01:58:30.225734	2024-12-12 03:22:11.079997	1	8	adfasdad	\N	\N	canceled	2024-12-12 03:22:11.079997	\N	\N	\N	\N	\N	\N	\N	\N	\N	customer	\N	\N	\N	2024-12-12 03:22:11.079997	4	customer	\N	f	f	\N	\N	\N
134	2024-12-01 05:03:18.578012	2024-12-17 02:48:43.100351	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	accepted	2024-12-17 02:48:43.100351	2024-12-02 09:00:00	15	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	4	customer	{"scale": 0, "amount": 150, "currency": "CLP"}	f	f	\N	\N	\N
172	2024-12-02 02:31:08.645845	2024-12-13 01:56:41.807889	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	rejected	2024-12-13 01:56:41.807889	2024-12-12 01:00:00	15	customer	changed_my_mind	\N	asdsadsa	2024-12-13 01:56:41.807889	\N	\N	\N	\N	\N	\N	\N	4	customer	{"scale": 0, "amount": 4, "currency": "CLP"}	f	f	\N	\N	\N
234	2024-12-14 02:08:03.468732	2024-12-14 02:09:05.505481	1	8	jfjsjj1111	\N	\N	canceled	2024-12-14 02:09:05.505481	\N	\N	\N	\N	\N	\N	\N	\N	\N	customer	\N	\N	\N	2024-12-14 02:09:05.505481	4	customer	\N	f	f	\N	\N	\N
156	2024-12-02 01:41:51.437388	2024-12-17 02:46:32.726331	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	accepted	2024-12-17 02:46:32.726331	2024-12-12 22:46:32.783	60	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	4	customer	{"scale": 0, "amount": 50, "currency": "CLP"}	f	f	\N	\N	\N
5	2024-08-22 03:25:37.328466	2024-09-12 03:21:12.610153	1	8	ejemplo prueba 	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/5/artist/8/proposed-designs/design_0", "size": 249394, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "proposedDesigns", "originalname": "design_0.jpg"}]}	quoted	2024-09-12 03:21:12.610153	2024-09-23 18:20:00	60	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	15	artist	{"scale": 0, "amount": 50000, "currency": "CLP"}	f	f	\N	\N	\N
94	2024-11-30 16:33:07.521088	2024-11-30 16:33:07.521088	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N
209	2024-12-04 02:24:13.898225	2024-12-20 03:45:49.421639	1	1	I want a tatto bla bla bla bla ba	{"count": 2, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/209/artist/1/reference-images/reference_0", "size": 37, "type": "image/png", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "rocket1.png"}, {"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/209/artist/1/reference-images/reference_1", "size": 37, "type": "image/png", "encoding": "7bit", "position": 1, "fieldname": "files[]", "originalname": "rocket2.png"}]}	\N	rejected	2024-12-20 03:45:49.421639	\N	\N	artist	\N	insufficient_details	noned	2024-12-20 03:45:49.421639	\N	\N	\N	\N	\N	\N	\N	1	artist	\N	f	f	\N	\N	\N
252	2025-03-06 02:23:12.443521	2025-03-06 02:23:12.443521	3	9	adsadas	\N	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N
4	2024-06-21 03:20:29.929902	2024-09-14 06:15:19.540943	1	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	{"count": 2, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/4/artist/1/proposed-designs/design_0", "size": 5619070, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "proposedDesigns", "originalname": "design_0.jpg"}, {"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/4/artist/1/proposed-designs/design_1", "size": 4933462, "type": "image/jpeg", "encoding": "7bit", "position": 1, "fieldname": "proposedDesigns", "originalname": "design_1.jpg"}]}	quoted	2024-09-14 06:15:19.540943	2024-09-14 19:00:00	60	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	artist	{"scale": 0, "amount": 50000, "currency": "CLP"}	f	f	\N	\N	\N
76	2024-09-15 04:58:58.31526	2024-09-15 05:07:11.292051	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	quoted	2024-09-15 05:07:11.292051	2024-09-15 05:06:00	60	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	artist	{"scale": 0, "amount": 50000, "currency": "CLP"}	f	f	\N	\N	\N
73	2024-09-15 04:58:57.887294	2024-09-16 01:11:02.667611	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	quoted	2024-09-16 01:11:02.667611	2024-09-15 23:10:00	60	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	artist	{"scale": 0, "amount": 50000, "currency": "CLP"}	f	f	\N	\N	\N
95	2024-11-30 16:35:07.484249	2024-11-30 16:35:07.484249	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N
11	2024-08-23 03:08:07.0258	2024-11-20 03:00:05.979121	1	1	ejmplo	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/1/proposed-designs/design_0", "size": 4933462, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "proposedDesigns", "originalname": "design_0.jpg"}]}	rejected	2024-11-20 03:00:05.979121	2024-09-14 04:11:00	60	customer	not_what_i_wanted	\N	asdad	2024-11-20 03:00:05.979121	\N	\N	\N	\N	\N	\N	\N	4	customer	{"scale": 0, "amount": 50000, "currency": "CLP"}	f	f	\N	\N	\N
12	2024-08-23 03:13:47.87426	2024-11-21 01:36:11.026835	1	8	yyy	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/12/artist/8/proposed-designs/design_0", "size": 2495405, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "proposedDesigns", "originalname": "design_0.jpg"}]}	rejected	2024-11-21 01:36:11.026835	2024-09-30 17:24:00	120	artist	\N	\N		2024-11-21 01:36:11.026835	\N	2024-11-20 02:59:54.701363	\N	\N	\N	\N	\N	15	artist	{"scale": 0, "amount": 50000, "currency": "CLP"}	f	f	\N	\N	\N
91	2024-11-29 23:49:18.908692	2024-11-29 23:49:18.908692	2	8	asdadsa	\N	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N
92	2024-11-29 23:52:18.190117	2024-11-29 23:52:18.190117	2	8	asdsad	\N	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N
93	2024-11-30 16:30:53.619966	2024-11-30 16:30:53.619966	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N
96	2024-11-30 17:37:42.776984	2024-11-30 17:37:42.776984	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N
97	2024-11-30 17:42:45.429273	2024-11-30 17:42:45.429273	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N
98	2024-11-30 17:44:44.380662	2024-11-30 17:44:44.380662	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N
99	2024-11-30 17:45:07.359801	2024-11-30 17:45:07.359801	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N
100	2024-11-30 19:33:03.831489	2024-11-30 19:33:03.831489	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N
101	2024-11-30 19:33:36.451078	2024-11-30 19:33:36.451078	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N
102	2024-11-30 19:35:32.375141	2024-11-30 19:35:32.375141	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N
103	2024-11-30 19:39:41.059025	2024-11-30 19:39:41.059025	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N
104	2024-11-30 19:42:25.62594	2024-11-30 19:42:25.62594	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N
105	2024-11-30 19:51:37.405839	2024-11-30 19:51:37.405839	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N
106	2024-11-30 19:55:40.96267	2024-11-30 19:55:40.96267	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N
107	2024-11-30 19:56:55.097196	2024-11-30 19:57:10.897989	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	canceled	2024-11-30 19:57:10.897989	\N	\N	\N	\N	\N	\N	\N	\N	\N	customer	other	\N	\N	2024-11-30 19:57:10.897989	4	customer	\N	f	f	\N	\N	\N
108	2024-11-30 19:58:28.508432	2024-11-30 19:58:44.338463	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	canceled	2024-11-30 19:58:44.338463	\N	\N	\N	\N	\N	\N	\N	\N	\N	customer	other	\N	\N	2024-11-30 19:58:44.338463	4	customer	\N	f	f	\N	\N	\N
109	2024-11-30 20:00:03.354907	2024-11-30 20:00:17.861672	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	canceled	2024-11-30 20:00:17.861672	\N	\N	\N	\N	\N	\N	\N	\N	\N	customer	other	\N	\N	2024-11-30 20:00:17.861672	4	customer	\N	f	f	\N	\N	\N
110	2024-11-30 20:18:07.950658	2024-11-30 20:18:07.950658	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N
111	2024-11-30 20:20:02.130261	2024-11-30 20:20:02.130261	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N
114	2024-11-30 20:37:42.659146	2024-11-30 20:38:42.149942	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	rejected	2024-11-30 20:38:42.149942	\N	\N	artist	\N	other	Test additional details	2024-11-30 20:38:42.149942	\N	\N	\N	\N	\N	\N	\N	15	artist	\N	f	f	\N	\N	\N
115	2024-11-30 20:40:36.397679	2024-11-30 20:41:37.321866	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	rejected	2024-11-30 20:41:37.321866	\N	\N	artist	\N	other	Test additional details	2024-11-30 20:41:37.321866	\N	\N	\N	\N	\N	\N	\N	15	artist	\N	f	f	\N	\N	\N
112	2024-11-30 20:31:50.669439	2024-11-30 23:56:46.995082	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	rejected	2024-11-30 23:56:46.995082	\N	\N	artist	\N	other	asdaa	2024-11-30 23:56:46.995082	\N	\N	\N	\N	\N	\N	\N	15	artist	\N	f	f	\N	\N	\N
120	2024-12-01 00:38:27.020161	2024-12-01 00:38:27.020161	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N
246	2024-12-22 00:29:06.266893	2024-12-22 00:29:06.266893	28	3	Gatos	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/246/artist/3/reference-images/reference_0", "size": 3045053, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N
262	2025-03-07 02:10:55.323363	2025-03-07 02:12:32.693411	3	9	123213	\N	\N	accepted	2025-03-07 02:12:24.68908	2025-03-06 23:11:10.478	60	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	6	customer	{"scale": 0, "amount": 50, "currency": "CLP"}	t	f	2025-03-07 02:12:32.693411	\N	\N
253	2025-03-06 02:27:32.490729	2025-03-22 04:24:25.347628	3	9	12312	\N	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	2025-03-22 04:24:25.347628	\N	\N
210	2024-12-04 02:24:34.307895	2024-12-20 03:46:14.81903	1	1	I want a tatto bla bla bla bla ba	{"count": 2, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/210/artist/1/reference-images/reference_0", "size": 37, "type": "image/png", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "rocket1.png"}, {"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/210/artist/1/reference-images/reference_1", "size": 37, "type": "image/png", "encoding": "7bit", "position": 1, "fieldname": "files[]", "originalname": "rocket2.png"}]}	\N	rejected	2024-12-20 03:46:14.81903	\N	\N	artist	\N	insufficient_details	nones	2024-12-20 03:46:14.81903	\N	\N	\N	\N	\N	\N	\N	1	artist	\N	f	f	\N	\N	\N
211	2024-12-04 02:25:09.449822	2024-12-20 03:46:35.198391	1	1	I want a tatto bla bla bla bla ba	{"count": 2, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/211/artist/1/reference-images/reference_0", "size": 37, "type": "image/png", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "rocket1.png"}, {"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/211/artist/1/reference-images/reference_1", "size": 37, "type": "image/png", "encoding": "7bit", "position": 1, "fieldname": "files[]", "originalname": "rocket2.png"}]}	\N	rejected	2024-12-20 03:46:35.198391	\N	\N	artist	\N	insufficient_details		2024-12-20 03:46:35.198391	\N	\N	\N	\N	\N	\N	\N	1	artist	\N	f	f	\N	\N	\N
212	2024-12-04 02:32:10.312205	2024-12-14 01:24:54.412215	1	1	I want a tatto bla bla bla bla ba	{"count": 2, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/212/artist/1/reference-images/reference_0", "size": 37, "type": "image/png", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "rocket1.png"}, {"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/212/artist/1/reference-images/reference_1", "size": 37, "type": "image/png", "encoding": "7bit", "position": 1, "fieldname": "files[]", "originalname": "rocket2.png"}]}	\N	canceled	2024-12-14 01:24:54.412215	\N	\N	\N	\N	\N	\N	\N	\N	\N	customer	\N	\N	\N	2024-12-14 01:24:54.412215	4	customer	\N	f	t	\N	2024-12-14 01:11:26.803634	\N
213	2024-12-04 02:32:47.144432	2024-12-14 00:59:12.720335	1	1	I want a tatto bla bla bla bla ba	{"count": 2, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/213/artist/1/reference-images/reference_0", "size": 37, "type": "image/png", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "rocket1.png"}, {"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/213/artist/1/reference-images/reference_1", "size": 37, "type": "image/png", "encoding": "7bit", "position": 1, "fieldname": "files[]", "originalname": "rocket2.png"}]}	\N	canceled	2024-12-14 00:59:12.720335	\N	\N	\N	\N	\N	\N	\N	\N	\N	customer	\N	\N	\N	2024-12-14 00:59:12.720335	4	customer	\N	f	f	\N	\N	\N
214	2024-12-04 02:33:15.485044	2024-12-14 00:57:26.810786	1	1	I want a tatto bla bla bla bla ba	{"count": 2, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/214/artist/1/reference-images/reference_0", "size": 37, "type": "image/png", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "rocket1.png"}, {"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/214/artist/1/reference-images/reference_1", "size": 37, "type": "image/png", "encoding": "7bit", "position": 1, "fieldname": "files[]", "originalname": "rocket2.png"}]}	\N	canceled	2024-12-14 00:57:26.810786	\N	\N	\N	\N	\N	\N	\N	\N	\N	customer	\N	\N	\N	2024-12-14 00:57:26.810786	4	customer	\N	f	f	\N	\N	\N
215	2024-12-04 02:34:54.045665	2024-12-14 00:57:14.580354	1	1	I want a tatto bla bla bla bla ba	{"count": 2, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/215/artist/1/reference-images/reference_0", "size": 37, "type": "image/png", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "rocket1.png"}, {"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/215/artist/1/reference-images/reference_1", "size": 37, "type": "image/png", "encoding": "7bit", "position": 1, "fieldname": "files[]", "originalname": "rocket2.png"}]}	\N	canceled	2024-12-14 00:57:14.580354	\N	\N	\N	\N	\N	\N	\N	\N	\N	customer	\N	\N	\N	2024-12-14 00:57:14.580354	4	customer	\N	f	f	\N	\N	\N
216	2024-12-04 02:38:03.373474	2024-12-14 00:57:07.540275	1	1	I want a tatto bla bla bla bla ba	{"count": 2, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/216/artist/1/reference-images/reference_0", "size": 37, "type": "image/png", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "rocket1.png"}, {"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/216/artist/1/reference-images/reference_1", "size": 37, "type": "image/png", "encoding": "7bit", "position": 1, "fieldname": "files[]", "originalname": "rocket2.png"}]}	\N	canceled	2024-12-14 00:57:07.540275	\N	\N	\N	\N	\N	\N	\N	\N	\N	customer	\N	\N	\N	2024-12-14 00:57:07.540275	4	customer	\N	f	f	\N	\N	\N
217	2024-12-04 02:42:18.224138	2024-12-14 00:56:43.712005	1	1	I want a tatto bla bla bla bla ba	{"count": 2, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/217/artist/1/reference-images/reference_0", "size": 37, "type": "image/png", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "rocket1.png"}, {"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/217/artist/1/reference-images/reference_1", "size": 37, "type": "image/png", "encoding": "7bit", "position": 1, "fieldname": "files[]", "originalname": "rocket2.png"}]}	\N	canceled	2024-12-14 00:56:43.712005	\N	\N	\N	\N	\N	\N	\N	\N	\N	customer	\N	\N	\N	2024-12-14 00:56:43.712005	4	customer	\N	f	f	\N	\N	\N
218	2024-12-04 02:43:03.251058	2024-12-14 00:56:37.656561	1	1	I want a tatto bla bla bla bla ba	{"count": 2, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/218/artist/1/reference-images/reference_0", "size": 37, "type": "image/png", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "rocket1.png"}, {"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/218/artist/1/reference-images/reference_1", "size": 37, "type": "image/png", "encoding": "7bit", "position": 1, "fieldname": "files[]", "originalname": "rocket2.png"}]}	\N	canceled	2024-12-14 00:56:37.656561	\N	\N	\N	\N	\N	\N	\N	\N	\N	customer	\N	\N	\N	2024-12-14 00:56:37.656561	4	customer	\N	f	f	\N	\N	\N
219	2024-12-04 02:43:43.992614	2024-12-14 00:56:06.642245	1	1	I want a tatto bla bla bla bla ba	{"count": 2, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/219/artist/1/reference-images/reference_0", "size": 37, "type": "image/png", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "rocket1.png"}, {"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/219/artist/1/reference-images/reference_1", "size": 37, "type": "image/png", "encoding": "7bit", "position": 1, "fieldname": "files[]", "originalname": "rocket2.png"}]}	\N	canceled	2024-12-14 00:56:06.642245	\N	\N	\N	\N	\N	\N	\N	\N	\N	customer	\N	\N	\N	2024-12-14 00:56:06.642245	4	customer	\N	f	f	\N	\N	\N
220	2024-12-04 02:48:27.354876	2024-12-13 02:46:42.24483	1	1	I want a tatto bla bla bla bla ba	{"count": 2, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/220/artist/1/reference-images/reference_0", "size": 37, "type": "image/png", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "rocket1.png"}, {"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/220/artist/1/reference-images/reference_1", "size": 37, "type": "image/png", "encoding": "7bit", "position": 1, "fieldname": "files[]", "originalname": "rocket2.png"}]}	\N	canceled	2024-12-13 02:46:42.24483	\N	\N	\N	\N	\N	\N	\N	\N	\N	customer	\N	\N	\N	2024-12-13 02:46:42.24483	4	customer	\N	f	f	\N	\N	\N
254	2025-03-06 02:28:27.541176	2025-03-22 04:19:22.133056	3	9	12313	\N	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	2025-03-22 04:19:22.133056	\N	\N
221	2024-12-04 02:48:51.147347	2024-12-13 02:26:59.774398	1	1	I want a tatto bla bla bla bla ba	{"count": 2, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/221/artist/1/reference-images/reference_0", "size": 37, "type": "image/png", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "rocket1.png"}, {"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/221/artist/1/reference-images/reference_1", "size": 37, "type": "image/png", "encoding": "7bit", "position": 1, "fieldname": "files[]", "originalname": "rocket2.png"}]}	\N	canceled	2024-12-13 02:26:59.774398	\N	\N	\N	\N	\N	\N	\N	\N	\N	customer	\N	\N	\N	2024-12-13 02:26:59.774398	4	customer	\N	f	f	\N	\N	\N
222	2024-12-04 02:57:15.89121	2024-12-13 01:59:05.407057	1	1	I want a tatto bla bla bla bla ba	{"count": 2, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/222/artist/1/reference-images/reference_0", "size": 37, "type": "image/png", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "rocket1.png"}, {"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/222/artist/1/reference-images/reference_1", "size": 37, "type": "image/png", "encoding": "7bit", "position": 1, "fieldname": "files[]", "originalname": "rocket2.png"}]}	\N	canceled	2024-12-13 01:59:05.407057	\N	\N	\N	\N	\N	\N	\N	\N	\N	customer	\N	\N	\N	2024-12-13 01:59:05.407057	4	customer	\N	f	f	\N	\N	\N
169	2024-12-02 02:00:37.603519	2024-12-13 01:58:57.25655	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	rejected	2024-12-13 01:58:57.25655	2024-12-12 00:29:28.448	60	customer	changed_my_mind	\N	asdsadas	2024-12-13 01:58:57.25655	\N	\N	\N	\N	\N	\N	\N	4	customer	{"scale": 0, "amount": 5, "currency": "CLP"}	f	f	\N	\N	\N
168	2024-12-02 01:59:27.145667	2024-12-14 01:36:28.021207	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	accepted	2024-12-14 01:36:28.021207	2024-12-12 22:42:59.664	60	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	4	customer	{"scale": 0, "amount": 5, "currency": "CLP"}	f	t	\N	2024-12-14 01:18:12.869307	\N
162	2024-12-02 01:56:29.404365	2024-12-17 02:09:09.631312	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	accepted	2024-12-17 02:08:46.184067	2024-12-12 22:43:29.021	60	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	4	customer	{"scale": 0, "amount": 545, "currency": "CLP"}	f	t	\N	2024-12-17 02:09:09.631312	\N
155	2024-12-02 01:23:07.64753	2024-12-17 02:29:49.852129	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	accepted	2024-12-17 02:29:49.852129	2024-12-12 22:47:53.413	60	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	4	customer	{"scale": 0, "amount": 435, "currency": "CLP"}	f	f	\N	\N	\N
157	2024-12-02 01:43:07.866765	2024-12-17 02:47:22.526759	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	accepted	2024-12-17 02:47:22.526759	2024-12-12 22:44:35.967	60	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	4	customer	{"scale": 0, "amount": 12, "currency": "CLP"}	f	f	\N	\N	\N
150	2024-12-02 01:14:12.273801	2024-12-13 01:55:26.095	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	rejected	2024-12-13 01:55:26.095	\N	\N	artist	\N	artistic_disagreement		2024-12-13 01:55:26.095	\N	\N	\N	\N	\N	\N	\N	15	artist	\N	f	f	\N	\N	\N
175	2024-12-02 02:33:46.6435	2024-12-13 01:56:11.82552	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	rejected	2024-12-13 01:56:11.82552	2024-12-02 20:45:00	15	customer	changed_my_mind	\N	asdsadada	2024-12-13 01:56:11.82552	\N	\N	\N	\N	\N	\N	\N	4	customer	{"scale": 0, "amount": 150, "currency": "CLP"}	f	f	\N	\N	\N
171	2024-12-02 02:02:07.982173	2024-12-13 01:57:55.264766	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	rejected	2024-12-13 01:57:55.264766	2024-12-12 00:28:47.153	60	customer	changed_my_mind	\N	asdsadada	2024-12-13 01:57:55.264766	\N	\N	\N	\N	\N	\N	\N	4	customer	{"scale": 0, "amount": 4, "currency": "CLP"}	f	f	\N	\N	\N
230	2024-12-12 02:32:11.342488	2024-12-14 01:32:45.986001	1	8	asdasdasdsadsa	\N	\N	accepted	2024-12-13 01:55:53.199847	2024-12-12 03:30:00	15	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	4	customer	{"scale": 0, "amount": 50, "currency": "CLP"}	t	f	2024-12-14 01:32:45.986001	\N	\N
166	2024-12-02 01:58:55.886906	2024-12-14 01:37:13.623866	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	accepted	2024-12-14 01:37:13.623866	2024-12-02 21:30:00	15	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	4	customer	{"scale": 0, "amount": 150, "currency": "CLP"}	t	t	2024-12-14 01:36:43.226194	2024-12-14 01:18:29.062132	\N
147	2024-12-02 01:12:46.059796	2024-12-14 03:39:58.119251	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	rejected	2024-12-14 02:04:19.716213	\N	\N	artist	\N	artistic_disagreement	adasdasd	2024-12-14 02:04:19.716213	\N	\N	\N	\N	\N	\N	\N	15	artist	\N	t	f	2024-12-14 03:39:58.119251	\N	\N
208	2024-12-04 02:22:06.39079	2024-12-20 03:45:05.294802	1	1	I want a tatto bla bla bla bla ba	{"count": 2, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/208/artist/1/reference-images/reference_0", "size": 37, "type": "image/png", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "rocket1.png"}, {"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/208/artist/1/reference-images/reference_1", "size": 37, "type": "image/png", "encoding": "7bit", "position": 1, "fieldname": "files[]", "originalname": "rocket2.png"}]}	\N	rejected	2024-12-20 03:45:05.294802	\N	\N	artist	\N	insufficient_details	huj	2024-12-20 03:45:05.294802	\N	\N	\N	\N	\N	\N	\N	1	artist	\N	f	f	\N	\N	\N
235	2024-12-14 03:44:24.637784	2024-12-14 03:45:32.565192	1	8	ada111	\N	\N	rejected	2024-12-14 03:45:25.815978	2024-12-14 00:44:45.792	60	customer	changed_my_mind	\N	asdasdsadas	2024-12-14 03:45:25.815978	\N	\N	\N	\N	\N	\N	\N	4	customer	{"scale": 0, "amount": 1, "currency": "CLP"}	t	f	2024-12-14 03:45:32.565192	\N	\N
143	2024-12-02 01:09:08.536459	2024-12-17 02:08:04.342331	1	8	Me gustaría un tatuaje de un dragón japonés en el brazo	\N	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	t	2024-12-14 03:59:01.50622	2024-12-17 02:08:04.342331	\N
34	2024-09-14 21:07:08.933444	2024-09-15 03:53:56.2358	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	quoted	2024-09-15 03:53:56.2358	2024-09-15 01:53:00	60	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	artist	\N	f	f	\N	\N	\N
206	2024-12-04 02:17:43.72368	2024-12-20 03:47:25.665772	1	1	I want a tatto bla bla bla bla ba	{"count": 2, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/206/artist/1/reference-images/reference_0", "size": 37, "type": "image/png", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "rocket1.png"}, {"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/206/artist/1/reference-images/reference_1", "size": 37, "type": "image/png", "encoding": "7bit", "position": 1, "fieldname": "files[]", "originalname": "rocket2.png"}]}	\N	quoted	2024-12-20 03:47:10.832461	2024-12-20 00:47:08.036	60	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	artist	{"scale": 0, "amount": 50, "currency": "CLP"}	t	f	2024-12-20 03:47:25.665772	\N	\N
202	2024-12-04 02:11:10.573788	2024-12-20 03:25:40.881241	1	11	asdad	\N	\N	quoted	2024-12-19 00:44:18.832334	2024-12-18 21:43:45.315	60	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	31	artist	{"scale": 0, "amount": 50, "currency": "CLP"}	t	t	2024-12-19 00:44:47.514713	2024-12-20 03:25:40.881241	\N
238	2024-12-17 03:07:10.781578	2024-12-20 03:25:58.336671	1	8	ffffff	\N	\N	accepted	2024-12-17 03:08:12.681894	2024-12-17 10:00:00	60	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	4	customer	{"scale": 0, "amount": 50, "currency": "CLP"}	f	t	\N	2024-12-20 03:25:58.336671	\N
207	2024-12-04 02:21:23.53725	2024-12-20 03:44:28.220108	1	1	I want a tatto bla bla bla bla ba	{"count": 2, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/207/artist/1/reference-images/reference_0", "size": 37, "type": "image/png", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "rocket1.png"}, {"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/207/artist/1/reference-images/reference_1", "size": 37, "type": "image/png", "encoding": "7bit", "position": 1, "fieldname": "files[]", "originalname": "rocket2.png"}]}	\N	rejected	2024-12-20 03:44:28.220108	\N	\N	artist	\N	insufficient_details	nope\n	2024-12-20 03:44:28.220108	\N	\N	\N	\N	\N	\N	\N	1	artist	\N	f	f	\N	\N	\N
241	2024-12-20 03:52:30.115135	2024-12-20 03:53:21.639788	3	9	Tatuaje	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/241/artist/9/reference-images/reference_0", "size": 2407315, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	canceled	2024-12-20 03:53:10.307605	\N	\N	\N	\N	\N	\N	\N	\N	\N	customer	\N	\N	\N	2024-12-20 03:53:10.307605	6	customer	\N	t	f	2024-12-20 03:53:21.639788	\N	\N
242	2024-12-20 03:54:19.517776	2024-12-20 03:55:51.829632	3	9	jijij	\N	\N	accepted	2024-12-20 03:55:38.879028	2025-01-01 09:54:00	60	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	6	customer	{"scale": 0, "amount": 50, "currency": "CLP"}	t	t	2024-12-20 03:55:47.973326	2024-12-20 03:55:51.829632	\N
197	2024-12-04 01:44:58.231904	2024-12-21 21:38:10.172502	3	1	I want a tatto bla bla bla bla ba	{"count": 2, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/197/artist/1/reference-images/reference_0", "size": 37, "type": "image/png", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "rocket1.png"}, {"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/197/artist/1/reference-images/reference_1", "size": 37, "type": "image/png", "encoding": "7bit", "position": 1, "fieldname": "files[]", "originalname": "rocket2.png"}]}	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	t	\N	2024-12-21 21:38:10.172502	\N
243	2024-12-21 23:49:45.87661	2024-12-21 23:50:28.867821	3	2	f	{"count": 4, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/243/artist/2/reference-images/reference_0", "size": 1626027, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}, {"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/243/artist/2/reference-images/reference_1", "size": 1017222, "type": "image/jpeg", "encoding": "7bit", "position": 1, "fieldname": "files[]", "originalname": "image_1.jpg"}, {"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/243/artist/2/reference-images/reference_2", "size": 646184, "type": "image/jpeg", "encoding": "7bit", "position": 2, "fieldname": "files[]", "originalname": "image_2.jpg"}, {"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/243/artist/2/reference-images/reference_3", "size": 2535122, "type": "image/jpeg", "encoding": "7bit", "position": 3, "fieldname": "files[]", "originalname": "image_3.jpg"}]}	\N	canceled	2024-12-21 23:50:20.440327	\N	\N	\N	\N	\N	\N	\N	\N	\N	customer	\N	\N	\N	2024-12-21 23:50:20.440327	6	customer	\N	f	t	\N	2024-12-21 23:50:28.867821	\N
256	2025-03-06 02:37:38.197597	2025-03-07 02:07:41.847825	3	9	12313	\N	\N	rejected	2025-03-07 02:03:24.143542	\N	\N	artist	\N	beyond_expertise		2025-03-07 02:03:24.143542	\N	\N	\N	\N	\N	\N	\N	29	artist	\N	f	t	\N	2025-03-07 02:07:41.847825	\N
263	2025-03-07 02:25:03.471803	2025-03-08 17:36:02.560936	3	9	1312312	\N	\N	rejected	2025-03-07 02:25:18.965424	\N	\N	artist	\N	insufficient_details		2025-03-07 02:25:18.965424	\N	\N	\N	\N	\N	\N	\N	29	artist	\N	t	t	2025-03-08 17:36:02.560936	2025-03-07 04:10:58.810421	\N
267	2025-04-06 23:43:42.466675	2025-04-06 23:47:58.378847	24	9	Solicito cotización para el diseño "test tags" . Me gustaría obtener más información sobre tamaños, precios y disponibilidad.\n\nCotización para stencil ID: 33	\N	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	t	\N	2025-04-06 23:47:58.378847	33
264	2025-03-07 21:18:05.206207	2025-03-08 00:22:46.753748	3	9	quiero un tattoo	\N	\N	accepted	2025-03-07 21:19:03.99547	2025-03-07 10:45:00	15	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	6	customer	{"scale": 0, "amount": 3, "currency": "CLP"}	t	t	2025-03-07 21:19:18.834929	2025-03-08 00:22:46.753748	\N
257	2025-03-06 02:38:20.789515	2025-03-14 23:53:06.857682	3	9	12313	\N	\N	rejected	2025-03-07 21:17:47.708162	\N	\N	artist	\N	scheduling_conflict		2025-03-07 21:17:47.708162	\N	\N	\N	\N	\N	\N	\N	29	artist	\N	t	t	2025-03-14 23:53:06.857682	2025-03-07 22:39:11.510294	\N
258	2025-03-06 02:41:11.963101	2025-03-06 02:49:08.202781	3	9	12321	\N	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	2025-03-06 02:49:08.202781	\N	\N
265	2025-03-12 01:56:09.575719	2025-03-23 16:05:39.14475	20	9	un tatuaje pls	\N	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/265/artist/9/proposed-designs/design_0", "size": 66074, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "proposedDesigns[]", "originalname": "image_0.jpg"}]}	quoted	2025-03-12 02:04:40.414268	2025-03-11 12:30:00	15	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	29	artist	{"scale": 0, "amount": 5, "currency": "CLP"}	t	t	2025-03-12 03:25:28.830779	2025-03-23 16:05:39.14475	\N
259	2025-03-06 02:57:11.588172	2025-03-07 02:07:48.350297	3	9	12321312	\N	\N	accepted	2025-03-07 02:01:25.727985	2025-03-06 12:00:00	15	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	6	customer	{"scale": 0, "amount": 50, "currency": "CLP"}	t	t	2025-03-07 02:01:35.995418	2025-03-07 02:07:48.350297	\N
255	2025-03-06 02:36:02.790146	2025-03-22 04:19:15.066812	3	9	1312313	\N	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	2025-03-22 04:19:15.066812	\N	\N
260	2025-03-07 01:29:53.049243	2025-03-07 01:29:53.049243	3	1	I want a tatto bla bla bla bla ba	{"count": 2, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/260/artist/1/reference-images/reference_0", "size": 37, "type": "image/png", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "rocket1.png"}, {"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/260/artist/1/reference-images/reference_1", "size": 37, "type": "image/png", "encoding": "7bit", "position": 1, "fieldname": "files[]", "originalname": "rocket2.png"}]}	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N
266	2025-04-06 18:52:55.069153	2025-04-06 23:38:06.440772	24	9	Solicito cotización para el diseño "test tags" . Me gustaría obtener más información sobre tamaños, precios y disponibilidad.\n\nCotización para stencil ID: 33	\N	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	t	\N	2025-04-06 23:38:06.440772	\N
\.


--
-- Data for Name: quotation_backup; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.quotation_backup (id, created_at, updated_at, customer_id, artist_id, description, reference_images, proposed_designs, status, response_date, appointment_date, appointment_duration, reject_by, customer_reject_reason, artist_reject_reason, reject_reason_details, rejected_date, appealed_reason, appealed_date, canceled_by, customer_cancel_reason, system_cancel_reason, cancel_reason_details, canceled_date, last_updated_by, last_updated_by_user_type, estimated_cost) FROM stdin;
6	2024-08-22 03:39:54.78399	2024-08-22 03:39:54.78399	1	3	djjdkkd	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
7	2024-08-22 03:42:21.899824	2024-08-22 03:42:21.899824	1	3	ekjdkjf	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
8	2024-08-22 03:46:20.591907	2024-08-22 03:46:20.591907	1	3	ejemplo\n	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
40	2024-09-15 04:58:51.511797	2024-09-15 04:58:51.511797	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
26	2024-08-23 04:12:16.024625	2024-09-02 04:03:22.331327	1	8	dnjdjd	\N	\N	canceled	2024-09-02 04:03:22.331327	\N	\N	\N	\N	\N	\N	\N	\N	\N	customer	other	\N	\N	2024-09-02 04:03:22.331327	4	customer	\N
25	2024-08-23 03:58:34.622775	2024-09-02 04:07:46.580578	1	8	q\n	\N	\N	canceled	2024-09-02 04:07:46.580578	\N	\N	\N	\N	\N	\N	\N	\N	\N	customer	other	\N	\N	2024-09-02 04:07:46.580578	4	customer	\N
30	2024-08-23 04:27:32.728119	2024-09-02 03:54:28.740468	1	8	lslslsllsllala\nmxldkdd	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	canceled	2024-09-02 03:54:28.740468	\N	\N	\N	\N	\N	\N	\N	\N	\N	customer	other	\N	\N	2024-09-02 03:54:28.740468	4	customer	\N
38	2024-09-15 04:58:50.944261	2024-09-15 04:58:50.944261	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
43	2024-09-15 04:58:53.627148	2024-09-15 04:58:53.627148	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
41	2024-09-15 04:58:52.375169	2024-09-15 04:58:52.375169	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
44	2024-09-15 04:58:53.797238	2024-09-15 04:58:53.797238	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
20	2024-08-23 03:31:08.359593	2024-09-02 04:20:05.135533	1	8	xd\n	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	canceled	2024-09-02 04:20:05.135533	\N	\N	\N	\N	\N	\N	\N	\N	\N	customer	other	\N	\N	2024-09-02 04:20:05.135533	4	customer	\N
22	2024-08-23 03:41:05.770501	2024-09-02 04:25:38.056818	1	8	g\n	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	canceled	2024-09-02 04:25:38.056818	\N	\N	\N	\N	\N	\N	\N	\N	\N	customer	other	\N	\N	2024-09-02 04:25:38.056818	4	customer	\N
45	2024-09-15 04:58:53.976603	2024-09-15 04:58:53.976603	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
52	2024-09-15 04:58:54.966367	2024-09-15 04:58:54.966367	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
53	2024-09-15 04:58:55.123442	2024-09-15 04:58:55.123442	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
59	2024-09-15 04:58:55.918055	2024-09-15 04:58:55.918055	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
64	2024-09-15 04:58:56.539704	2024-09-15 04:58:56.539704	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
65	2024-09-15 04:58:56.786527	2024-09-15 04:58:56.786527	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
62	2024-09-15 04:58:56.374203	2024-09-15 04:58:56.374203	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
70	2024-09-15 04:58:57.543628	2024-09-16 03:10:50.511062	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	rejected	2024-09-16 03:10:50.511062	\N	0	artist	\N	insufficient_details		2024-09-16 03:10:50.511062	\N	\N	\N	\N	\N	\N	\N	1	artist	\N
63	2024-09-15 04:58:56.488542	2024-09-15 04:58:56.488542	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
68	2024-09-15 04:58:57.078022	2024-09-16 03:22:50.650955	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	rejected	2024-09-16 03:22:50.650955	\N	0	artist	\N	insufficient_details		2024-09-16 03:22:50.650955	\N	\N	\N	\N	\N	\N	\N	1	artist	\N
9	2024-08-22 03:46:44.906062	2024-08-22 03:46:44.906062	1	3	djjdjdjkd	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
18	2024-08-23 03:23:59.074837	2024-09-02 04:33:11.078061	1	8	j\n	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	canceled	2024-09-02 04:33:11.078061	\N	\N	\N	\N	\N	\N	\N	\N	\N	customer	other	\N	\N	2024-09-02 04:33:11.078061	4	customer	\N
17	2024-08-23 03:20:53.728877	2024-09-03 02:13:50.140335	1	8	y\n	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	canceled	2024-09-03 02:13:50.140335	\N	\N	\N	\N	\N	\N	\N	\N	\N	customer	other	\N	\N	2024-09-03 02:13:50.140335	4	customer	\N
69	2024-09-15 04:58:57.292838	2024-09-16 03:22:21.720119	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/69/artist/1/proposed-designs/design_0", "size": 147911, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "proposedDesigns", "originalname": "design_0.jpg"}]}	quoted	2024-09-16 03:22:21.720119	2024-09-16 01:22:00	60	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	artist	{"scale": 2, "amount": 500, "currency": "USD"}
28	2024-08-23 04:18:36.097704	2024-09-02 03:58:08.521864	1	8	ejemplos \ndjjdjdjd\nd\nde\nd\nd\nd\n\nd	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	canceled	2024-09-02 03:58:08.521864	\N	\N	\N	\N	\N	\N	\N	\N	\N	customer	other	\N	\N	2024-09-02 03:58:08.521864	4	customer	\N
27	2024-08-23 04:12:24.730255	2024-09-02 04:03:09.780408	1	8	dnjdjd	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	canceled	2024-09-02 04:03:09.780408	\N	\N	\N	\N	\N	\N	\N	\N	\N	customer	other	\N	\N	2024-09-02 04:03:09.780408	4	customer	\N
24	2024-08-23 03:53:19.752031	2024-09-02 04:12:38.015529	1	8	q\n	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	canceled	2024-09-02 04:12:38.015529	\N	\N	\N	\N	\N	\N	\N	\N	\N	customer	other	\N	\N	2024-09-02 04:12:38.015529	4	customer	\N
29	2024-08-23 04:19:14.623966	2024-09-02 04:19:53.317099	1	8	esto es un ejemplo de descripción 	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	canceled	2024-09-02 04:19:53.317099	\N	\N	\N	\N	\N	\N	\N	\N	\N	customer	other	\N	\N	2024-09-02 04:19:53.317099	4	customer	\N
74	2024-09-15 04:58:58.074581	2024-09-15 23:05:46.423641	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	rejected	2024-09-15 23:05:46.423641	\N	0	artist	\N	artistic_disagreement		2024-09-15 23:05:46.423641	\N	\N	\N	\N	\N	\N	\N	1	artist	\N
23	2024-08-23 03:49:34.903059	2024-09-02 04:29:01.881133	1	8	q	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	canceled	2024-09-02 04:29:01.881133	\N	\N	\N	\N	\N	\N	\N	\N	\N	customer	other	\N	\N	2024-09-02 04:29:01.881133	4	customer	\N
21	2024-08-23 03:35:19.525674	2024-09-02 04:32:32.870413	1	8	q\n	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	canceled	2024-09-02 04:32:32.870413	\N	\N	\N	\N	\N	\N	\N	\N	\N	customer	other	\N	\N	2024-09-02 04:32:32.870413	4	customer	\N
19	2024-08-23 03:26:10.148782	2024-09-02 04:32:44.226685	1	8	w\n	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	canceled	2024-09-02 04:32:44.226685	\N	\N	\N	\N	\N	\N	\N	\N	\N	customer	other	\N	\N	2024-09-02 04:32:44.226685	4	customer	\N
34	2024-09-14 21:07:08.933444	2024-09-15 03:53:56.2358	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	quoted	2024-09-15 03:53:56.2358	2024-09-15 01:53:00	60	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	artist	\N
33	2024-09-14 21:07:03.835709	2024-09-15 03:54:21.491803	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	quoted	2024-09-15 03:54:21.491803	2024-09-15 01:54:00	60	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	artist	\N
36	2024-09-14 21:07:16.459737	2024-09-15 03:36:52.87781	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/36/artist/1/proposed-designs/design_0", "size": 5619070, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "proposedDesigns", "originalname": "design_0.jpg"}]}	quoted	2024-09-15 03:36:52.87781	2024-09-15 14:36:00	60	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	artist	\N
37	2024-09-14 21:07:19.796047	2024-09-14 21:32:41.867685	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	quoted	2024-09-14 21:32:41.867685	2024-09-14 19:31:00	60	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	artist	\N
35	2024-09-14 21:07:12.403848	2024-09-15 03:30:26.737254	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	quoted	2024-09-15 03:30:26.737254	2024-09-17 02:31:00	60	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	artist	\N
10	2024-08-22 03:47:33.818354	2024-09-12 03:20:17.925579	1	8	ejemplo	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	quoted	2024-09-12 03:20:17.925579	2024-09-24 09:19:00	120	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	15	artist	{"scale": 2, "amount": 5000000, "currency": "USD"}
39	2024-09-15 04:58:51.321699	2024-09-15 04:58:51.321699	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
51	2024-09-15 04:58:54.814486	2024-09-15 04:58:54.814486	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
57	2024-09-15 04:58:55.591567	2024-09-15 04:58:55.591567	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
58	2024-09-15 04:58:55.823367	2024-09-15 04:58:55.823367	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
66	2024-09-15 04:58:56.821306	2024-09-15 04:58:56.821306	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
42	2024-09-15 04:58:53.173262	2024-09-15 04:58:53.173262	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
46	2024-09-15 04:58:54.260237	2024-09-15 04:58:54.260237	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
47	2024-09-15 04:58:54.254972	2024-09-15 04:58:54.254972	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
48	2024-09-15 04:58:54.355304	2024-09-15 04:58:54.355304	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
49	2024-09-15 04:58:54.580356	2024-09-15 04:58:54.580356	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
50	2024-09-15 04:58:54.708226	2024-09-15 04:58:54.708226	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
54	2024-09-15 04:58:55.196444	2024-09-15 04:58:55.196444	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
55	2024-09-15 04:58:55.385053	2024-09-15 04:58:55.385053	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
56	2024-09-15 04:58:55.440861	2024-09-15 04:58:55.440861	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
60	2024-09-15 04:58:56.009994	2024-09-15 04:58:56.009994	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
61	2024-09-15 04:58:56.223341	2024-09-15 04:58:56.223341	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
72	2024-09-15 04:58:57.883113	2024-09-16 02:08:59.715166	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	rejected	2024-09-16 02:08:59.715166	\N	0	artist	\N	other		2024-09-16 02:08:59.715166	\N	\N	\N	\N	\N	\N	\N	1	artist	\N
67	2024-09-15 04:58:57.020302	2024-09-20 17:50:56.738516	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	rejected	2024-09-20 17:50:56.738516	\N	0	artist	\N	artistic_disagreement		2024-09-20 17:50:56.738516	\N	\N	\N	\N	\N	\N	\N	1	artist	\N
83	2024-10-20 02:48:58.358766	2024-10-27 18:49:25.386346	1	8	opppa	\N	\N	canceled	2024-10-27 18:49:25.386346	\N	\N	\N	\N	\N	\N	\N	\N	\N	customer	other	\N	\N	2024-10-27 18:49:25.386346	4	customer	\N
84	2024-10-27 18:50:08.624	2024-10-27 18:50:31.840535	1	1	ejemplo 1	\N	\N	canceled	2024-10-27 18:50:31.840535	\N	\N	\N	\N	\N	\N	\N	\N	\N	customer	other	\N	\N	2024-10-27 18:50:31.840535	4	customer	\N
85	2024-10-27 18:55:18.559945	2024-10-27 18:55:34.832549	1	1	asdasdfasd	\N	\N	rejected	2024-10-27 18:55:34.832549	\N	0	artist	\N	scheduling_conflict		2024-10-27 18:55:34.832549	\N	\N	\N	\N	\N	\N	\N	1	artist	\N
87	2024-11-04 02:11:10.06657	2024-11-04 02:11:10.06657	1	1	example y weas	\N	\N	pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
71	2024-09-15 04:58:57.616667	2024-09-16 02:13:11.029973	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	quoted	2024-09-16 02:13:11.029973	2024-09-16 17:13:00	357	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	artist	{"scale": 2, "amount": 500, "currency": "USD"}
86	2024-10-27 19:30:16.564295	2024-10-28 01:48:11.623327	1	1	ejemplxx	\N	\N	accepted	2024-10-28 01:48:11.623327	2024-11-06 18:30:00	0	\N	\N	\N	\N	\N	\N	2024-10-27 19:31:00.823381	\N	\N	\N	\N	\N	1	artist	{"scale": 2, "amount": 1000, "currency": "USD"}
15	2024-08-23 03:18:03.83863	2024-10-21 01:39:27.374201	1	8	g\n	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/15/artist/8/proposed-designs/design_0", "size": 2454907, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "proposedDesigns", "originalname": "design_0.jpg"}]}	rejected	2024-10-21 01:39:27.374201	2024-09-25 21:00:00	\N	customer	too_expensive	\N	muy caro man	2024-10-21 01:39:27.374201	\N	\N	\N	\N	\N	\N	\N	4	customer	{"scale": 2, "amount": 5000000, "currency": "USD"}
14	2024-08-23 03:16:31.393674	2024-10-21 01:39:57.536438	1	8	jkdjd	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	accepted	2024-10-21 01:39:57.536438	2024-09-22 21:00:00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	4	customer	{"scale": 2, "amount": 5000000, "currency": "USD"}
11	2024-08-23 03:08:07.0258	2024-09-14 06:12:12.868856	1	1	ejmplo	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/1/proposed-designs/design_0", "size": 4933462, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "proposedDesigns", "originalname": "design_0.jpg"}]}	quoted	2024-09-14 06:12:12.868856	2024-09-14 04:11:00	60	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	artist	{"scale": 2, "amount": 500000, "currency": "USD"}
16	2024-08-23 03:19:29.617101	2024-11-10 04:17:33.797746	1	8	Prueba de cotizacion 1	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/16/artist/8/proposed-designs/design_0", "size": 2481850, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "proposedDesigns", "originalname": "design_0.jpg"}]}	quoted	2024-11-10 04:17:33.797746	2024-11-10 02:16:00	60	\N	\N	\N	\N	\N	\N	2024-10-21 01:37:56.044411	\N	\N	\N	\N	\N	15	artist	{"scale": 0, "amount": 500, "currency": "CLP"}
31	2024-09-14 21:06:50.374983	2024-09-15 04:56:18.057887	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	quoted	2024-09-15 04:56:18.057887	2024-09-15 02:56:00	60	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	artist	{"scale": 2, "amount": 50000, "currency": "USD"}
32	2024-09-14 21:07:01.582281	2024-09-15 04:55:14.892063	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	quoted	2024-09-15 04:55:14.892063	2024-09-15 02:55:00	60	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	artist	{"scale": 2, "amount": 500, "currency": "USD"}
75	2024-09-15 04:58:58.201617	2024-09-15 05:25:00.539654	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	quoted	2024-09-15 05:25:00.539654	2024-09-15 05:24:00	60	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	artist	{"scale": 2, "amount": 500, "currency": "USD"}
5	2024-08-22 03:25:37.328466	2024-09-12 03:21:12.610153	1	8	ejemplo prueba 	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/5/artist/8/proposed-designs/design_0", "size": 249394, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "proposedDesigns", "originalname": "design_0.jpg"}]}	quoted	2024-09-12 03:21:12.610153	2024-09-23 18:20:00	60	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	15	artist	{"scale": 2, "amount": 500000, "currency": "USD"}
12	2024-08-23 03:13:47.87426	2024-09-12 03:25:31.68839	1	8	yyy	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/12/artist/8/proposed-designs/design_0", "size": 2495405, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "proposedDesigns", "originalname": "design_0.jpg"}]}	quoted	2024-09-12 03:25:31.68839	2024-09-30 17:24:00	120	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	15	artist	{"scale": 2, "amount": 5000000, "currency": "USD"}
13	2024-08-23 03:15:59.952299	2024-11-04 02:06:02.653841	1	8	y\n	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	appealed	2024-11-04 02:06:02.653841	2024-09-22 21:00:00	\N	\N	\N	\N	\N	\N	design_change	2024-11-04 02:06:02.653841	\N	\N	\N	\N	\N	4	customer	{"scale": 2, "amount": 50000000, "currency": "USD"}
4	2024-06-21 03:20:29.929902	2024-09-14 06:15:19.540943	1	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	{"count": 2, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/4/artist/1/proposed-designs/design_0", "size": 5619070, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "proposedDesigns", "originalname": "design_0.jpg"}, {"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/4/artist/1/proposed-designs/design_1", "size": 4933462, "type": "image/jpeg", "encoding": "7bit", "position": 1, "fieldname": "proposedDesigns", "originalname": "design_1.jpg"}]}	quoted	2024-09-14 06:15:19.540943	2024-09-14 19:00:00	60	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	artist	{"scale": 2, "amount": 500000, "currency": "USD"}
76	2024-09-15 04:58:58.31526	2024-09-15 05:07:11.292051	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	quoted	2024-09-15 05:07:11.292051	2024-09-15 05:06:00	60	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	artist	{"scale": 2, "amount": 500, "currency": "USD"}
73	2024-09-15 04:58:57.887294	2024-09-16 01:11:02.667611	3	1	I want a tatto bla bla bla bla ba	{"count": 1, "metadata": [{"url": "https://d1riey1i0e5tx2.cloudfront.net/quotation/11/artist/8/reference-images/reference_0", "size": 77046, "type": "image/jpeg", "encoding": "7bit", "position": 0, "fieldname": "files[]", "originalname": "image_0.jpg"}]}	\N	quoted	2024-09-16 01:11:02.667611	2024-09-15 23:10:00	60	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	artist	{"scale": 2, "amount": 500, "currency": "USD"}
\.


--
-- Data for Name: quotation_history; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.quotation_history (id, created_at, updated_at, previous_status, new_status, changed_at, changed_by, changed_by_user_type, previous_appointment_date, new_appointment_date, previous_appointment_duration, new_appointment_duration, appealed_reason, rejection_reason, cancellation_reason, additional_details, last_updated_by, last_updated_by_user_type, quotation_id, previous_estimated_cost, new_estimated_cost) FROM stdin;
1	2024-09-02 03:54:28.740468	2024-09-02 03:54:28.740468	pending	canceled	2024-09-02 03:54:28.740468	4	customer	\N	\N	\N	\N	\N	\N	other	\N	4	customer	30	\N	\N
2	2024-09-02 03:58:08.521864	2024-09-02 03:58:08.521864	pending	canceled	2024-09-02 03:58:08.521864	4	customer	\N	\N	\N	\N	\N	\N	other	\N	4	customer	28	\N	\N
3	2024-09-02 04:03:09.780408	2024-09-02 04:03:09.780408	pending	canceled	2024-09-02 04:03:09.780408	4	customer	\N	\N	\N	\N	\N	\N	other	\N	4	customer	27	\N	\N
4	2024-09-02 04:03:22.331327	2024-09-02 04:03:22.331327	pending	canceled	2024-09-02 04:03:22.331327	4	customer	\N	\N	\N	\N	\N	\N	other	\N	4	customer	26	\N	\N
5	2024-09-02 04:07:46.580578	2024-09-02 04:07:46.580578	pending	canceled	2024-09-02 04:07:46.580578	4	customer	\N	\N	\N	\N	\N	\N	other	\N	4	customer	25	\N	\N
6	2024-09-02 04:12:38.015529	2024-09-02 04:12:38.015529	pending	canceled	2024-09-02 04:12:38.015529	4	customer	\N	\N	\N	\N	\N	\N	other	\N	4	customer	24	\N	\N
7	2024-09-02 04:19:53.317099	2024-09-02 04:19:53.317099	pending	canceled	2024-09-02 04:19:53.317099	4	customer	\N	\N	\N	\N	\N	\N	other	\N	4	customer	29	\N	\N
8	2024-09-02 04:20:05.135533	2024-09-02 04:20:05.135533	pending	canceled	2024-09-02 04:20:05.135533	4	customer	\N	\N	\N	\N	\N	\N	other	\N	4	customer	20	\N	\N
9	2024-09-02 04:25:38.056818	2024-09-02 04:25:38.056818	pending	canceled	2024-09-02 04:25:38.056818	4	customer	\N	\N	\N	\N	\N	\N	other	\N	4	customer	22	\N	\N
10	2024-09-02 04:29:01.881133	2024-09-02 04:29:01.881133	pending	canceled	2024-09-02 04:29:01.881133	4	customer	\N	\N	\N	\N	\N	\N	other	\N	4	customer	23	\N	\N
11	2024-09-02 04:32:32.870413	2024-09-02 04:32:32.870413	pending	canceled	2024-09-02 04:32:32.870413	4	customer	\N	\N	\N	\N	\N	\N	other	\N	4	customer	21	\N	\N
12	2024-09-02 04:32:44.226685	2024-09-02 04:32:44.226685	pending	canceled	2024-09-02 04:32:44.226685	4	customer	\N	\N	\N	\N	\N	\N	other	\N	4	customer	19	\N	\N
13	2024-09-02 04:33:11.078061	2024-09-02 04:33:11.078061	pending	canceled	2024-09-02 04:33:11.078061	4	customer	\N	\N	\N	\N	\N	\N	other	\N	4	customer	18	\N	\N
14	2024-09-03 02:13:50.140335	2024-09-03 02:13:50.140335	pending	canceled	2024-09-03 02:13:50.140335	4	customer	\N	\N	\N	\N	\N	\N	other	\N	4	customer	17	\N	\N
15	2024-09-12 02:38:09.745533	2024-09-12 02:38:09.745533	pending	quoted	2024-09-12 02:38:09.745533	15	artist	\N	2024-09-27 00:00:00	\N	15	\N	\N	\N		15	artist	16	\N	\N
16	2024-09-12 03:13:14.526225	2024-09-12 03:13:14.526225	pending	quoted	2024-09-12 03:13:14.526225	15	artist	\N	2024-09-25 21:00:00	\N	\N	\N	\N	\N	\n	15	artist	15	\N	\N
17	2024-09-12 03:15:58.6464	2024-09-12 03:15:58.6464	pending	quoted	2024-09-12 03:15:58.6464	15	artist	\N	2024-09-22 21:00:00	\N	\N	\N	\N	\N		15	artist	14	\N	\N
18	2024-09-12 03:19:09.165621	2024-09-12 03:19:09.165621	pending	quoted	2024-09-12 03:19:09.165621	15	artist	\N	2024-09-22 21:00:00	\N	\N	\N	\N	\N		15	artist	13	\N	\N
19	2024-09-12 03:20:17.925579	2024-09-12 03:20:17.925579	pending	quoted	2024-09-12 03:20:17.925579	15	artist	\N	2024-09-24 09:19:00	\N	120	\N	\N	\N		15	artist	10	\N	\N
20	2024-09-12 03:21:12.610153	2024-09-12 03:21:12.610153	pending	quoted	2024-09-12 03:21:12.610153	15	artist	\N	2024-09-23 18:20:00	\N	60	\N	\N	\N		15	artist	5	\N	\N
21	2024-09-12 03:25:31.68839	2024-09-12 03:25:31.68839	pending	quoted	2024-09-12 03:25:31.68839	15	artist	\N	2024-09-30 17:24:00	\N	120	\N	\N	\N		15	artist	12	\N	\N
22	2024-09-14 06:12:12.868856	2024-09-14 06:12:12.868856	pending	quoted	2024-09-14 06:12:12.868856	1	artist	\N	2024-09-14 04:11:00	\N	60	\N	\N	\N		1	artist	11	\N	\N
23	2024-09-14 06:15:19.540943	2024-09-14 06:15:19.540943	pending	quoted	2024-09-14 06:15:19.540943	1	artist	\N	2024-09-14 19:00:00	\N	60	\N	\N	\N		1	artist	4	\N	\N
24	2024-09-14 21:32:41.867685	2024-09-14 21:32:41.867685	pending	quoted	2024-09-14 21:32:41.867685	1	artist	\N	2024-09-14 19:31:00	\N	60	\N	\N	\N		1	artist	37	\N	\N
25	2024-09-15 03:30:26.737254	2024-09-15 03:30:26.737254	pending	quoted	2024-09-15 03:30:26.737254	1	artist	\N	2024-09-17 02:31:00	\N	60	\N	\N	\N		1	artist	35	\N	\N
26	2024-09-15 03:36:52.87781	2024-09-15 03:36:52.87781	pending	quoted	2024-09-15 03:36:52.87781	1	artist	\N	2024-09-15 14:36:00	\N	60	\N	\N	\N		1	artist	36	\N	\N
27	2024-09-15 03:53:56.2358	2024-09-15 03:53:56.2358	pending	quoted	2024-09-15 03:53:56.2358	1	artist	\N	2024-09-15 01:53:00	\N	60	\N	\N	\N		1	artist	34	\N	\N
28	2024-09-15 03:54:21.491803	2024-09-15 03:54:21.491803	pending	quoted	2024-09-15 03:54:21.491803	1	artist	\N	2024-09-15 01:54:00	\N	60	\N	\N	\N		1	artist	33	\N	\N
29	2024-09-15 04:55:14.892063	2024-09-15 04:55:14.892063	pending	quoted	2024-09-15 04:55:14.892063	1	artist	\N	2024-09-15 02:55:00	\N	60	\N	\N	\N		1	artist	32	\N	\N
30	2024-09-15 04:56:18.057887	2024-09-15 04:56:18.057887	pending	quoted	2024-09-15 04:56:18.057887	1	artist	\N	2024-09-15 02:56:00	\N	60	\N	\N	\N		1	artist	31	\N	\N
31	2024-09-15 05:07:11.292051	2024-09-15 05:07:11.292051	pending	quoted	2024-09-15 05:07:11.292051	1	artist	\N	2024-09-15 05:06:00	\N	60	\N	\N	\N		1	artist	76	\N	\N
32	2024-09-15 05:25:00.539654	2024-09-15 05:25:00.539654	pending	quoted	2024-09-15 05:25:00.539654	1	artist	\N	2024-09-15 05:24:00	\N	60	\N	\N	\N		1	artist	75	\N	\N
33	2024-09-15 23:05:46.423641	2024-09-15 23:05:46.423641	pending	rejected	2024-09-15 23:05:46.423641	1	artist	\N	\N	\N	0	\N	artistic_disagreement	\N		1	artist	74	\N	\N
34	2024-09-16 01:11:02.667611	2024-09-16 01:11:02.667611	pending	quoted	2024-09-16 01:11:02.667611	1	artist	\N	2024-09-15 23:10:00	\N	60	\N	\N	\N		1	artist	73	\N	\N
35	2024-09-16 02:08:59.715166	2024-09-16 02:08:59.715166	pending	rejected	2024-09-16 02:08:59.715166	1	artist	\N	\N	\N	0	\N	other	\N		1	artist	72	\N	\N
36	2024-09-16 02:13:11.029973	2024-09-16 02:13:11.029973	pending	quoted	2024-09-16 02:13:11.029973	1	artist	\N	2024-09-16 17:13:00	\N	357	\N	\N	\N		1	artist	71	\N	\N
37	2024-09-16 03:10:50.511062	2024-09-16 03:10:50.511062	pending	rejected	2024-09-16 03:10:50.511062	1	artist	\N	\N	\N	0	\N	insufficient_details	\N		1	artist	70	\N	\N
38	2024-09-16 03:22:21.720119	2024-09-16 03:22:21.720119	pending	quoted	2024-09-16 03:22:21.720119	1	artist	\N	2024-09-16 01:22:00	\N	60	\N	\N	\N		1	artist	69	\N	\N
39	2024-09-16 03:22:50.650955	2024-09-16 03:22:50.650955	pending	rejected	2024-09-16 03:22:50.650955	1	artist	\N	\N	\N	0	\N	insufficient_details	\N		1	artist	68	\N	\N
40	2024-09-20 17:50:56.738516	2024-09-20 17:50:56.738516	pending	rejected	2024-09-20 17:50:56.738516	1	artist	\N	\N	\N	0	\N	artistic_disagreement	\N		1	artist	67	\N	\N
41	2024-10-21 01:37:56.044411	2024-10-21 01:37:56.044411	quoted	appealed	2024-10-21 01:37:56.044411	4	customer	2024-09-27 00:00:00	\N	15	\N	price_change	\N	\N	un ultimo precio?	4	customer	16	\N	\N
42	2024-10-21 01:39:27.374201	2024-10-21 01:39:27.374201	quoted	rejected	2024-10-21 01:39:27.374201	4	customer	2024-09-25 21:00:00	\N	\N	\N	\N	too_expensive	\N	muy caro man	4	customer	15	\N	\N
43	2024-10-21 01:39:57.536438	2024-10-21 01:39:57.536438	quoted	accepted	2024-10-21 01:39:57.536438	4	customer	2024-09-22 21:00:00	\N	\N	\N	\N	\N	\N		4	customer	14	\N	\N
44	2024-10-27 18:49:25.386346	2024-10-27 18:49:25.386346	pending	canceled	2024-10-27 18:49:25.386346	4	customer	\N	\N	\N	\N	\N	\N	other	\N	4	customer	83	\N	\N
45	2024-10-27 18:50:31.840535	2024-10-27 18:50:31.840535	pending	canceled	2024-10-27 18:50:31.840535	4	customer	\N	\N	\N	\N	\N	\N	other	\N	4	customer	84	\N	\N
46	2024-10-27 18:55:34.832549	2024-10-27 18:55:34.832549	pending	rejected	2024-10-27 18:55:34.832549	1	artist	\N	\N	\N	0	\N	scheduling_conflict	\N		1	artist	85	\N	\N
47	2024-10-27 19:30:45.914036	2024-10-27 19:30:45.914036	pending	quoted	2024-10-27 19:30:45.914036	1	artist	\N	2024-11-06 18:30:00	\N	120	\N	\N	\N		1	artist	86	\N	\N
48	2024-10-27 19:31:00.823381	2024-10-27 19:31:00.823381	quoted	appealed	2024-10-27 19:31:00.823381	4	customer	2024-11-06 18:30:00	\N	120	\N	price_change	\N	\N	muy caro compa	4	customer	86	\N	\N
49	2024-10-28 01:48:11.623327	2024-10-28 01:48:11.623327	appealed	accepted	2024-10-28 01:48:11.623327	1	artist	2024-11-06 18:30:00	\N	120	0	\N	\N	\N	démosle choro	1	artist	86	\N	\N
50	2024-11-04 02:06:02.653841	2024-11-04 02:06:02.653841	quoted	appealed	2024-11-04 02:06:02.653841	4	customer	2024-09-22 21:00:00	\N	\N	\N	design_change	\N	\N	hagamos otra cosa we	4	customer	13	\N	\N
58	2024-11-20 02:59:54.701363	2024-11-20 02:59:54.701363	quoted	appealed	2024-11-20 02:59:54.701363	4	customer	2024-09-30 17:24:00	\N	120	\N	price_change	\N	\N	asdsa	4	customer	12	{"scale": 0, "amount": 50000, "currency": "CLP"}	\N
59	2024-11-20 03:00:05.979121	2024-11-20 03:00:05.979121	quoted	rejected	2024-11-20 03:00:05.979121	4	customer	2024-09-14 04:11:00	\N	60	\N	\N	not_what_i_wanted	\N	asdad	4	customer	11	{"scale": 0, "amount": 50000, "currency": "CLP"}	\N
51	2024-11-10 04:17:33.797746	2024-11-10 04:17:33.797746	appealed	quoted	2024-11-10 04:17:33.797746	15	artist	2024-09-27 00:00:00	2024-11-10 02:16:00	15	60	\N	\N	\N		15	artist	16	{"scale": 0, "amount": 50000, "currency": "CLP"}	{"scale": 0, "amount": 50000, "currency": "CLP"}
52	2024-11-11 01:09:42.117134	2024-11-11 01:09:42.117134	appealed	rejected	2024-11-11 01:09:42.117134	15	artist	2024-09-22 21:00:00	\N	\N	0	\N	\N	\N	lo siento bro no Tengo tiempo	15	artist	13	{"scale": 0, "amount": 50000, "currency": "CLP"}	{"scale": 0, "amount": 0, "currency": "CLP"}
53	2024-11-11 02:52:51.410946	2024-11-11 02:52:51.410946	quoted	appealed	2024-11-11 02:52:51.410946	4	customer	2024-11-10 02:16:00	\N	60	\N	design_change	\N	\N	cambiemos	4	customer	16	{"scale": 0, "amount": 50000, "currency": "CLP"}	\N
54	2024-11-12 02:11:29.247683	2024-11-12 02:11:29.247683	appealed	quoted	2024-11-12 02:11:29.247683	15	artist	2024-11-10 02:16:00	2024-11-12 21:11:00	60	120	\N	\N	\N	ya cambiemos el tatto, te Mando mas disenos	15	artist	16	{"scale": 0, "amount": 50000, "currency": "CLP"}	{"scale": 0, "amount": 40, "currency": "CLP"}
55	2024-11-20 02:55:56.64279	2024-11-20 02:55:56.64279	pending	canceled	2024-11-20 02:55:56.64279	4	customer	\N	\N	\N	\N	\N	\N	other	\N	4	customer	87	\N	\N
56	2024-11-20 02:57:26.309641	2024-11-20 02:57:26.309641	pending	canceled	2024-11-20 02:57:26.309641	4	customer	\N	\N	\N	\N	\N	\N	other	\N	4	customer	9	\N	\N
57	2024-11-20 02:57:44.10209	2024-11-20 02:57:44.10209	quoted	accepted	2024-11-20 02:57:44.10209	4	customer	2024-11-12 21:11:00	\N	120	\N	\N	\N	\N		4	customer	16	{"scale": 0, "amount": 40, "currency": "CLP"}	\N
60	2024-11-21 01:36:11.026835	2024-11-21 01:36:11.026835	appealed	rejected	2024-11-21 01:36:11.026835	15	artist	2024-09-30 17:24:00	\N	120	\N	\N	\N	\N		15	artist	12	{"scale": 0, "amount": 50000, "currency": "CLP"}	\N
61	2024-11-30 19:57:10.897989	2024-11-30 19:57:10.897989	pending	canceled	2024-11-30 19:57:10.897989	4	customer	\N	\N	\N	\N	\N	\N	other	\N	4	customer	107	\N	\N
62	2024-11-30 19:58:44.338463	2024-11-30 19:58:44.338463	pending	canceled	2024-11-30 19:58:44.338463	4	customer	\N	\N	\N	\N	\N	\N	other	\N	4	customer	108	\N	\N
63	2024-11-30 20:00:17.861672	2024-11-30 20:00:17.861672	pending	canceled	2024-11-30 20:00:17.861672	4	customer	\N	\N	\N	\N	\N	\N	other	\N	4	customer	109	\N	\N
64	2024-11-30 20:38:42.149942	2024-11-30 20:38:42.149942	pending	rejected	2024-11-30 20:38:42.149942	15	artist	\N	\N	\N	\N	\N	other	\N	Test additional details	15	artist	114	\N	\N
65	2024-11-30 20:41:37.321866	2024-11-30 20:41:37.321866	pending	rejected	2024-11-30 20:41:37.321866	15	artist	\N	\N	\N	\N	\N	other	\N	Test additional details	15	artist	115	\N	\N
66	2024-11-30 23:42:59.717138	2024-11-30 23:42:59.717138	pending	rejected	2024-11-30 23:42:59.717138	15	artist	\N	\N	\N	\N	\N	other	\N	Test additional details	15	artist	116	\N	\N
67	2024-11-30 23:44:34.027967	2024-11-30 23:44:34.027967	pending	rejected	2024-11-30 23:44:34.027967	15	artist	\N	\N	\N	\N	\N	other	\N	Test additional details	15	artist	117	\N	\N
68	2024-11-30 23:46:15.999982	2024-11-30 23:46:15.999982	pending	rejected	2024-11-30 23:46:15.999982	15	artist	\N	\N	\N	\N	\N	other	\N	asdsadad	15	artist	113	\N	\N
69	2024-11-30 23:56:46.995082	2024-11-30 23:56:46.995082	pending	rejected	2024-11-30 23:56:46.995082	15	artist	\N	\N	\N	\N	\N	other	\N	asdaa	15	artist	112	\N	\N
70	2024-11-30 23:58:24.303266	2024-11-30 23:58:24.303266	pending	rejected	2024-11-30 23:58:24.303266	15	artist	\N	\N	\N	\N	\N	other	\N	Test additional details	15	artist	118	\N	\N
71	2024-12-01 00:01:11.425911	2024-12-01 00:01:11.425911	pending	rejected	2024-12-01 00:01:11.425911	15	artist	\N	\N	\N	\N	\N	other	\N	Test additional details	15	artist	119	\N	\N
72	2024-12-01 04:19:59.509804	2024-12-01 04:19:59.509804	pending	quoted	2024-12-01 04:19:59.509804	15	artist	\N	2024-12-02 08:45:00	\N	15	\N	\N	\N	Sesión de 2 horas para tatuaje de dragón japonés	15	artist	121	\N	{"scale": 0, "amount": 150, "currency": "CLP"}
73	2024-12-01 04:23:46.175377	2024-12-01 04:23:46.175377	pending	quoted	2024-12-01 04:23:46.175377	15	artist	\N	2024-12-02 08:45:00	\N	15	\N	\N	\N	Sesión de 2 horas para tatuaje de dragón japonés	15	artist	122	\N	{"scale": 0, "amount": 150, "currency": "CLP"}
74	2024-12-01 04:26:26.491366	2024-12-01 04:26:26.491366	pending	quoted	2024-12-01 04:26:26.491366	15	artist	\N	2024-12-02 08:45:00	\N	15	\N	\N	\N	Sesión de 2 horas para tatuaje de dragón japonés	15	artist	123	\N	{"scale": 0, "amount": 150, "currency": "CLP"}
75	2024-12-01 04:30:03.058264	2024-12-01 04:30:03.058264	pending	rejected	2024-12-01 04:30:03.058264	15	artist	\N	\N	\N	\N	\N	other	\N	Test additional details	15	artist	125	\N	\N
76	2024-12-01 04:31:29.088795	2024-12-01 04:31:29.088795	pending	quoted	2024-12-01 04:31:29.088795	15	artist	\N	2024-12-02 08:45:00	\N	15	\N	\N	\N	Sesión de 2 horas para tatuaje de dragón japonés	15	artist	126	\N	{"scale": 0, "amount": 150, "currency": "CLP"}
77	2024-12-01 04:33:32.070554	2024-12-01 04:33:32.070554	pending	canceled	2024-12-01 04:33:32.070554	4	customer	\N	\N	\N	\N	\N	\N	other	\N	4	customer	130	\N	\N
78	2024-12-01 04:34:42.382599	2024-12-01 04:34:42.382599	pending	rejected	2024-12-01 04:34:42.382599	15	artist	\N	\N	\N	\N	\N	other	\N	Test additional details	15	artist	131	\N	\N
79	2024-12-01 04:36:07.046215	2024-12-01 04:36:07.046215	pending	quoted	2024-12-01 04:36:07.046215	15	artist	\N	2024-12-02 09:00:00	\N	15	\N	\N	\N	Sesión de 2 horas para tatuaje de dragón japonés	15	artist	132	\N	{"scale": 0, "amount": 150, "currency": "CLP"}
80	2024-12-01 04:47:26.636482	2024-12-01 04:47:26.636482	pending	quoted	2024-12-01 04:47:26.636482	15	artist	\N	2024-12-02 09:00:00	\N	15	\N	\N	\N	Sesión de 2 horas para tatuaje de dragón japonés	15	artist	133	\N	{"scale": 0, "amount": 150, "currency": "CLP"}
81	2024-12-01 05:02:41.235276	2024-12-01 05:02:41.235276	quoted	accepted	2024-12-01 05:02:41.235276	4	customer	2024-12-02 09:00:00	\N	15	\N	\N	\N	\N	Acepto los términos y el costo estimado	4	customer	133	{"scale": 0, "amount": 150, "currency": "CLP"}	\N
82	2024-12-01 05:04:25.651431	2024-12-01 05:04:25.651431	pending	quoted	2024-12-01 05:04:25.651431	15	artist	\N	2024-12-02 09:00:00	\N	15	\N	\N	\N	Sesión de 2 horas para tatuaje de dragón japonés	15	artist	134	\N	{"scale": 0, "amount": 150, "currency": "CLP"}
83	2024-12-01 05:06:38.281024	2024-12-01 05:06:38.281024	pending	quoted	2024-12-01 05:06:38.281024	15	artist	\N	2024-12-02 09:15:00	\N	15	\N	\N	\N	Sesión de 2 horas para tatuaje de dragón japonés	15	artist	135	\N	{"scale": 0, "amount": 150, "currency": "CLP"}
84	2024-12-01 05:07:17.228485	2024-12-01 05:07:17.228485	quoted	accepted	2024-12-01 05:07:17.228485	4	customer	2024-12-02 09:15:00	\N	15	\N	\N	\N	\N	Acepto los términos y el costo estimado	4	customer	135	{"scale": 0, "amount": 150, "currency": "CLP"}	\N
85	2024-12-02 01:07:15.92576	2024-12-02 01:07:15.92576	pending	canceled	2024-12-02 01:07:15.92576	4	customer	\N	\N	\N	\N	\N	\N	other	\N	4	customer	137	\N	\N
86	2024-12-02 01:08:34.421631	2024-12-02 01:08:34.421631	pending	rejected	2024-12-02 01:08:34.421631	15	artist	\N	\N	\N	\N	\N	other	\N	Test additional details	15	artist	139	\N	\N
87	2024-12-02 01:20:05.752818	2024-12-02 01:20:05.752818	pending	canceled	2024-12-02 01:20:05.752818	4	customer	\N	\N	\N	\N	\N	\N	other	\N	4	customer	152	\N	\N
88	2024-12-02 01:22:38.87474	2024-12-02 01:22:38.87474	pending	rejected	2024-12-02 01:22:38.87474	15	artist	\N	\N	\N	\N	\N	other	\N	Test additional details	15	artist	154	\N	\N
89	2024-12-02 01:45:22.424885	2024-12-02 01:45:22.424885	pending	rejected	2024-12-02 01:45:22.424885	15	artist	\N	\N	\N	\N	\N	other	\N	Test additional details	15	artist	158	\N	\N
90	2024-12-02 01:48:25.265159	2024-12-02 01:48:25.265159	pending	quoted	2024-12-02 01:48:25.265159	15	artist	\N	2024-12-02 21:00:00	\N	15	\N	\N	\N	Sesión de 2 horas para tatuaje de dragón japonés	15	artist	159	\N	{"scale": 0, "amount": 150, "currency": "CLP"}
91	2024-12-02 01:49:03.128949	2024-12-02 01:49:03.128949	quoted	accepted	2024-12-02 01:49:03.128949	4	customer	2024-12-02 21:00:00	\N	15	\N	\N	\N	\N	Acepto los términos y el costo estimado	4	customer	159	{"scale": 0, "amount": 150, "currency": "CLP"}	\N
92	2024-12-02 01:50:42.40696	2024-12-02 01:50:42.40696	pending	quoted	2024-12-02 01:50:42.40696	15	artist	\N	2024-12-02 20:45:00	\N	15	\N	\N	\N	Sesión de 2 horas para tatuaje de dragón japonés	15	artist	160	\N	{"scale": 0, "amount": 150, "currency": "CLP"}
93	2024-12-02 01:52:09.019873	2024-12-02 01:52:09.019873	pending	rejected	2024-12-02 01:52:09.019873	15	artist	\N	\N	\N	\N	\N	other	\N	Test additional details	15	artist	161	\N	\N
94	2024-12-02 01:57:11.107684	2024-12-02 01:57:11.107684	pending	canceled	2024-12-02 01:57:11.107684	4	customer	\N	\N	\N	\N	\N	\N	other	\N	4	customer	164	\N	\N
95	2024-12-02 01:57:48.807057	2024-12-02 01:57:48.807057	pending	quoted	2024-12-02 01:57:48.807057	15	artist	\N	2024-12-02 20:45:00	\N	15	\N	\N	\N	Sesión de 2 horas para tatuaje de dragón japonés	15	artist	163	\N	{"scale": 0, "amount": 150, "currency": "CLP"}
96	2024-12-02 01:58:26.652954	2024-12-02 01:58:26.652954	quoted	accepted	2024-12-02 01:58:26.652954	4	customer	2024-12-02 20:45:00	\N	15	\N	\N	\N	\N	Acepto los términos y el costo estimado	4	customer	163	{"scale": 0, "amount": 150, "currency": "CLP"}	\N
97	2024-12-02 01:58:28.820662	2024-12-02 01:58:28.820662	pending	rejected	2024-12-02 01:58:28.820662	15	artist	\N	\N	\N	\N	\N	other	\N	Test additional details	15	artist	165	\N	\N
98	2024-12-02 01:59:08.128348	2024-12-02 01:59:08.128348	pending	canceled	2024-12-02 01:59:08.128348	4	customer	\N	\N	\N	\N	\N	\N	other	\N	4	customer	167	\N	\N
99	2024-12-02 02:00:05.782537	2024-12-02 02:00:05.782537	pending	quoted	2024-12-02 02:00:05.782537	15	artist	\N	2024-12-02 21:30:00	\N	15	\N	\N	\N	Sesión de 2 horas para tatuaje de dragón japonés	15	artist	166	\N	{"scale": 0, "amount": 150, "currency": "CLP"}
100	2024-12-02 02:01:39.474225	2024-12-02 02:01:39.474225	pending	rejected	2024-12-02 02:01:39.474225	15	artist	\N	\N	\N	\N	\N	other	\N	Test additional details	15	artist	170	\N	\N
101	2024-12-02 02:31:51.805898	2024-12-02 02:31:51.805898	pending	canceled	2024-12-02 02:31:51.805898	4	customer	\N	\N	\N	\N	\N	\N	other	\N	4	customer	173	\N	\N
102	2024-12-02 02:33:14.659356	2024-12-02 02:33:14.659356	pending	rejected	2024-12-02 02:33:14.659356	15	artist	\N	\N	\N	\N	\N	other	\N	Test additional details	15	artist	174	\N	\N
103	2024-12-02 02:34:49.371843	2024-12-02 02:34:49.371843	pending	quoted	2024-12-02 02:34:49.371843	15	artist	\N	2024-12-02 20:45:00	\N	15	\N	\N	\N	Sesión de 2 horas para tatuaje de dragón japonés	15	artist	175	\N	{"scale": 0, "amount": 150, "currency": "CLP"}
104	2024-12-02 02:36:33.223822	2024-12-02 02:36:33.223822	pending	quoted	2024-12-02 02:36:33.223822	15	artist	\N	2024-12-02 20:45:00	\N	15	\N	\N	\N	Sesión de 2 horas para tatuaje de dragón japonés	15	artist	176	\N	{"scale": 0, "amount": 150, "currency": "CLP"}
105	2024-12-02 03:13:58.038719	2024-12-02 03:13:58.038719	pending	quoted	2024-12-02 03:13:58.038719	15	artist	\N	2024-12-03 21:15:00	\N	15	\N	\N	\N	Sesión de 2 horas para tatuaje de dragón japonés	15	artist	178	\N	{"scale": 0, "amount": 150, "currency": "CLP"}
106	2024-12-02 03:14:35.797338	2024-12-02 03:14:35.797338	quoted	accepted	2024-12-02 03:14:35.797338	4	customer	2024-12-03 21:15:00	\N	15	\N	\N	\N	\N	Acepto los términos y el costo estimado	4	customer	178	{"scale": 0, "amount": 150, "currency": "CLP"}	\N
107	2024-12-02 03:22:48.059842	2024-12-02 03:22:48.059842	pending	canceled	2024-12-02 03:22:48.059842	4	customer	\N	\N	\N	\N	\N	\N	other	\N	4	customer	180	\N	\N
108	2024-12-02 03:24:02.945009	2024-12-02 03:24:02.945009	pending	quoted	2024-12-02 03:24:02.945009	15	artist	\N	2024-12-03 21:15:00	\N	15	\N	\N	\N	Sesión de 2 horas para tatuaje de dragón japonés	15	artist	179	\N	{"scale": 0, "amount": 150, "currency": "CLP"}
109	2024-12-02 03:24:13.635958	2024-12-02 03:24:13.635958	pending	rejected	2024-12-02 03:24:13.635958	15	artist	\N	\N	\N	\N	\N	other	\N	Test additional details	15	artist	181	\N	\N
110	2024-12-02 03:24:40.696262	2024-12-02 03:24:40.696262	quoted	accepted	2024-12-02 03:24:40.696262	4	customer	2024-12-03 21:15:00	\N	15	\N	\N	\N	\N	Acepto los términos y el costo estimado	4	customer	179	{"scale": 0, "amount": 150, "currency": "CLP"}	\N
111	2024-12-02 03:25:22.000641	2024-12-02 03:25:22.000641	pending	canceled	2024-12-02 03:25:22.000641	4	customer	\N	\N	\N	\N	\N	\N	other	\N	4	customer	183	\N	\N
112	2024-12-02 03:26:40.51477	2024-12-02 03:26:40.51477	pending	rejected	2024-12-02 03:26:40.51477	15	artist	\N	\N	\N	\N	\N	other	\N	Test additional details	15	artist	184	\N	\N
113	2024-12-02 03:28:07.227354	2024-12-02 03:28:07.227354	pending	canceled	2024-12-02 03:28:07.227354	4	customer	\N	\N	\N	\N	\N	\N	other	\N	4	customer	185	\N	\N
114	2024-12-02 03:29:25.328336	2024-12-02 03:29:25.328336	pending	rejected	2024-12-02 03:29:25.328336	15	artist	\N	\N	\N	\N	\N	other	\N	Test additional details	15	artist	186	\N	\N
115	2024-12-02 03:31:28.011099	2024-12-02 03:31:28.011099	pending	canceled	2024-12-02 03:31:28.011099	4	customer	\N	\N	\N	\N	\N	\N	other	\N	4	customer	187	\N	\N
116	2024-12-02 03:32:45.071072	2024-12-02 03:32:45.071072	pending	rejected	2024-12-02 03:32:45.071072	15	artist	\N	\N	\N	\N	\N	other	\N	Test additional details	15	artist	188	\N	\N
117	2024-12-02 03:34:31.259273	2024-12-02 03:34:31.259273	pending	quoted	2024-12-02 03:34:31.259273	15	artist	\N	2024-12-03 21:00:00	\N	15	\N	\N	\N	Sesión de 2 horas para tatuaje de dragón japonés	15	artist	189	\N	{"scale": 0, "amount": 150, "currency": "CLP"}
118	2024-12-02 03:35:09.047121	2024-12-02 03:35:09.047121	quoted	accepted	2024-12-02 03:35:09.047121	4	customer	2024-12-03 21:00:00	\N	15	\N	\N	\N	\N	Acepto los términos y el costo estimado	4	customer	189	{"scale": 0, "amount": 150, "currency": "CLP"}	\N
119	2024-12-03 23:26:14.43989	2024-12-03 23:26:14.43989	pending	canceled	2024-12-03 23:26:14.43989	4	customer	\N	\N	\N	\N	\N	\N	other	\N	4	customer	182	\N	\N
120	2024-12-03 23:28:36.768494	2024-12-03 23:28:36.768494	pending	canceled	2024-12-03 23:28:36.768494	4	customer	\N	\N	\N	\N	\N	\N	other	\N	4	customer	177	\N	\N
121	2024-12-03 23:30:05.937485	2024-12-03 23:30:05.937485	pending	canceled	2024-12-03 23:30:05.937485	4	customer	\N	\N	\N	\N	\N	\N	other	\N	4	customer	190	\N	\N
122	2024-12-12 02:37:08.713893	2024-12-12 02:37:08.713893	pending	canceled	2024-12-12 02:37:08.713893	4	customer	\N	\N	\N	\N	\N	\N	other	\N	4	customer	231	\N	\N
123	2024-12-12 03:09:56.903973	2024-12-12 03:09:56.903973	pending	quoted	2024-12-12 03:09:56.903973	15	artist	\N	2024-12-12 03:30:00	\N	15	\N	\N	\N	adsadsa	15	artist	230	\N	{"scale": 0, "amount": 50, "currency": "CLP"}
124	2024-12-12 03:17:41.183873	2024-12-12 03:17:41.183873	pending	canceled	2024-12-12 03:17:41.183873	4	customer	\N	\N	\N	\N	\N	\N	\N	\N	4	customer	229	\N	\N
125	2024-12-12 03:18:47.938881	2024-12-12 03:18:47.938881	pending	canceled	2024-12-12 03:18:47.938881	4	customer	\N	\N	\N	\N	\N	\N	\N	\N	4	customer	228	\N	\N
126	2024-12-12 03:19:33.509712	2024-12-12 03:19:33.509712	pending	canceled	2024-12-12 03:19:33.509712	4	customer	\N	\N	\N	\N	\N	\N	\N	\N	4	customer	227	\N	\N
127	2024-12-12 03:19:54.526709	2024-12-12 03:19:54.526709	pending	canceled	2024-12-12 03:19:54.526709	4	customer	\N	\N	\N	\N	\N	\N	\N	\N	4	customer	226	\N	\N
128	2024-12-12 03:21:05.024845	2024-12-12 03:21:05.024845	pending	canceled	2024-12-12 03:21:05.024845	4	customer	\N	\N	\N	\N	\N	\N	\N	\N	4	customer	225	\N	\N
129	2024-12-12 03:21:58.685049	2024-12-12 03:21:58.685049	pending	canceled	2024-12-12 03:21:58.685049	4	customer	\N	\N	\N	\N	\N	\N	\N	\N	4	customer	224	\N	\N
130	2024-12-12 03:22:11.079997	2024-12-12 03:22:11.079997	pending	canceled	2024-12-12 03:22:11.079997	4	customer	\N	\N	\N	\N	\N	\N	\N	\N	4	customer	223	\N	\N
131	2024-12-12 03:23:48.758536	2024-12-12 03:23:48.758536	pending	quoted	2024-12-12 03:23:48.758536	15	artist	\N	2024-12-12 01:00:00	\N	15	\N	\N	\N	asdsadad	15	artist	172	\N	{"scale": 0, "amount": 4, "currency": "CLP"}
132	2024-12-12 03:28:52.897974	2024-12-12 03:28:52.897974	pending	quoted	2024-12-12 03:28:52.897974	15	artist	\N	2024-12-12 00:28:47.153	\N	60	\N	\N	\N	asdadsa	15	artist	171	\N	{"scale": 0, "amount": 4, "currency": "CLP"}
133	2024-12-12 03:29:35.727017	2024-12-12 03:29:35.727017	pending	quoted	2024-12-12 03:29:35.727017	15	artist	\N	2024-12-12 00:29:28.448	\N	60	\N	\N	\N	asdsadsad	15	artist	169	\N	{"scale": 0, "amount": 5, "currency": "CLP"}
134	2024-12-13 01:43:05.364017	2024-12-13 01:43:05.364017	pending	quoted	2024-12-13 01:43:05.364017	15	artist	\N	2024-12-12 22:42:59.664	\N	60	\N	\N	\N	dsadad	15	artist	168	\N	{"scale": 0, "amount": 5, "currency": "CLP"}
135	2024-12-13 01:43:36.028695	2024-12-13 01:43:36.028695	pending	quoted	2024-12-13 01:43:36.028695	15	artist	\N	2024-12-12 22:43:29.021	\N	60	\N	\N	\N	asda	15	artist	162	\N	{"scale": 0, "amount": 545, "currency": "CLP"}
136	2024-12-13 01:44:40.112089	2024-12-13 01:44:40.112089	pending	quoted	2024-12-13 01:44:40.112089	15	artist	\N	2024-12-12 22:44:35.967	\N	60	\N	\N	\N		15	artist	157	\N	{"scale": 0, "amount": 12, "currency": "CLP"}
137	2024-12-13 01:46:36.452759	2024-12-13 01:46:36.452759	pending	quoted	2024-12-13 01:46:36.452759	15	artist	\N	2024-12-12 22:46:32.783	\N	60	\N	\N	\N		15	artist	156	\N	{"scale": 0, "amount": 50, "currency": "CLP"}
138	2024-12-13 01:47:57.612168	2024-12-13 01:47:57.612168	pending	quoted	2024-12-13 01:47:57.612168	15	artist	\N	2024-12-12 22:47:53.413	\N	60	\N	\N	\N	asdsadsad	15	artist	155	\N	{"scale": 0, "amount": 435, "currency": "CLP"}
139	2024-12-13 01:48:35.064118	2024-12-13 01:48:35.064118	pending	rejected	2024-12-13 01:48:35.064118	15	artist	\N	\N	\N	\N	\N	artistic_disagreement	\N		15	artist	153	\N	\N
140	2024-12-13 01:49:10.325698	2024-12-13 01:49:10.325698	pending	rejected	2024-12-13 01:49:10.325698	15	artist	\N	\N	\N	\N	\N	artistic_disagreement	\N		15	artist	151	\N	\N
141	2024-12-13 01:55:26.095	2024-12-13 01:55:26.095	pending	rejected	2024-12-13 01:55:26.095	15	artist	\N	\N	\N	\N	\N	artistic_disagreement	\N		15	artist	150	\N	\N
142	2024-12-13 01:55:53.199847	2024-12-13 01:55:53.199847	quoted	accepted	2024-12-13 01:55:53.199847	4	customer	2024-12-12 03:30:00	\N	15	\N	\N	\N	\N	asdasd	4	customer	230	{"scale": 0, "amount": 50, "currency": "CLP"}	\N
143	2024-12-13 01:56:01.972607	2024-12-13 01:56:01.972607	quoted	appealed	2024-12-13 01:56:01.972607	4	customer	2024-12-02 20:45:00	\N	15	\N	price_change	\N	\N	asdada	4	customer	176	{"scale": 0, "amount": 150, "currency": "CLP"}	\N
144	2024-12-13 01:56:11.82552	2024-12-13 01:56:11.82552	quoted	rejected	2024-12-13 01:56:11.82552	4	customer	2024-12-02 20:45:00	\N	15	\N	\N	changed_my_mind	\N	asdsadada	4	customer	175	{"scale": 0, "amount": 150, "currency": "CLP"}	\N
145	2024-12-13 01:56:41.807889	2024-12-13 01:56:41.807889	quoted	rejected	2024-12-13 01:56:41.807889	4	customer	2024-12-12 01:00:00	\N	15	\N	\N	changed_my_mind	\N	asdsadsa	4	customer	172	{"scale": 0, "amount": 4, "currency": "CLP"}	\N
146	2024-12-13 01:57:55.264766	2024-12-13 01:57:55.264766	quoted	rejected	2024-12-13 01:57:55.264766	4	customer	2024-12-12 00:28:47.153	\N	60	\N	\N	changed_my_mind	\N	asdsadada	4	customer	171	{"scale": 0, "amount": 4, "currency": "CLP"}	\N
147	2024-12-13 01:58:57.25655	2024-12-13 01:58:57.25655	quoted	rejected	2024-12-13 01:58:57.25655	4	customer	2024-12-12 00:29:28.448	\N	60	\N	\N	changed_my_mind	\N	asdsadas	4	customer	169	{"scale": 0, "amount": 5, "currency": "CLP"}	\N
148	2024-12-13 01:59:05.407057	2024-12-13 01:59:05.407057	pending	canceled	2024-12-13 01:59:05.407057	4	customer	\N	\N	\N	\N	\N	\N	\N	\N	4	customer	222	\N	\N
149	2024-12-13 02:26:59.774398	2024-12-13 02:26:59.774398	pending	canceled	2024-12-13 02:26:59.774398	4	customer	\N	\N	\N	\N	\N	\N	\N	\N	4	customer	221	\N	\N
150	2024-12-13 02:46:42.24483	2024-12-13 02:46:42.24483	pending	canceled	2024-12-13 02:46:42.24483	4	customer	\N	\N	\N	\N	\N	\N	\N	\N	4	customer	220	\N	\N
151	2024-12-13 02:47:00.192483	2024-12-13 02:47:00.192483	appealed	quoted	2024-12-13 02:47:00.192483	15	artist	2024-12-02 20:45:00	2024-12-12 23:46:53.686	15	60	\N	\N	\N		15	artist	176	{"scale": 0, "amount": 150, "currency": "CLP"}	{"scale": 0, "amount": 123, "currency": "CLP"}
152	2024-12-13 02:47:08.811388	2024-12-13 02:47:08.811388	pending	rejected	2024-12-13 02:47:08.811388	15	artist	\N	\N	\N	\N	\N	artistic_disagreement	\N	asdsad	15	artist	149	\N	\N
153	2024-12-13 02:58:38.572473	2024-12-13 02:58:38.572473	pending	rejected	2024-12-13 02:58:38.572473	15	artist	\N	\N	\N	\N	\N	insufficient_details	\N	adasda	15	artist	148	\N	\N
154	2024-12-14 00:56:06.642245	2024-12-14 00:56:06.642245	pending	canceled	2024-12-14 00:56:06.642245	4	customer	\N	\N	\N	\N	\N	\N	\N	\N	4	customer	219	\N	\N
155	2024-12-14 00:56:37.656561	2024-12-14 00:56:37.656561	pending	canceled	2024-12-14 00:56:37.656561	4	customer	\N	\N	\N	\N	\N	\N	\N	\N	4	customer	218	\N	\N
156	2024-12-14 00:56:43.712005	2024-12-14 00:56:43.712005	pending	canceled	2024-12-14 00:56:43.712005	4	customer	\N	\N	\N	\N	\N	\N	\N	\N	4	customer	217	\N	\N
157	2024-12-14 00:57:07.540275	2024-12-14 00:57:07.540275	pending	canceled	2024-12-14 00:57:07.540275	4	customer	\N	\N	\N	\N	\N	\N	\N	\N	4	customer	216	\N	\N
158	2024-12-14 00:57:14.580354	2024-12-14 00:57:14.580354	pending	canceled	2024-12-14 00:57:14.580354	4	customer	\N	\N	\N	\N	\N	\N	\N	\N	4	customer	215	\N	\N
159	2024-12-14 00:57:26.810786	2024-12-14 00:57:26.810786	pending	canceled	2024-12-14 00:57:26.810786	4	customer	\N	\N	\N	\N	\N	\N	\N	\N	4	customer	214	\N	\N
160	2024-12-14 00:59:12.720335	2024-12-14 00:59:12.720335	pending	canceled	2024-12-14 00:59:12.720335	4	customer	\N	\N	\N	\N	\N	\N	\N	\N	4	customer	213	\N	\N
161	2024-12-14 01:24:54.412215	2024-12-14 01:24:54.412215	pending	canceled	2024-12-14 01:24:54.412215	4	customer	\N	\N	\N	\N	\N	\N	\N	\N	4	customer	212	\N	\N
162	2024-12-14 01:35:43.111647	2024-12-14 01:35:43.111647	quoted	accepted	2024-12-14 01:35:43.111647	4	customer	2024-12-12 23:46:53.686	\N	60	\N	\N	\N	\N		4	customer	176	{"scale": 0, "amount": 123, "currency": "CLP"}	\N
163	2024-12-14 01:36:28.021207	2024-12-14 01:36:28.021207	quoted	accepted	2024-12-14 01:36:28.021207	4	customer	2024-12-12 22:42:59.664	\N	60	\N	\N	\N	\N		4	customer	168	{"scale": 0, "amount": 5, "currency": "CLP"}	\N
164	2024-12-14 01:37:13.623866	2024-12-14 01:37:13.623866	quoted	accepted	2024-12-14 01:37:13.623866	4	customer	2024-12-02 21:30:00	\N	15	\N	\N	\N	\N	demosle mi rey	4	customer	166	{"scale": 0, "amount": 150, "currency": "CLP"}	\N
165	2024-12-14 01:44:47.878625	2024-12-14 01:44:47.878625	pending	canceled	2024-12-14 01:44:47.878625	4	customer	\N	\N	\N	\N	\N	\N	\N	\N	4	customer	232	\N	\N
166	2024-12-14 02:03:42.434909	2024-12-14 02:03:42.434909	pending	canceled	2024-12-14 02:03:42.434909	4	customer	\N	\N	\N	\N	\N	\N	\N	\N	4	customer	233	\N	\N
167	2024-12-14 02:04:19.716213	2024-12-14 02:04:19.716213	pending	rejected	2024-12-14 02:04:19.716213	15	artist	\N	\N	\N	\N	\N	artistic_disagreement	\N	adasdasd	15	artist	147	\N	\N
168	2024-12-14 02:09:05.505481	2024-12-14 02:09:05.505481	pending	canceled	2024-12-14 02:09:05.505481	4	customer	\N	\N	\N	\N	\N	\N	\N	\N	4	customer	234	\N	\N
169	2024-12-14 02:10:51.088458	2024-12-14 02:10:51.088458	pending	rejected	2024-12-14 02:10:51.088458	15	artist	\N	\N	\N	\N	\N	artistic_disagreement	\N		15	artist	146	\N	\N
170	2024-12-14 02:11:44.059014	2024-12-14 02:11:44.059014	pending	rejected	2024-12-14 02:11:44.059014	15	artist	\N	\N	\N	\N	\N	insufficient_details	\N		15	artist	145	\N	\N
171	2024-12-14 03:40:16.250651	2024-12-14 03:40:16.250651	pending	rejected	2024-12-14 03:40:16.250651	15	artist	\N	\N	\N	\N	\N	artistic_disagreement	\N		15	artist	144	\N	\N
172	2024-12-14 03:44:48.905446	2024-12-14 03:44:48.905446	pending	quoted	2024-12-14 03:44:48.905446	15	artist	\N	2024-12-14 00:44:45.792	\N	60	\N	\N	\N		15	artist	235	\N	{"scale": 0, "amount": 1, "currency": "CLP"}
173	2024-12-14 03:45:25.815978	2024-12-14 03:45:25.815978	quoted	rejected	2024-12-14 03:45:25.815978	4	customer	2024-12-14 00:44:45.792	\N	60	\N	\N	changed_my_mind	\N	asdasdsadas	4	customer	235	{"scale": 0, "amount": 1, "currency": "CLP"}	\N
174	2024-12-14 03:46:30.468633	2024-12-14 03:46:30.468633	pending	rejected	2024-12-14 03:46:30.468633	15	artist	\N	\N	\N	\N	\N	insufficient_details	\N	111111	15	artist	236	\N	\N
175	2024-12-17 00:38:41.195095	2024-12-17 00:38:41.195095	pending	canceled	2024-12-17 00:38:41.195095	4	customer	\N	\N	\N	\N	\N	\N	\N	\N	4	customer	237	\N	\N
176	2024-12-17 02:08:46.184067	2024-12-17 02:08:46.184067	quoted	accepted	2024-12-17 02:08:46.184067	4	customer	2024-12-12 22:43:29.021	\N	60	\N	\N	\N	\N	lslala	4	customer	162	{"scale": 0, "amount": 545, "currency": "CLP"}	\N
177	2024-12-17 02:29:49.852129	2024-12-17 02:29:49.852129	quoted	accepted	2024-12-17 02:29:49.852129	4	customer	2024-12-12 22:47:53.413	\N	60	\N	\N	\N	\N		4	customer	155	{"scale": 0, "amount": 435, "currency": "CLP"}	\N
178	2024-12-17 02:46:32.726331	2024-12-17 02:46:32.726331	quoted	accepted	2024-12-17 02:46:32.726331	4	customer	2024-12-12 22:46:32.783	\N	60	\N	\N	\N	\N		4	customer	156	{"scale": 0, "amount": 50, "currency": "CLP"}	\N
179	2024-12-17 02:47:22.526759	2024-12-17 02:47:22.526759	quoted	accepted	2024-12-17 02:47:22.526759	4	customer	2024-12-12 22:44:35.967	\N	60	\N	\N	\N	\N		4	customer	157	{"scale": 0, "amount": 12, "currency": "CLP"}	\N
180	2024-12-17 02:47:57.140547	2024-12-17 02:47:57.140547	quoted	accepted	2024-12-17 02:47:57.140547	4	customer	2024-12-02 20:45:00	\N	15	\N	\N	\N	\N		4	customer	160	{"scale": 0, "amount": 150, "currency": "CLP"}	\N
181	2024-12-17 02:48:43.100351	2024-12-17 02:48:43.100351	quoted	accepted	2024-12-17 02:48:43.100351	4	customer	2024-12-02 09:00:00	\N	15	\N	\N	\N	\N		4	customer	134	{"scale": 0, "amount": 150, "currency": "CLP"}	\N
182	2024-12-17 03:07:44.275848	2024-12-17 03:07:44.275848	pending	quoted	2024-12-17 03:07:44.275848	15	artist	\N	2024-12-17 10:00:00	\N	60	\N	\N	\N	ok vamosle	15	artist	238	\N	{"scale": 0, "amount": 50, "currency": "CLP"}
183	2024-12-17 03:08:12.681894	2024-12-17 03:08:12.681894	quoted	accepted	2024-12-17 03:08:12.681894	4	customer	2024-12-17 10:00:00	\N	60	\N	\N	\N	\N		4	customer	238	{"scale": 0, "amount": 50, "currency": "CLP"}	\N
184	2024-12-19 00:44:18.832334	2024-12-19 00:44:18.832334	pending	quoted	2024-12-19 00:44:18.832334	31	artist	\N	2024-12-18 21:43:45.315	\N	60	\N	\N	\N	sale 50 mil compa	31	artist	202	\N	{"scale": 0, "amount": 50, "currency": "CLP"}
185	2024-12-20 03:40:46.064989	2024-12-20 03:40:46.064989	pending	rejected	2024-12-20 03:40:46.064989	1	artist	\N	\N	\N	\N	\N	insufficient_details	\N	nope	1	artist	240	\N	\N
186	2024-12-20 03:41:15.457204	2024-12-20 03:41:15.457204	pending	quoted	2024-12-20 03:41:15.457204	1	artist	\N	2024-12-20 04:41:00	\N	60	\N	\N	\N	oks	1	artist	239	\N	{"scale": 0, "amount": 50, "currency": "CLP"}
187	2024-12-20 03:41:49.331365	2024-12-20 03:41:49.331365	quoted	accepted	2024-12-20 03:41:49.331365	6	customer	2024-12-20 04:41:00	\N	60	\N	\N	\N	\N	wena	6	customer	239	{"scale": 0, "amount": 50, "currency": "CLP"}	\N
188	2024-12-20 03:44:28.220108	2024-12-20 03:44:28.220108	pending	rejected	2024-12-20 03:44:28.220108	1	artist	\N	\N	\N	\N	\N	insufficient_details	\N	nope\n	1	artist	207	\N	\N
189	2024-12-20 03:45:05.294802	2024-12-20 03:45:05.294802	pending	rejected	2024-12-20 03:45:05.294802	1	artist	\N	\N	\N	\N	\N	insufficient_details	\N	huj	1	artist	208	\N	\N
190	2024-12-20 03:45:49.421639	2024-12-20 03:45:49.421639	pending	rejected	2024-12-20 03:45:49.421639	1	artist	\N	\N	\N	\N	\N	insufficient_details	\N	noned	1	artist	209	\N	\N
191	2024-12-20 03:46:14.81903	2024-12-20 03:46:14.81903	pending	rejected	2024-12-20 03:46:14.81903	1	artist	\N	\N	\N	\N	\N	insufficient_details	\N	nones	1	artist	210	\N	\N
192	2024-12-20 03:46:35.198391	2024-12-20 03:46:35.198391	pending	rejected	2024-12-20 03:46:35.198391	1	artist	\N	\N	\N	\N	\N	insufficient_details	\N		1	artist	211	\N	\N
193	2024-12-20 03:47:10.832461	2024-12-20 03:47:10.832461	pending	quoted	2024-12-20 03:47:10.832461	1	artist	\N	2024-12-20 00:47:08.036	\N	60	\N	\N	\N		1	artist	206	\N	{"scale": 0, "amount": 50, "currency": "CLP"}
194	2024-12-20 03:53:10.307605	2024-12-20 03:53:10.307605	pending	canceled	2024-12-20 03:53:10.307605	6	customer	\N	\N	\N	\N	\N	\N	\N	\N	6	customer	241	\N	\N
195	2024-12-20 03:54:55.167391	2024-12-20 03:54:55.167391	pending	quoted	2024-12-20 03:54:55.167391	29	artist	\N	2025-01-01 09:54:00	\N	60	\N	\N	\N	holis	29	artist	242	\N	{"scale": 0, "amount": 50, "currency": "CLP"}
196	2024-12-20 03:55:38.879028	2024-12-20 03:55:38.879028	quoted	accepted	2024-12-20 03:55:38.879028	6	customer	2025-01-01 09:54:00	\N	60	\N	\N	\N	\N		6	customer	242	{"scale": 0, "amount": 50, "currency": "CLP"}	\N
197	2024-12-21 23:50:20.440327	2024-12-21 23:50:20.440327	pending	canceled	2024-12-21 23:50:20.440327	6	customer	\N	\N	\N	\N	\N	\N	\N	\N	6	customer	243	\N	\N
198	2024-12-22 00:17:01.582393	2024-12-22 00:17:01.582393	pending	quoted	2024-12-22 00:17:01.582393	30	artist	\N	2025-01-14 16:16:00	\N	60	\N	\N	\N	weno	30	artist	244	\N	{"scale": 0, "amount": 50, "currency": "CLP"}
199	2024-12-22 00:17:48.352191	2024-12-22 00:17:48.352191	quoted	accepted	2024-12-22 00:17:48.352191	37	customer	2025-01-14 16:16:00	\N	60	\N	\N	\N	\N		37	customer	244	{"scale": 0, "amount": 50, "currency": "CLP"}	\N
200	2025-03-07 02:00:10.452259	2025-03-07 02:00:10.452259	pending	quoted	2025-03-07 02:00:10.452259	29	artist	\N	2025-03-06 12:00:00	\N	15	\N	\N	\N		29	artist	259	\N	{"scale": 0, "amount": 50, "currency": "CLP"}
201	2025-03-07 02:01:25.727985	2025-03-07 02:01:25.727985	quoted	accepted	2025-03-07 02:01:25.727985	6	customer	2025-03-06 12:00:00	\N	15	\N	\N	\N	\N		6	customer	259	{"scale": 0, "amount": 50, "currency": "CLP"}	\N
202	2025-03-07 02:03:24.143542	2025-03-07 02:03:24.143542	pending	rejected	2025-03-07 02:03:24.143542	29	artist	\N	\N	\N	\N	\N	beyond_expertise	\N		29	artist	256	\N	\N
203	2025-03-07 02:10:29.508052	2025-03-07 02:10:29.508052	pending	rejected	2025-03-07 02:10:29.508052	29	artist	\N	\N	\N	\N	\N	insufficient_details	\N		29	artist	261	\N	\N
204	2025-03-07 02:11:13.251649	2025-03-07 02:11:13.251649	pending	quoted	2025-03-07 02:11:13.251649	29	artist	\N	2025-03-06 23:11:10.478	\N	60	\N	\N	\N		29	artist	262	\N	{"scale": 0, "amount": 50, "currency": "CLP"}
205	2025-03-07 02:12:24.68908	2025-03-07 02:12:24.68908	quoted	accepted	2025-03-07 02:12:24.68908	6	customer	2025-03-06 23:11:10.478	\N	60	\N	\N	\N	\N	adasda	6	customer	262	{"scale": 0, "amount": 50, "currency": "CLP"}	\N
206	2025-03-07 02:25:18.965424	2025-03-07 02:25:18.965424	pending	rejected	2025-03-07 02:25:18.965424	29	artist	\N	\N	\N	\N	\N	insufficient_details	\N		29	artist	263	\N	\N
207	2025-03-07 21:17:47.708162	2025-03-07 21:17:47.708162	pending	rejected	2025-03-07 21:17:47.708162	29	artist	\N	\N	\N	\N	\N	scheduling_conflict	\N		29	artist	257	\N	\N
208	2025-03-07 21:18:44.310498	2025-03-07 21:18:44.310498	pending	quoted	2025-03-07 21:18:44.310498	29	artist	\N	2025-03-07 10:45:00	\N	15	\N	\N	\N	ji un B	29	artist	264	\N	{"scale": 0, "amount": 3, "currency": "CLP"}
209	2025-03-07 21:19:03.99547	2025-03-07 21:19:03.99547	quoted	accepted	2025-03-07 21:19:03.99547	6	customer	2025-03-07 10:45:00	\N	15	\N	\N	\N	\N	dasdad	6	customer	264	{"scale": 0, "amount": 3, "currency": "CLP"}	\N
210	2025-03-12 02:04:40.414268	2025-03-12 02:04:40.414268	pending	quoted	2025-03-12 02:04:40.414268	29	artist	\N	2025-03-11 12:30:00	\N	15	\N	\N	\N	oks\n	29	artist	265	\N	{"scale": 0, "amount": 5, "currency": "CLP"}
\.


--
-- Data for Name: quotation_history_backup; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.quotation_history_backup (id, created_at, updated_at, previous_status, new_status, changed_at, changed_by, changed_by_user_type, previous_appointment_date, new_appointment_date, previous_appointment_duration, new_appointment_duration, appealed_reason, rejection_reason, cancellation_reason, additional_details, last_updated_by, last_updated_by_user_type, quotation_id, previous_estimated_cost, new_estimated_cost) FROM stdin;
1	2024-09-02 03:54:28.740468	2024-09-02 03:54:28.740468	pending	canceled	2024-09-02 03:54:28.740468	4	customer	\N	\N	\N	\N	\N	\N	other	\N	4	customer	30	\N	\N
2	2024-09-02 03:58:08.521864	2024-09-02 03:58:08.521864	pending	canceled	2024-09-02 03:58:08.521864	4	customer	\N	\N	\N	\N	\N	\N	other	\N	4	customer	28	\N	\N
3	2024-09-02 04:03:09.780408	2024-09-02 04:03:09.780408	pending	canceled	2024-09-02 04:03:09.780408	4	customer	\N	\N	\N	\N	\N	\N	other	\N	4	customer	27	\N	\N
4	2024-09-02 04:03:22.331327	2024-09-02 04:03:22.331327	pending	canceled	2024-09-02 04:03:22.331327	4	customer	\N	\N	\N	\N	\N	\N	other	\N	4	customer	26	\N	\N
5	2024-09-02 04:07:46.580578	2024-09-02 04:07:46.580578	pending	canceled	2024-09-02 04:07:46.580578	4	customer	\N	\N	\N	\N	\N	\N	other	\N	4	customer	25	\N	\N
6	2024-09-02 04:12:38.015529	2024-09-02 04:12:38.015529	pending	canceled	2024-09-02 04:12:38.015529	4	customer	\N	\N	\N	\N	\N	\N	other	\N	4	customer	24	\N	\N
7	2024-09-02 04:19:53.317099	2024-09-02 04:19:53.317099	pending	canceled	2024-09-02 04:19:53.317099	4	customer	\N	\N	\N	\N	\N	\N	other	\N	4	customer	29	\N	\N
8	2024-09-02 04:20:05.135533	2024-09-02 04:20:05.135533	pending	canceled	2024-09-02 04:20:05.135533	4	customer	\N	\N	\N	\N	\N	\N	other	\N	4	customer	20	\N	\N
9	2024-09-02 04:25:38.056818	2024-09-02 04:25:38.056818	pending	canceled	2024-09-02 04:25:38.056818	4	customer	\N	\N	\N	\N	\N	\N	other	\N	4	customer	22	\N	\N
10	2024-09-02 04:29:01.881133	2024-09-02 04:29:01.881133	pending	canceled	2024-09-02 04:29:01.881133	4	customer	\N	\N	\N	\N	\N	\N	other	\N	4	customer	23	\N	\N
11	2024-09-02 04:32:32.870413	2024-09-02 04:32:32.870413	pending	canceled	2024-09-02 04:32:32.870413	4	customer	\N	\N	\N	\N	\N	\N	other	\N	4	customer	21	\N	\N
12	2024-09-02 04:32:44.226685	2024-09-02 04:32:44.226685	pending	canceled	2024-09-02 04:32:44.226685	4	customer	\N	\N	\N	\N	\N	\N	other	\N	4	customer	19	\N	\N
13	2024-09-02 04:33:11.078061	2024-09-02 04:33:11.078061	pending	canceled	2024-09-02 04:33:11.078061	4	customer	\N	\N	\N	\N	\N	\N	other	\N	4	customer	18	\N	\N
14	2024-09-03 02:13:50.140335	2024-09-03 02:13:50.140335	pending	canceled	2024-09-03 02:13:50.140335	4	customer	\N	\N	\N	\N	\N	\N	other	\N	4	customer	17	\N	\N
15	2024-09-12 02:38:09.745533	2024-09-12 02:38:09.745533	pending	quoted	2024-09-12 02:38:09.745533	15	artist	\N	2024-09-27 00:00:00	\N	15	\N	\N	\N		15	artist	16	\N	\N
16	2024-09-12 03:13:14.526225	2024-09-12 03:13:14.526225	pending	quoted	2024-09-12 03:13:14.526225	15	artist	\N	2024-09-25 21:00:00	\N	\N	\N	\N	\N	\n	15	artist	15	\N	\N
17	2024-09-12 03:15:58.6464	2024-09-12 03:15:58.6464	pending	quoted	2024-09-12 03:15:58.6464	15	artist	\N	2024-09-22 21:00:00	\N	\N	\N	\N	\N		15	artist	14	\N	\N
18	2024-09-12 03:19:09.165621	2024-09-12 03:19:09.165621	pending	quoted	2024-09-12 03:19:09.165621	15	artist	\N	2024-09-22 21:00:00	\N	\N	\N	\N	\N		15	artist	13	\N	\N
19	2024-09-12 03:20:17.925579	2024-09-12 03:20:17.925579	pending	quoted	2024-09-12 03:20:17.925579	15	artist	\N	2024-09-24 09:19:00	\N	120	\N	\N	\N		15	artist	10	\N	\N
20	2024-09-12 03:21:12.610153	2024-09-12 03:21:12.610153	pending	quoted	2024-09-12 03:21:12.610153	15	artist	\N	2024-09-23 18:20:00	\N	60	\N	\N	\N		15	artist	5	\N	\N
21	2024-09-12 03:25:31.68839	2024-09-12 03:25:31.68839	pending	quoted	2024-09-12 03:25:31.68839	15	artist	\N	2024-09-30 17:24:00	\N	120	\N	\N	\N		15	artist	12	\N	\N
22	2024-09-14 06:12:12.868856	2024-09-14 06:12:12.868856	pending	quoted	2024-09-14 06:12:12.868856	1	artist	\N	2024-09-14 04:11:00	\N	60	\N	\N	\N		1	artist	11	\N	\N
23	2024-09-14 06:15:19.540943	2024-09-14 06:15:19.540943	pending	quoted	2024-09-14 06:15:19.540943	1	artist	\N	2024-09-14 19:00:00	\N	60	\N	\N	\N		1	artist	4	\N	\N
24	2024-09-14 21:32:41.867685	2024-09-14 21:32:41.867685	pending	quoted	2024-09-14 21:32:41.867685	1	artist	\N	2024-09-14 19:31:00	\N	60	\N	\N	\N		1	artist	37	\N	\N
25	2024-09-15 03:30:26.737254	2024-09-15 03:30:26.737254	pending	quoted	2024-09-15 03:30:26.737254	1	artist	\N	2024-09-17 02:31:00	\N	60	\N	\N	\N		1	artist	35	\N	\N
26	2024-09-15 03:36:52.87781	2024-09-15 03:36:52.87781	pending	quoted	2024-09-15 03:36:52.87781	1	artist	\N	2024-09-15 14:36:00	\N	60	\N	\N	\N		1	artist	36	\N	\N
27	2024-09-15 03:53:56.2358	2024-09-15 03:53:56.2358	pending	quoted	2024-09-15 03:53:56.2358	1	artist	\N	2024-09-15 01:53:00	\N	60	\N	\N	\N		1	artist	34	\N	\N
28	2024-09-15 03:54:21.491803	2024-09-15 03:54:21.491803	pending	quoted	2024-09-15 03:54:21.491803	1	artist	\N	2024-09-15 01:54:00	\N	60	\N	\N	\N		1	artist	33	\N	\N
29	2024-09-15 04:55:14.892063	2024-09-15 04:55:14.892063	pending	quoted	2024-09-15 04:55:14.892063	1	artist	\N	2024-09-15 02:55:00	\N	60	\N	\N	\N		1	artist	32	\N	\N
30	2024-09-15 04:56:18.057887	2024-09-15 04:56:18.057887	pending	quoted	2024-09-15 04:56:18.057887	1	artist	\N	2024-09-15 02:56:00	\N	60	\N	\N	\N		1	artist	31	\N	\N
31	2024-09-15 05:07:11.292051	2024-09-15 05:07:11.292051	pending	quoted	2024-09-15 05:07:11.292051	1	artist	\N	2024-09-15 05:06:00	\N	60	\N	\N	\N		1	artist	76	\N	\N
32	2024-09-15 05:25:00.539654	2024-09-15 05:25:00.539654	pending	quoted	2024-09-15 05:25:00.539654	1	artist	\N	2024-09-15 05:24:00	\N	60	\N	\N	\N		1	artist	75	\N	\N
33	2024-09-15 23:05:46.423641	2024-09-15 23:05:46.423641	pending	rejected	2024-09-15 23:05:46.423641	1	artist	\N	\N	\N	0	\N	artistic_disagreement	\N		1	artist	74	\N	\N
34	2024-09-16 01:11:02.667611	2024-09-16 01:11:02.667611	pending	quoted	2024-09-16 01:11:02.667611	1	artist	\N	2024-09-15 23:10:00	\N	60	\N	\N	\N		1	artist	73	\N	\N
35	2024-09-16 02:08:59.715166	2024-09-16 02:08:59.715166	pending	rejected	2024-09-16 02:08:59.715166	1	artist	\N	\N	\N	0	\N	other	\N		1	artist	72	\N	\N
36	2024-09-16 02:13:11.029973	2024-09-16 02:13:11.029973	pending	quoted	2024-09-16 02:13:11.029973	1	artist	\N	2024-09-16 17:13:00	\N	357	\N	\N	\N		1	artist	71	\N	\N
37	2024-09-16 03:10:50.511062	2024-09-16 03:10:50.511062	pending	rejected	2024-09-16 03:10:50.511062	1	artist	\N	\N	\N	0	\N	insufficient_details	\N		1	artist	70	\N	\N
38	2024-09-16 03:22:21.720119	2024-09-16 03:22:21.720119	pending	quoted	2024-09-16 03:22:21.720119	1	artist	\N	2024-09-16 01:22:00	\N	60	\N	\N	\N		1	artist	69	\N	\N
39	2024-09-16 03:22:50.650955	2024-09-16 03:22:50.650955	pending	rejected	2024-09-16 03:22:50.650955	1	artist	\N	\N	\N	0	\N	insufficient_details	\N		1	artist	68	\N	\N
40	2024-09-20 17:50:56.738516	2024-09-20 17:50:56.738516	pending	rejected	2024-09-20 17:50:56.738516	1	artist	\N	\N	\N	0	\N	artistic_disagreement	\N		1	artist	67	\N	\N
41	2024-10-21 01:37:56.044411	2024-10-21 01:37:56.044411	quoted	appealed	2024-10-21 01:37:56.044411	4	customer	2024-09-27 00:00:00	\N	15	\N	price_change	\N	\N	un ultimo precio?	4	customer	16	\N	\N
42	2024-10-21 01:39:27.374201	2024-10-21 01:39:27.374201	quoted	rejected	2024-10-21 01:39:27.374201	4	customer	2024-09-25 21:00:00	\N	\N	\N	\N	too_expensive	\N	muy caro man	4	customer	15	\N	\N
43	2024-10-21 01:39:57.536438	2024-10-21 01:39:57.536438	quoted	accepted	2024-10-21 01:39:57.536438	4	customer	2024-09-22 21:00:00	\N	\N	\N	\N	\N	\N		4	customer	14	\N	\N
44	2024-10-27 18:49:25.386346	2024-10-27 18:49:25.386346	pending	canceled	2024-10-27 18:49:25.386346	4	customer	\N	\N	\N	\N	\N	\N	other	\N	4	customer	83	\N	\N
45	2024-10-27 18:50:31.840535	2024-10-27 18:50:31.840535	pending	canceled	2024-10-27 18:50:31.840535	4	customer	\N	\N	\N	\N	\N	\N	other	\N	4	customer	84	\N	\N
46	2024-10-27 18:55:34.832549	2024-10-27 18:55:34.832549	pending	rejected	2024-10-27 18:55:34.832549	1	artist	\N	\N	\N	0	\N	scheduling_conflict	\N		1	artist	85	\N	\N
47	2024-10-27 19:30:45.914036	2024-10-27 19:30:45.914036	pending	quoted	2024-10-27 19:30:45.914036	1	artist	\N	2024-11-06 18:30:00	\N	120	\N	\N	\N		1	artist	86	\N	\N
48	2024-10-27 19:31:00.823381	2024-10-27 19:31:00.823381	quoted	appealed	2024-10-27 19:31:00.823381	4	customer	2024-11-06 18:30:00	\N	120	\N	price_change	\N	\N	muy caro compa	4	customer	86	\N	\N
49	2024-10-28 01:48:11.623327	2024-10-28 01:48:11.623327	appealed	accepted	2024-10-28 01:48:11.623327	1	artist	2024-11-06 18:30:00	\N	120	0	\N	\N	\N	démosle choro	1	artist	86	\N	\N
50	2024-11-04 02:06:02.653841	2024-11-04 02:06:02.653841	quoted	appealed	2024-11-04 02:06:02.653841	4	customer	2024-09-22 21:00:00	\N	\N	\N	design_change	\N	\N	hagamos otra cosa we	4	customer	13	\N	\N
51	2024-11-10 04:17:33.797746	2024-11-10 04:17:33.797746	appealed	quoted	2024-11-10 04:17:33.797746	15	artist	2024-09-27 00:00:00	2024-11-10 02:16:00	15	60	\N	\N	\N		15	artist	16	{"scale": 2, "amount": 500000, "currency": "USD"}	{"scale": 0, "amount": 500, "currency": "CLP"}
\.


--
-- Name: agenda_event_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.agenda_event_history_id_seq', 6, true);


--
-- Name: agenda_event_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.agenda_event_id_seq', 15, true);


--
-- Name: agenda_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.agenda_id_seq', 12, true);


--
-- Name: agenda_invitation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.agenda_invitation_id_seq', 5, true);


--
-- Name: agenda_unavailable_time_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.agenda_unavailable_time_id_seq', 2, true);


--
-- Name: quotation_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.quotation_history_id_seq', 210, true);


--
-- Name: quotation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.quotation_id_seq', 267, true);


--
-- Name: agenda_event PK_2d1f04ea60f7ca9b758000ad5dc; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.agenda_event
    ADD CONSTRAINT "PK_2d1f04ea60f7ca9b758000ad5dc" PRIMARY KEY (id);


--
-- Name: agenda PK_49397cfc20589bebaac8b43251d; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.agenda
    ADD CONSTRAINT "PK_49397cfc20589bebaac8b43251d" PRIMARY KEY (id);


--
-- Name: agenda_event_history PK_580077f240837b5cdb035b37916; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.agenda_event_history
    ADD CONSTRAINT "PK_580077f240837b5cdb035b37916" PRIMARY KEY (id);


--
-- Name: quotation PK_596c572d5858492d10d8cf5383d; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.quotation
    ADD CONSTRAINT "PK_596c572d5858492d10d8cf5383d" PRIMARY KEY (id);


--
-- Name: agenda_invitation PK_90721b8d5e50986a26a8830b6fd; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.agenda_invitation
    ADD CONSTRAINT "PK_90721b8d5e50986a26a8830b6fd" PRIMARY KEY (id);


--
-- Name: quotation_history PK_a14a0b9bfa5bb74d3a46c0a7ee6; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.quotation_history
    ADD CONSTRAINT "PK_a14a0b9bfa5bb74d3a46c0a7ee6" PRIMARY KEY (id);


--
-- Name: agenda_unavailable_time PK_e37b45f59e0f89bf7b21c93455b; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.agenda_unavailable_time
    ADD CONSTRAINT "PK_e37b45f59e0f89bf7b21c93455b" PRIMARY KEY (id);


--
-- Name: agenda_invitation REL_a4be6d79f7ac6e0ff252361f5f; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.agenda_invitation
    ADD CONSTRAINT "REL_a4be6d79f7ac6e0ff252361f5f" UNIQUE (event_id);


--
-- Name: IDX_0819be156d36ead6e3a10d7391; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_0819be156d36ead6e3a10d7391" ON public.agenda_event USING btree (quotation_id);


--
-- Name: IDX_085cd03c647cd3f2f2045dbbd0; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_085cd03c647cd3f2f2045dbbd0" ON public.agenda_unavailable_time USING btree (start_date);


--
-- Name: IDX_50ece0401edd36c92ecfa43d5d; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_50ece0401edd36c92ecfa43d5d" ON public.agenda_event USING btree (start_date);


--
-- Name: IDX_51cea2e92a1684c6f5dec0be77; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_51cea2e92a1684c6f5dec0be77" ON public.agenda_event USING btree (customer_id);


--
-- Name: IDX_5ad973140c6162b87c4780477c; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_5ad973140c6162b87c4780477c" ON public.agenda_event USING btree (end_date);


--
-- Name: IDX_703dc0714a96b3a6872d0978a1; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_703dc0714a96b3a6872d0978a1" ON public.agenda_event USING btree (start_date, end_date);


--
-- Name: IDX_76f0dc9ea1b280b659485e1c56; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_76f0dc9ea1b280b659485e1c56" ON public.agenda_unavailable_time USING btree (end_date);


--
-- Name: IDX_95663d2c16f5445a1b677d5482; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_95663d2c16f5445a1b677d5482" ON public.quotation USING btree (artist_id);


--
-- Name: IDX_9b0f71bc992eacc3909e1f3866; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_9b0f71bc992eacc3909e1f3866" ON public.agenda_unavailable_time USING btree (start_date, end_date);


--
-- Name: IDX_a4be6d79f7ac6e0ff252361f5f; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_a4be6d79f7ac6e0ff252361f5f" ON public.agenda_invitation USING btree (event_id);


--
-- Name: IDX_a9d713d3bd3c54be56263cb76e; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_a9d713d3bd3c54be56263cb76e" ON public.quotation USING btree (customer_id);


--
-- Name: IDX_c9083b6cdc404ea78948b7b625; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_c9083b6cdc404ea78948b7b625" ON public.agenda USING btree (artist_id);


--
-- Name: idx_agenda_id; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX idx_agenda_id ON public.agenda_event USING btree (agenda_id);


--
-- Name: quotation_history FK_17ee753f917de8c53ca06c6425f; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.quotation_history
    ADD CONSTRAINT "FK_17ee753f917de8c53ca06c6425f" FOREIGN KEY (quotation_id) REFERENCES public.quotation(id);


--
-- Name: agenda_event_history FK_23d67ae396d322090e5cc4fed29; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.agenda_event_history
    ADD CONSTRAINT "FK_23d67ae396d322090e5cc4fed29" FOREIGN KEY (event_id) REFERENCES public.agenda_event(id);


--
-- Name: agenda_event FK_52830e038af1114957b8f95a507; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.agenda_event
    ADD CONSTRAINT "FK_52830e038af1114957b8f95a507" FOREIGN KEY (agenda_id) REFERENCES public.agenda(id);


--
-- Name: agenda_invitation FK_a4be6d79f7ac6e0ff252361f5f7; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.agenda_invitation
    ADD CONSTRAINT "FK_a4be6d79f7ac6e0ff252361f5f7" FOREIGN KEY (event_id) REFERENCES public.agenda_event(id);


--
-- Name: agenda_unavailable_time FK_f8ca0c062bf614bbcb27172e890; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.agenda_unavailable_time
    ADD CONSTRAINT "FK_f8ca0c062bf614bbcb27172e890" FOREIGN KEY (agenda_id) REFERENCES public.agenda(id);


--
-- PostgreSQL database dump complete
--

