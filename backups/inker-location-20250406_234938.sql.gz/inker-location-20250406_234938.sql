--
-- PostgreSQL database dump
--

-- Dumped from database version 17.2 (Debian 17.2-1.pgdg110+1)
-- Dumped by pg_dump version 17.2 (Debian 17.2-1.pgdg110+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: postgis; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis WITH SCHEMA public;


--
-- Name: EXTENSION postgis; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION postgis IS 'PostGIS geometry and geography spatial types and functions';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: AddressType; Type: TYPE; Schema: public; Owner: root
--

CREATE TYPE public."AddressType" AS ENUM (
    'HOME',
    'DEPARTMENT',
    'STUDIO',
    'OFFICE'
);


ALTER TYPE public."AddressType" OWNER TO root;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: artist_location; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.artist_location (
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    address1 character varying(100) NOT NULL,
    short_address1 character varying(100),
    address2 character varying(50) NOT NULL,
    address3 character varying(50),
    address_type public."AddressType" DEFAULT 'HOME'::public."AddressType" NOT NULL,
    state character varying(100),
    city character varying(100),
    country character varying(20),
    formatted_address character varying(255),
    lat double precision NOT NULL,
    lng double precision NOT NULL,
    viewport jsonb,
    location public.geography(Point,4326),
    name character varying NOT NULL,
    profile_thumbnail character varying,
    google_place_id character varying,
    location_order integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    artist_id integer
);


ALTER TABLE public.artist_location OWNER TO root;

--
-- Name: event_location; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.event_location (
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    address1 character varying(100) NOT NULL,
    short_address1 character varying(100),
    address2 character varying(50) NOT NULL,
    address3 character varying(50),
    address_type public."AddressType" DEFAULT 'HOME'::public."AddressType" NOT NULL,
    state character varying(100),
    city character varying(100),
    country character varying(20),
    formatted_address character varying(255),
    lat double precision NOT NULL,
    lng double precision NOT NULL,
    viewport jsonb,
    location public.geography(Point,4326),
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL
);


ALTER TABLE public.event_location OWNER TO root;

--
-- Data for Name: artist_location; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.artist_location (created_at, updated_at, address1, short_address1, address2, address3, address_type, state, city, country, formatted_address, lat, lng, viewport, location, name, profile_thumbnail, google_place_id, location_order, is_active, id, artist_id) FROM stdin;
2023-01-10 00:03:20.646773	2023-01-10 00:03:20.646773	Avenida Vicuña Mackenna	Av. Vicuña Mackenna	6100	Depto 1008	DEPARTMENT	Región Metropolitana	La Florida	Chile	Av. Vicuña Mackenna 6100, La Florida, Región Metropolitana, Chile	-33.511334	-70.6102933	{"northeast": {"lat": -33.5100508197085, "lng": -70.60904166970849}, "southwest": {"lat": -33.5127487802915, "lng": -70.61173963029151}}	0101000020E6100000F21DA10B0FA751C09BAA7B6473C140C0	Juanart Art	\N	ChIJa6nN23HQYpYR3qGDC1QQIHs	0	t	ae3bde2b-498a-44b1-a372-a116b50729b9	\N
2023-01-10 00:08:58.583857	2023-01-10 00:08:58.583857	Veinticuatro Oriente	Veinticuatro Ote.	6345		HOME	Región Metropolitana	La Granja	Chile	Veinticuatro Ote. 6345, La Granja, Región Metropolitana, Chile	-33.5152054	-70.6206179	{"northeast": {"lat": -33.51385641970851, "lng": -70.61926891970849}, "southwest": {"lat": -33.51655438029151, "lng": -70.62196688029151}}	0101000020E6100000FBF32334B8A751C07EDC2340F2C140C0	Loco Ree	\N	EihWZWludGljdWF0cm8gT3RlLiA2MzQ1LCBMYSBHcmFuamEsIENoaWxlIjESLwoUChIJ4W0w7HfQYpYR10w1L7wrTeMQyTEqFAoSCeVsAvB30GKWEQOEq2heWxkz	0	t	28fe3d9b-f535-434a-ab92-fba1dd0ed8ef	\N
2023-01-10 00:12:53.777547	2023-01-10 00:12:53.777547	Santa Claus	Sta. Claus	7482		HOME	Región Metropolitana	La Florida	Chile	Sta. Claus 7482, La Florida, Región Metropolitana, Chile	-33.522868	-70.60475819999999	{"northeast": {"lat": -33.5215190197085, "lng": -70.60340921970848}, "southwest": {"lat": -33.5242169802915, "lng": -70.6061071802915}}	0101000020E610000038BFBC5BB4A651C0FE0FB056EDC240C0	Viejo Pascuero	\N	EiJTdGEuIENsYXVzIDc0ODIsIExhIEZsb3JpZGEsIENoaWxlIjESLwoUChIJK3GcMWLQYpYR7PP2DYtvZOkQujoqFAoSCQdOpc1j0GKWEQxP1_7cBsDb	0	t	e2069a37-d3eb-48a3-9235-586be6935b36	\N
2023-05-05 17:01:28.810871	2023-05-05 17:01:28.810871	Mirador Azul	Mirador Azul	87		HOME	Región Metropolitana	La Florida	Chile	Mirador Azul 87, La Florida, Región Metropolitana, Chile	-33.5131385	-70.6070774	{"northeast": {"lat": -33.51171776970849, "lng": -70.60574626970849}, "southwest": {"lat": -33.51441573029149, "lng": -70.6084442302915}}	0101000020E610000001C92A5BDAA651C0C4E8B985AEC140C0	Daniel Henry	\N	ChIJ8ZJDn2_QYpYRuybNmzZNI0s	0	t	ab8269e9-d454-4c30-b2fa-7e15f6661cc6	\N
2024-10-27 18:30:22.691151	2024-10-27 18:30:22.691151	Atahualpa	Atahualpa	235	105 B	DEPARTMENT	Región Metropolitana	La Florida	Chile	Atahualpa 235, 8261830 La Florida, Región Metropolitana, Chile	-33.5175891	-70.6073928	{"northeast": {"lat": -33.51656011970849, "lng": -70.60600811970849}, "southwest": {"lat": -33.51925808029149, "lng": -70.60870608029151}}	0101000020E6100000DBF40C86DFA651C00FA2105C40C240C0	Ablb Blab	\N	ChIJ17RT_mTQYpYRjUqlfg4gwws	0	t	cd4f2029-fbd0-49ab-8b0c-b856406d94df	\N
2024-11-12 02:16:38.65944	2024-11-12 02:16:38.65944	Atahualpa	Atahualpa	235	105 B	DEPARTMENT	Región Metropolitana	La Florida	Chile	Atahualpa 235, 8261830 La Florida, Región Metropolitana, Chile	-33.5175891	-70.6073928	{"northeast": {"lat": -33.51656011970849, "lng": -70.60600811970849}, "southwest": {"lat": -33.51925808029149, "lng": -70.60870608029151}}	0101000020E6100000DBF40C86DFA651C00FA2105C40C240C0	Lucas Henry	\N	ChIJ17RT_mTQYpYRjUqlfg4gwws	0	t	bdbf6bc9-b991-42f7-9e08-f38125851588	\N
2024-12-22 00:15:41.892165	2024-12-22 00:15:41.892165	Colombia	Colombia	7300	17	DEPARTMENT	Región Metropolitana	La Florida	Chile	Colombia 7300, 8241482 La Florida, Región Metropolitana, Chile	-33.5220542	-70.58956359999999	{"northeast": {"lat": -33.5207978697085, "lng": -70.5885112197085}, "southwest": {"lat": -33.5234958302915, "lng": -70.5912091802915}}	0101000020E61000005E3AF768BBA551C0A6DE09ACD2C240C0	Gina Galleguillos	\N	ChIJw85CgljQYpYRYCsVR3wPI7Q	0	t	099240ec-429c-48e5-9159-053eff6b818d	\N
2025-03-13 01:33:29.068886	2025-03-13 01:33:29.068886	235	235	Atahualpa	\N	STUDIO	Región Metropolitana	La Florida	Chile	Atahualpa 235, 8261830 La Florida, Región Metropolitana, Chile	-33.5175891	-70.6073928	{"northeast": {"lat": -33.51656011970849, "lng": -70.60600811970849}, "southwest": {"lat": -33.51925808029149, "lng": -70.60870608029151}}	0101000020E6100000DBF40C86DFA651C00FA2105C40C240C0	Casa	\N	ChIJ17RT_mTQYpYRjUqlfg4gwws	0	t	635a1caf-ff4a-4a3d-8b84-e83e256d2e93	\N
2025-03-13 02:35:21.342672	2025-03-22 04:23:29.779208	756	756	Avenida Padre Hurtado Sur	\N	STUDIO	Región Metropolitana	Las Condes	Chile	Av. Padre Hurtado Sur 756, 7500000 Las Condes, Región Metropolitana, Chile	-33.4131593	-70.540217	{"northeast": {"lat": -33.4118625697085, "lng": -70.5389953197085}, "southwest": {"lat": -33.4145605302915, "lng": -70.54169328029151}}	0101000020E610000091EF52EA92A251C0E5C46867E2B440C0	Estudio centro	\N	ChIJz7R7hNfPYpYRf_cNSdu22Bs	1	t	4f406896-996f-48ec-9d2d-8320528c5af4	\N
2025-03-13 02:43:00.059069	2025-03-22 04:23:54.19523	222	222	Atahualpa	\N	STUDIO	Valparaíso	Valparaíso	Chile	Atahualpa 222, Valparaíso, Chile	-33.0446157	-71.62690959999999	{"northeast": {"lat": -33.0433256197085, "lng": -71.62555451970849}, "southwest": {"lat": -33.0460235802915, "lng": -71.6282524802915}}	0101000020E6100000196371491FE851C0AF319EF7B58540C0	Estudio Sur	\N	EiFBdGFodWFscGEgMjIyLCBWYWxwYXJhw61zbywgQ2hpbGUiMRIvChQKEgnvuGQ8L-GJlhGgn3-mQZQ1uhDeASoUChIJd2cinS_hiZYRPoF_Nr0u028	2	t	6ff626be-06a4-4e05-b1c8-8d2602b7b6b4	\N
\.


--
-- Data for Name: event_location; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.event_location (created_at, updated_at, address1, short_address1, address2, address3, address_type, state, city, country, formatted_address, lat, lng, viewport, location, id) FROM stdin;
\.


--
-- Data for Name: spatial_ref_sys; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.spatial_ref_sys (srid, auth_name, auth_srid, srtext, proj4text) FROM stdin;
\.


--
-- Name: artist_location PK_86c4d78b72729fe4f03e468ef55; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.artist_location
    ADD CONSTRAINT "PK_86c4d78b72729fe4f03e468ef55" PRIMARY KEY (id);


--
-- Name: event_location PK_ff5c43e186f7faf15a975004d76; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.event_location
    ADD CONSTRAINT "PK_ff5c43e186f7faf15a975004d76" PRIMARY KEY (id);


--
-- Name: artist_location UQ_084f6193398283c4c2d42a0b71c; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.artist_location
    ADD CONSTRAINT "UQ_084f6193398283c4c2d42a0b71c" UNIQUE (artist_id, location_order);


--
-- Name: IDX_1ce699acff5d40d1b7ce70b1fc; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_1ce699acff5d40d1b7ce70b1fc" ON public.artist_location USING gist (location);


--
-- Name: IDX_32b296abf35bf4c43f52239ba5; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_32b296abf35bf4c43f52239ba5" ON public.event_location USING gist (location);


--
-- Name: IDX_43b8bd2d87ace87ddad31443c4; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_43b8bd2d87ace87ddad31443c4" ON public.artist_location USING btree (artist_id);


--
-- PostgreSQL database dump complete
--

