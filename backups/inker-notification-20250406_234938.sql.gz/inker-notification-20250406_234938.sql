--
-- PostgreSQL database dump
--

-- Dumped from database version 17.2 (Debian 17.2-1.pgdg110+1)
-- Dumped by pg_dump version 17.2 (Debian 17.2-1.pgdg110+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: job_type_key; Type: TYPE; Schema: public; Owner: root
--

CREATE TYPE public.job_type_key AS ENUM (
    'EVENT_CREATED',
    'EVENT_CANCELED',
    'EVENT_REMINDER',
    'EVENT_UPDATED',
    'EVENT_STATUS_CHANGED',
    'RSVP_ACCEPTED',
    'RSVP_DECLINED',
    'RSVP_UNSCHEDULABLE',
    'QUOTATION_CREATED',
    'QUOTATION_REPLIED',
    'QUOTATION_ACCEPTED',
    'QUOTATION_REJECTED',
    'QUOTATION_APPEALED',
    'QUOTATION_CANCELED',
    'ACCOUNT_VERIFICATION_CODE'
);


ALTER TYPE public.job_type_key OWNER TO root;

--
-- Name: user_fcm_tokens_device_type_enum; Type: TYPE; Schema: public; Owner: root
--

CREATE TYPE public.user_fcm_tokens_device_type_enum AS ENUM (
    'android',
    'ios',
    'web'
);


ALTER TYPE public.user_fcm_tokens_device_type_enum OWNER TO root;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: notifications; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.notifications (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id integer NOT NULL,
    title character varying NOT NULL,
    body character varying NOT NULL,
    type public.job_type_key NOT NULL,
    data jsonb NOT NULL,
    read boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.notifications OWNER TO root;

--
-- Name: user_fcm_tokens; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.user_fcm_tokens (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id integer NOT NULL,
    token character varying NOT NULL,
    device_type public.user_fcm_tokens_device_type_enum NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    last_used_at timestamp without time zone
);


ALTER TABLE public.user_fcm_tokens OWNER TO root;

--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.notifications (id, user_id, title, body, type, data, read, created_at) FROM stdin;
7a08cfd6-ecbb-4d7c-abe2-e264f98ca1b5	9	New Quotation Request	Paula has sent you a new quotation request.	QUOTATION_CREATED	{"customerId": 3, "quotationId": "252", "customerName": "Paula"}	f	2025-03-06 02:23:27.836807
53ed92d3-9eb4-4244-be3f-0516c27e30d7	9	New Quotation Request	Paula has sent you a new quotation request.	QUOTATION_CREATED	{"customerId": 3, "quotationId": "252", "customerName": "Paula"}	f	2025-03-06 02:23:30.888027
199dc62b-9193-4e15-a24f-cb7f4157e635	9	New Quotation Request	Paula has sent you a new quotation request.	QUOTATION_CREATED	{"customerId": 3, "quotationId": "252", "customerName": "Paula"}	f	2025-03-06 02:23:33.372227
7374170d-2af3-4335-a089-a089f6112ebb	9	New Quotation Request	Paula has sent you a new quotation request.	QUOTATION_CREATED	{"customerId": 3, "quotationId": "253", "customerName": "Paula"}	f	2025-03-06 02:27:34.100637
44caa440-1754-4628-9839-df69c720a3e4	9	New Quotation Request	Paula has sent you a new quotation request.	QUOTATION_CREATED	{"customerId": 3, "quotationId": "253", "customerName": "Paula"}	f	2025-03-06 02:27:35.925121
daded92b-8e9c-4fd8-a8ba-7f05596dc797	9	New Quotation Request	Paula has sent you a new quotation request.	QUOTATION_CREATED	{"customerId": 3, "quotationId": "253", "customerName": "Paula"}	f	2025-03-06 02:27:37.717452
bd57607f-3167-4573-a3dd-b2c1d5458101	9	New Quotation Request	Paula has sent you a new quotation request.	QUOTATION_CREATED	{"customerId": 3, "quotationId": "254", "customerName": "Paula"}	f	2025-03-06 02:28:29.34268
57715c75-d7ac-4294-91a5-1cee99a6d563	4	New Appointment Scheduled	Your appointment "Appointment with Lucas" with jualiart has been scheduled for 3/12/2025	EVENT_CREATED	{"eventId": 15, "artistId": 9, "artistName": "jualiart"}	f	2025-03-12 01:31:58.44507
48677755-937e-4406-a2f5-9bbca0ebded0	29	New Appointment Created	New appointment "Appointment with Lucas" with Lucas has been scheduled for 3/12/2025	EVENT_CREATED	{"eventId": 15, "customerId": 1, "customerName": "Lucas"}	t	2025-03-12 01:31:58.476479
ef084c02-fb6b-46b3-923d-49939c71c853	29	New Quotation Request	Lucas has sent you a new quotation request.	QUOTATION_CREATED	{"customerId": 24, "quotationId": "266", "customerName": "Lucas"}	f	2025-04-06 18:52:55.216441
abd6e856-f4de-4b2e-96eb-35a05cfc7554	1	New Quotation Request	Paula has sent you a new quotation request.	QUOTATION_CREATED	{"customerId": 3, "quotationId": "260", "customerName": "Paula"}	f	2025-03-07 01:29:54.233891
c90a0165-2008-4287-9a4f-294d9870fe7f	29	New Quotation Request	Paula has sent you a new quotation request.	QUOTATION_CREATED	{"customerId": 3, "quotationId": "256", "customerName": "Paula"}	t	2025-03-06 02:37:38.363483
8c4e07f2-e7f5-4990-9a13-d0df189be07b	29	New Quotation Request	Paula has sent you a new quotation request.	QUOTATION_CREATED	{"customerId": 3, "quotationId": "257", "customerName": "Paula"}	t	2025-03-06 02:38:20.966922
38e856f3-1081-4fa7-880b-a50d8e0a495d	29	New Quotation Request	Paula has sent you a new quotation request.	QUOTATION_CREATED	{"customerId": 3, "quotationId": "258", "customerName": "Paula"}	t	2025-03-06 02:41:12.060933
9dd9b9fc-fdb3-4de6-bb7e-001048454c1a	6	Quotation Rejected by Artist	jualiart has rejected your quotation. Reason: No reason provided	QUOTATION_REJECTED	{"reason": "", "artistId": 9, "artistName": "jualiart", "quotationId": "263"}	t	2025-03-07 02:25:19.012821
f831bd37-bceb-48fb-95d9-719df15d6a56	29	New Quotation Request	Luano has sent you a new quotation request.	QUOTATION_CREATED	{"customerId": 20, "quotationId": "265", "customerName": "Luano"}	t	2025-03-12 01:56:09.676647
6fd1e153-fc91-488c-903d-4ffc65ecb7c0	29	New Quotation Request	Lucas has sent you a new quotation request.	QUOTATION_CREATED	{"customerId": 24, "quotationId": "267", "customerName": "Lucas"}	f	2025-04-06 23:43:42.615333
ddf14ec5-0c7f-4f95-8ed4-1429f4be264c	6	Quotation Replied	jualiart has replied to your quotation request.	QUOTATION_REPLIED	{"cost": "3 CLP", "date": "2025-03-07T13:45:00.000Z", "artistId": 9, "artistName": "jualiart", "quotationId": "264", "artistUserId": 29}	t	2025-03-07 21:18:44.454513
01b39558-83b6-49ac-9729-75fe3488e911	6	Quotation Rejected by Artist	jualiart has rejected your quotation. Reason: No reason provided	QUOTATION_REJECTED	{"reason": "", "artistId": 9, "artistName": "jualiart", "quotationId": "257"}	t	2025-03-07 21:17:47.843156
ee0cccaf-98cf-4274-9197-37dd307c8083	6	Quotation Replied	jualiart has replied to your quotation request.	QUOTATION_REPLIED	{"cost": "50 CLP", "date": "2025-03-06T15:00:00.000Z", "artistId": 9, "artistName": "jualiart", "quotationId": "259", "artistUserId": 29}	t	2025-03-07 02:00:10.605708
7b7ca049-eed3-4ddf-8ced-b9d1a5a8fb81	6	Quotation Rejected by Artist	jualiart has rejected your quotation. Reason: No reason provided	QUOTATION_REJECTED	{"reason": "", "artistId": 9, "artistName": "jualiart", "quotationId": "256"}	t	2025-03-07 02:03:24.221792
58dc7702-7479-4ce9-b311-57655aed974a	6	Quotation Rejected by Artist	jualiart has rejected your quotation. Reason: No reason provided	QUOTATION_REJECTED	{"reason": "", "artistId": 9, "artistName": "jualiart", "quotationId": "261"}	t	2025-03-07 02:10:29.562832
98c3e582-486d-4f3f-b31d-5bb44cb61838	6	Quotation Replied	jualiart has replied to your quotation request.	QUOTATION_REPLIED	{"cost": "50 CLP", "date": "2025-03-07T02:11:10.478Z", "artistId": 9, "artistName": "jualiart", "quotationId": "262", "artistUserId": 29}	t	2025-03-07 02:11:13.36527
7ecec4de-d3e6-4ab6-ab97-2cae7fcc52b1	4	New Appointment Scheduled	Your appointment "Appointment with Lucas" with jualiart has been scheduled for 3/11/2025	EVENT_CREATED	{"eventId": 11, "artistId": 9, "artistName": "jualiart"}	f	2025-03-11 03:10:20.548442
43316b01-51cd-4672-b309-e15ae97c230c	4	New Appointment Scheduled	Your appointment "Appointment with Lucas" with jualiart has been scheduled for 3/12/2025	EVENT_CREATED	{"eventId": 12, "artistId": 9, "artistName": "jualiart"}	f	2025-03-11 03:13:32.673303
d6faa9c3-0d9e-4517-9f64-43d25c6ee3b3	4	New Appointment Scheduled	Your appointment "Appointment with Lucas" with jualiart has been scheduled for 3/13/2025	EVENT_CREATED	{"eventId": 13, "artistId": 9, "artistName": "jualiart"}	f	2025-03-11 03:16:48.05236
db4be7cd-4c3b-47d2-903f-caef60d470dd	4	New Appointment Scheduled	Your appointment "Appointment with Lucas" with jualiart has been scheduled for 3/14/2025	EVENT_CREATED	{"eventId": 14, "artistId": 9, "artistName": "jualiart"}	f	2025-03-11 03:27:01.125539
ff6dc92c-3523-45d1-8678-5a9c19c834e3	29	Quotation Accepted	Paula has accepted your quotation.	QUOTATION_ACCEPTED	{"cost": "50 CLP", "date": "2025-03-06T15:00:00.000Z", "customerId": 3, "quotationId": "259", "customerName": "Paula"}	t	2025-03-07 02:01:25.836896
17c5c4e7-e692-450a-aeaf-103f9e313d6d	29	New Quotation Request	Paula has sent you a new quotation request.	QUOTATION_CREATED	{"customerId": 3, "quotationId": "261", "customerName": "Paula"}	t	2025-03-07 02:10:08.314799
2b41d073-7bbb-4de5-8b58-966d05a4ae10	29	New Quotation Request	Paula has sent you a new quotation request.	QUOTATION_CREATED	{"customerId": 3, "quotationId": "262", "customerName": "Paula"}	t	2025-03-07 02:10:55.409723
38f04dae-193c-4ce6-b6f1-af00894444bb	29	New Quotation Request	Paula has sent you a new quotation request.	QUOTATION_CREATED	{"customerId": 3, "quotationId": "264", "customerName": "Paula"}	t	2025-03-07 21:18:05.342474
e22845ee-dbef-41c8-878f-fef0e378b6f5	28	Quotation Replied	jualiart has replied to your quotation request.	QUOTATION_REPLIED	{"cost": "5 CLP", "date": "2025-03-11T15:30:00.000Z", "artistId": 9, "artistName": "jualiart", "quotationId": "265", "artistUserId": 29}	f	2025-03-12 02:04:40.620504
6d3c4eb6-082b-49c8-a564-97bbfc382324	29	Quotation Accepted	Paula has accepted your quotation.	QUOTATION_ACCEPTED	{"cost": "50 CLP", "date": "2025-03-07T02:11:10.478Z", "customerId": 3, "quotationId": "262", "customerName": "Paula"}	t	2025-03-07 02:12:24.755361
28c0ced3-b0b1-4ce8-a100-0c807b102087	29	New Quotation Request	Paula has sent you a new quotation request.	QUOTATION_CREATED	{"customerId": 3, "quotationId": "263", "customerName": "Paula"}	t	2025-03-07 02:25:03.564481
4420565f-544e-404d-9aa0-8da028f81bf2	29	Quotation Accepted	Paula has accepted your quotation.	QUOTATION_ACCEPTED	{"cost": "3 CLP", "date": "2025-03-07T13:45:00.000Z", "customerId": 3, "quotationId": "264", "customerName": "Paula"}	t	2025-03-07 21:19:04.081227
830611fa-57f8-43fc-be04-8bfa34c83f4c	29	New Appointment Created	New appointment "Appointment with Lucas" with Lucas has been scheduled for 3/11/2025	EVENT_CREATED	{"eventId": 11, "customerId": 1, "customerName": "Lucas"}	t	2025-03-11 03:10:20.587939
5d61c9fe-1edd-4458-9807-86bcd0689f99	29	New Appointment Created	New appointment "Appointment with Lucas" with Lucas has been scheduled for 3/12/2025	EVENT_CREATED	{"eventId": 12, "customerId": 1, "customerName": "Lucas"}	t	2025-03-11 03:13:32.70226
36d80bc8-7ada-4b79-b3e6-a354e1be9cba	29	New Appointment Created	New appointment "Appointment with Lucas" with Lucas has been scheduled for 3/13/2025	EVENT_CREATED	{"eventId": 13, "customerId": 1, "customerName": "Lucas"}	t	2025-03-11 03:16:48.083049
509d4e35-6872-4242-baf2-e5249b6c8c66	29	New Appointment Created	New appointment "Appointment with Lucas" with Lucas has been scheduled for 3/14/2025	EVENT_CREATED	{"eventId": 14, "customerId": 1, "customerName": "Lucas"}	t	2025-03-11 03:27:01.154416
\.


--
-- Data for Name: user_fcm_tokens; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.user_fcm_tokens (id, user_id, token, device_type, is_active, created_at, last_used_at) FROM stdin;
caa1b0df-2684-4377-97be-859b7c2dc77e	6	fdG7TILENk4ThXIy0ayR0F:APA91bHrvspjSlrtSJ7WXXaDbo4lHI4SEE_SppQsEFcyGyUIfBUqyAPYD1bBi7qRQwnucfsXsoNIUh8G2w_PgdW7Fe6dH9v7kYjYAEwlCW6S9vDzjK2-OXE	ios	t	2025-03-06 00:52:47.253742	2025-03-05 21:52:47.007
e5e4ad38-f5e9-43a2-b2ae-071dc89553fb	29	c3jLkNXvo0HLisk-eA4I4M:APA91bEE1zg6WrZ9Ij6N4lBwo78L3HtbLCsMLvZsz8oyVns5tq1rN_p-7mShlvdU_rMgheerja8bpnr_8TURFiCRyVDSDjqlCLH30FLlHwoW_W1FQIc8Bbc	ios	t	2025-03-05 03:23:34.063065	2025-03-21 00:24:22.928
75044c2c-7e7c-418f-9b17-938bb49300d9	28	fdG7TILENk4ThXIy0ayR0F:APA91bHrvspjSlrtSJ7WXXaDbo4lHI4SEE_SppQsEFcyGyUIfBUqyAPYD1bBi7qRQwnucfsXsoNIUh8G2w_PgdW7Fe6dH9v7kYjYAEwlCW6S9vDzjK2-OXE	ios	t	2025-03-12 01:55:46.106639	2025-03-22 14:49:10.207
7a9fd5cf-c332-4ca6-81fe-fc8d5019da86	29	fdG7TILENk4ThXIy0ayR0F:APA91bHrvspjSlrtSJ7WXXaDbo4lHI4SEE_SppQsEFcyGyUIfBUqyAPYD1bBi7qRQwnucfsXsoNIUh8G2w_PgdW7Fe6dH9v7kYjYAEwlCW6S9vDzjK2-OXE	ios	t	2025-03-25 03:11:42.489158	2025-03-25 00:11:42.261
7efb2e8a-1589-47ed-98b0-7f0bd3838686	35	fdG7TILENk4ThXIy0ayR0F:APA91bHrvspjSlrtSJ7WXXaDbo4lHI4SEE_SppQsEFcyGyUIfBUqyAPYD1bBi7qRQwnucfsXsoNIUh8G2w_PgdW7Fe6dH9v7kYjYAEwlCW6S9vDzjK2-OXE	ios	t	2025-03-25 03:14:27.850906	2025-04-06 14:27:48.959
\.


--
-- Name: notifications PK_6a72c3c0f683f6462415e653c3a; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT "PK_6a72c3c0f683f6462415e653c3a" PRIMARY KEY (id);


--
-- Name: user_fcm_tokens PK_f8088ed7e1116e01a4033b6ca76; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.user_fcm_tokens
    ADD CONSTRAINT "PK_f8088ed7e1116e01a4033b6ca76" PRIMARY KEY (id);


--
-- Name: IDX_e66818fd4f5952a132c6bd0e68; Type: INDEX; Schema: public; Owner: root
--

CREATE UNIQUE INDEX "IDX_e66818fd4f5952a132c6bd0e68" ON public.user_fcm_tokens USING btree (user_id, token);


--
-- PostgreSQL database dump complete
--

