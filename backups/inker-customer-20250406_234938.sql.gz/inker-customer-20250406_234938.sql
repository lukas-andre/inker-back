--
-- PostgreSQL database dump
--

-- Dumped from database version 17.2 (Debian 17.2-1.pgdg110+1)
-- Dumped by pg_dump version 17.2 (Debian 17.2-1.pgdg110+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


--
-- Name: unaccent; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS unaccent WITH SCHEMA public;


--
-- Name: EXTENSION unaccent; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION unaccent IS 'text search dictionary that removes accents';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: update_tsvector(); Type: FUNCTION; Schema: public; Owner: root
--

CREATE FUNCTION public.update_tsvector() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.tsv := 
    setweight(
      to_tsvector('english', 
        coalesce(NEW.first_name, '') || ' ' || 
        coalesce(NEW.last_name, '') || ' ' || 
        coalesce(NEW.contact_email, '')
      ), 
      'A'
    ) ||
    setweight(
      to_tsvector('spanish', 
        coalesce(NEW.first_name, '') || ' ' || 
        coalesce(NEW.last_name, '') || ' ' || 
        coalesce(NEW.contact_email, '')
      ), 
      'B'
    );
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_tsvector() OWNER TO root;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: customer; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.customer (
    id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    user_id integer NOT NULL,
    first_name character varying,
    last_name character varying,
    contact_email character varying,
    contact_phone_number character varying,
    short_description character varying,
    profile_thumbnail character varying,
    follows jsonb,
    rating double precision DEFAULT '0'::double precision NOT NULL,
    tsv tsvector NOT NULL,
    deleted_at timestamp without time zone
);


ALTER TABLE public.customer OWNER TO root;

--
-- Name: customer_feed; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.customer_feed (
    id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    "userId" character varying NOT NULL,
    feed jsonb NOT NULL,
    "maxItems" integer DEFAULT 50 NOT NULL
);


ALTER TABLE public.customer_feed OWNER TO root;

--
-- Name: customer_feed_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.customer_feed_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.customer_feed_id_seq OWNER TO root;

--
-- Name: customer_feed_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.customer_feed_id_seq OWNED BY public.customer_feed.id;


--
-- Name: customer_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.customer_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.customer_id_seq OWNER TO root;

--
-- Name: customer_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.customer_id_seq OWNED BY public.customer.id;


--
-- Name: customer id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.customer ALTER COLUMN id SET DEFAULT nextval('public.customer_id_seq'::regclass);


--
-- Name: customer_feed id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.customer_feed ALTER COLUMN id SET DEFAULT nextval('public.customer_feed_id_seq'::regclass);


--
-- Data for Name: customer; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.customer (id, created_at, updated_at, user_id, first_name, last_name, contact_email, contact_phone_number, short_description, profile_thumbnail, follows, rating, tsv, deleted_at) FROM stdin;
1	2023-01-10 00:58:49.011556	2023-01-10 00:58:49.011556	4	Lucas	Henry	lucas.henrydz@gmail.com	+56964484712	\N	\N	\N	0	'henri':2A 'henry':5B 'luc':4B 'luca':1A 'lucas.henrydz@gmail.com':3A,6B	\N
2	2023-02-16 01:46:01.980616	2023-02-16 01:46:01.980616	5	Andre	Henry	andre.henrydz@gmail.com	+56964484713	\N	\N	\N	0	'andr':1A 'andre':4B 'andre.henrydz@gmail.com':3A,6B 'henri':2A 'henry':5B	\N
3	2023-02-21 00:29:44.9883	2023-02-21 00:29:44.9883	6	Paula	Carrasco	paula@gmail.com	+56964484714	\N	\N	\N	0	'carrasc':5B 'carrasco':2A 'paul':4B 'paula':1A 'paula@gmail.com':3A,6B	\N
4	2023-03-21 02:30:42.294096	2023-03-21 02:30:42.294096	7	Customer	Test 1	test1@test.com	+56964484712	\N	\N	\N	0	'1':3A,7B 'custom':1A,5B 'test':2A,6B 'test1@test.com':4A,8B	\N
5	2023-03-21 02:36:10.934323	2023-03-21 02:36:10.934323	8	Customer	Test 2	test2@test.com	+56964484712	\N	\N	\N	0	'2':3A,7B 'custom':1A,5B 'test':2A,6B 'test2@test.com':4A,8B	\N
6	2023-03-21 02:36:50.341096	2023-03-21 02:36:50.341096	9	Customer	Test 3	test3@test.com	+56964484712	\N	\N	\N	0	'3':3A,7B 'custom':1A,5B 'test':2A,6B 'test3@test.com':4A,8B	\N
7	2023-03-21 02:38:16.248201	2023-03-21 02:38:16.248201	10	Customer	Test 4	test4@test.com	+56964484712	\N	\N	\N	0	'4':3A,7B 'custom':1A,5B 'test':2A,6B 'test4@test.com':4A,8B	\N
20	2024-10-27 03:52:40.46728	2024-10-27 03:52:40.46728	28	Luano	Kefai	launo@kefai.cl	+56964484712	\N	\N	\N	0	'kefai':2A,5B 'launo@kefai.cl':3A,6B 'luan':4B 'luano':1A	\N
21	2024-12-21 23:20:38.317447	2024-12-21 23:20:38.317447	32	Juanoo	Likeman	lucas.henrydz@gmail.com	+56964484712	\N	\N	\N	0	'juano':4B 'juanoo':1A 'likem':5B 'likeman':2A 'lucas.henrydz@gmail.com':3A,6B	\N
22	2024-12-21 23:30:33.059833	2024-12-21 23:30:33.059833	33	Lucas	Henry	lucas.henrydz@gmail.com	+56964484712	\N	\N	\N	0	'henri':2A 'henry':5B 'luc':4B 'luca':1A 'lucas.henrydz@gmail.com':3A,6B	\N
23	2024-12-21 23:34:51.511741	2024-12-21 23:34:51.511741	34	Lucas	Henry	lucas.henrydz@gmail.com	+56964484712	\N	\N	\N	0	'henri':2A 'henry':5B 'luc':4B 'luca':1A 'lucas.henrydz@gmail.com':3A,6B	\N
24	2024-12-21 23:44:32.088104	2024-12-21 23:44:32.088104	35	Lucas	Henry	lucas.henrydz@gmail.com	+56964484712	\N	\N	\N	0	'henri':2A 'henry':5B 'luc':4B 'luca':1A 'lucas.henrydz@gmail.com':3A,6B	\N
25	2024-12-22 00:03:53.292525	2024-12-22 00:03:53.292525	36	Paula	Carrasco	paula.masiel.carrasco@gmail.com	+56979980676	\N	\N	\N	0	'carrasc':5B 'carrasco':2A 'paul':4B 'paula':1A 'paula.masiel.carrasco@gmail.com':3A,6B	\N
26	2024-12-22 00:11:25.341826	2024-12-22 00:11:25.341826	37	Catalina	Giuria	cataa.giuria@gmail.com	+56992557103	\N	\N	\N	0	'cataa.giuria@gmail.com':3A,6B 'catalin':4B 'catalina':1A 'giuri':5B 'giuria':2A	\N
27	2024-12-22 00:16:00.354657	2024-12-22 00:16:00.354657	39	Leonardo	Urbina	leo.urbinaa@gmail.com	+56934009744	\N	\N	\N	0	'leo.urbinaa@gmail.com':3A,6B 'leonard':4B 'leonardo':1A 'urbin':5B 'urbina':2A	\N
28	2024-12-22 00:17:52.608006	2024-12-22 00:17:52.608006	40	Leonardo	Urbina	leo.urbinaa@gmail.com	+56934009744	\N	\N	\N	0	'leo.urbinaa@gmail.com':3A,6B 'leonard':4B 'leonardo':1A 'urbin':5B 'urbina':2A	\N
\.


--
-- Data for Name: customer_feed; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.customer_feed (id, created_at, updated_at, "userId", feed, "maxItems") FROM stdin;
\.


--
-- Name: customer_feed_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.customer_feed_id_seq', 1, false);


--
-- Name: customer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.customer_id_seq', 28, true);


--
-- Name: customer_feed PK_0ea45282db360536f96375c8ae7; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.customer_feed
    ADD CONSTRAINT "PK_0ea45282db360536f96375c8ae7" PRIMARY KEY (id);


--
-- Name: customer PK_a7a13f4cacb744524e44dfdad32; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.customer
    ADD CONSTRAINT "PK_a7a13f4cacb744524e44dfdad32" PRIMARY KEY (id);


--
-- Name: IDX_54a4e7dee8f1ae70885954f2f5; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_54a4e7dee8f1ae70885954f2f5" ON public.customer_feed USING btree ("userId");


--
-- Name: customer tsvectorupdate; Type: TRIGGER; Schema: public; Owner: root
--

CREATE TRIGGER tsvectorupdate BEFORE INSERT OR UPDATE ON public.customer FOR EACH ROW EXECUTE FUNCTION public.update_tsvector();


--
-- PostgreSQL database dump complete
--

