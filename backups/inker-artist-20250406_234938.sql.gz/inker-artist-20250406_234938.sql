--
-- PostgreSQL database dump
--

-- Dumped from database version 17.2 (Debian 17.2-1.pgdg110+1)
-- Dumped by pg_dump version 17.2 (Debian 17.2-1.pgdg110+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: service_name; Type: TYPE; Schema: public; Owner: root
--

CREATE TYPE public.service_name AS ENUM (
    'Barber',
    'Tattoo Artist'
);


ALTER TYPE public.service_name OWNER TO root;

--
-- Name: stencils_status_enum; Type: TYPE; Schema: public; Owner: root
--

CREATE TYPE public.stencils_status_enum AS ENUM (
    'AVAILABLE',
    'SOLD',
    'USED'
);


ALTER TYPE public.stencils_status_enum OWNER TO root;

--
-- Name: works_source_enum; Type: TYPE; Schema: public; Owner: root
--

CREATE TYPE public.works_source_enum AS ENUM (
    'APP',
    'EXTERNAL'
);


ALTER TYPE public.works_source_enum OWNER TO root;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: artist; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.artist (
    id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    user_id integer NOT NULL,
    username character varying NOT NULL,
    first_name character varying NOT NULL,
    last_name character varying NOT NULL,
    profile_thumbnail character varying,
    "profileThumbnailVersion" integer DEFAULT 0 NOT NULL,
    studio_photo character varying,
    "studioPhotoVersion" integer DEFAULT 0 NOT NULL,
    deleted_at timestamp without time zone,
    contact_id integer,
    short_description text,
    rating numeric(3,1) DEFAULT '0'::numeric NOT NULL,
    works_count integer DEFAULT 0 NOT NULL,
    stencils_count integer DEFAULT 0 NOT NULL,
    visible_works_count integer DEFAULT 0 NOT NULL,
    visible_stencils_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.artist OWNER TO root;

--
-- Name: COLUMN artist.rating; Type: COMMENT; Schema: public; Owner: root
--

COMMENT ON COLUMN public.artist.rating IS 'Artist rating from 0.0 to 5.0';


--
-- Name: COLUMN artist.works_count; Type: COMMENT; Schema: public; Owner: root
--

COMMENT ON COLUMN public.artist.works_count IS 'Count of all works (including hidden)';


--
-- Name: COLUMN artist.stencils_count; Type: COMMENT; Schema: public; Owner: root
--

COMMENT ON COLUMN public.artist.stencils_count IS 'Count of all stencils (including hidden)';


--
-- Name: COLUMN artist.visible_works_count; Type: COMMENT; Schema: public; Owner: root
--

COMMENT ON COLUMN public.artist.visible_works_count IS 'Count of visible works only (is_hidden=false)';


--
-- Name: COLUMN artist.visible_stencils_count; Type: COMMENT; Schema: public; Owner: root
--

COMMENT ON COLUMN public.artist.visible_stencils_count IS 'Count of visible stencils only (is_hidden=false)';


--
-- Name: artist_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.artist_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.artist_id_seq OWNER TO root;

--
-- Name: artist_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.artist_id_seq OWNED BY public.artist.id;


--
-- Name: artist_services; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.artist_services (
    artist_id integer NOT NULL,
    service_id integer NOT NULL
);


ALTER TABLE public.artist_services OWNER TO root;

--
-- Name: artist_services_service; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.artist_services_service (
    "artistId" integer NOT NULL,
    "serviceId" integer NOT NULL
);


ALTER TABLE public.artist_services_service OWNER TO root;

--
-- Name: artist_styles; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.artist_styles (
    artist_id integer NOT NULL,
    style_name character varying NOT NULL,
    proficiency_level integer DEFAULT 3 NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.artist_styles OWNER TO root;

--
-- Name: artist_tags; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.artist_tags (
    artist_id integer NOT NULL,
    tag_id integer NOT NULL
);


ALTER TABLE public.artist_tags OWNER TO root;

--
-- Name: contact; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.contact (
    id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    email character varying NOT NULL,
    phone character varying NOT NULL,
    phone_dial_code character varying NOT NULL,
    phone_country_iso_code character varying NOT NULL
);


ALTER TABLE public.contact OWNER TO root;

--
-- Name: contact_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.contact_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.contact_id_seq OWNER TO root;

--
-- Name: contact_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.contact_id_seq OWNED BY public.contact.id;


--
-- Name: interactions; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.interactions (
    id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    user_id integer NOT NULL,
    interaction_type character varying NOT NULL,
    entity_type character varying NOT NULL,
    entity_id integer NOT NULL
);


ALTER TABLE public.interactions OWNER TO root;

--
-- Name: interactions_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.interactions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.interactions_id_seq OWNER TO root;

--
-- Name: interactions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.interactions_id_seq OWNED BY public.interactions.id;


--
-- Name: service; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.service (
    id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    name public.service_name NOT NULL,
    description character varying
);


ALTER TABLE public.service OWNER TO root;

--
-- Name: service_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.service_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.service_id_seq OWNER TO root;

--
-- Name: service_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.service_id_seq OWNED BY public.service.id;


--
-- Name: stencil_tags; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.stencil_tags (
    stencil_id integer NOT NULL,
    tag_id integer NOT NULL
);


ALTER TABLE public.stencil_tags OWNER TO root;

--
-- Name: stencils; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.stencils (
    id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    artist_id integer NOT NULL,
    title character varying NOT NULL,
    description text,
    image_url character varying NOT NULL,
    image_version integer DEFAULT 0 NOT NULL,
    thumbnail_url character varying,
    thumbnail_version integer DEFAULT 0 NOT NULL,
    price numeric(10,2),
    deleted_at timestamp without time zone,
    tsv tsvector NOT NULL,
    is_featured boolean DEFAULT false NOT NULL,
    order_position integer DEFAULT 0 NOT NULL,
    status public.stencils_status_enum DEFAULT 'AVAILABLE'::public.stencils_status_enum NOT NULL,
    is_hidden boolean DEFAULT false NOT NULL,
    image_id character varying(40) NOT NULL,
    dimensions jsonb,
    recommended_placements text DEFAULT '[]'::text,
    estimated_time integer,
    is_customizable boolean DEFAULT false,
    is_downloadable boolean DEFAULT false,
    license text,
    license_url text,
    is_available boolean DEFAULT false
);


ALTER TABLE public.stencils OWNER TO root;

--
-- Name: stencils_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.stencils_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.stencils_id_seq OWNER TO root;

--
-- Name: stencils_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.stencils_id_seq OWNED BY public.stencils.id;


--
-- Name: tag; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.tag (
    id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    name character varying NOT NULL,
    created_by text
);


ALTER TABLE public.tag OWNER TO root;

--
-- Name: tag_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.tag_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tag_id_seq OWNER TO root;

--
-- Name: tag_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.tag_id_seq OWNED BY public.tag.id;


--
-- Name: work_tags; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.work_tags (
    work_id integer NOT NULL,
    tag_id integer NOT NULL
);


ALTER TABLE public.work_tags OWNER TO root;

--
-- Name: works; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.works (
    id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    artist_id integer NOT NULL,
    title character varying NOT NULL,
    description text,
    image_url character varying NOT NULL,
    image_version integer DEFAULT 0 NOT NULL,
    thumbnail_url character varying,
    thumbnail_version integer DEFAULT 0 NOT NULL,
    is_featured boolean DEFAULT false NOT NULL,
    order_position integer DEFAULT 0 NOT NULL,
    deleted_at timestamp without time zone,
    tsv tsvector NOT NULL,
    source public.works_source_enum DEFAULT 'EXTERNAL'::public.works_source_enum NOT NULL,
    is_hidden boolean DEFAULT false NOT NULL,
    image_id character varying
);


ALTER TABLE public.works OWNER TO root;

--
-- Name: works_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.works_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.works_id_seq OWNER TO root;

--
-- Name: works_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.works_id_seq OWNED BY public.works.id;


--
-- Name: artist id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.artist ALTER COLUMN id SET DEFAULT nextval('public.artist_id_seq'::regclass);


--
-- Name: contact id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.contact ALTER COLUMN id SET DEFAULT nextval('public.contact_id_seq'::regclass);


--
-- Name: interactions id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.interactions ALTER COLUMN id SET DEFAULT nextval('public.interactions_id_seq'::regclass);


--
-- Name: service id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.service ALTER COLUMN id SET DEFAULT nextval('public.service_id_seq'::regclass);


--
-- Name: stencils id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.stencils ALTER COLUMN id SET DEFAULT nextval('public.stencils_id_seq'::regclass);


--
-- Name: tag id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.tag ALTER COLUMN id SET DEFAULT nextval('public.tag_id_seq'::regclass);


--
-- Name: works id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.works ALTER COLUMN id SET DEFAULT nextval('public.works_id_seq'::regclass);


--
-- Data for Name: artist; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.artist (id, created_at, updated_at, user_id, username, first_name, last_name, profile_thumbnail, "profileThumbnailVersion", studio_photo, "studioPhotoVersion", deleted_at, contact_id, short_description, rating, works_count, stencils_count, visible_works_count, visible_stencils_count) FROM stdin;
2	2023-01-10 00:08:58.472946	2023-01-10 00:08:58.472946	2	locorene	Loco	Ree	\N	0	\N	0	\N	2	Hola	1.0	0	0	0	0
3	2023-01-10 00:12:53.631805	2023-01-10 00:12:53.631805	3	viejopascuero	Viejo	Pascuero	\N	0	\N	0	\N	3	Hola	2.0	0	0	0	0
8	2023-05-05 17:01:28.776694	2023-05-05 17:01:28.776694	15	elnata	Daniel	Henry	\N	0	\N	0	\N	8	Hola	3.0	0	0	0	0
10	2024-10-27 18:30:22.608751	2024-10-27 18:30:22.608751	30	bla	Ablb	Blab	\N	0	\N	0	\N	10	Hola	5.0	0	0	0	0
11	2024-11-12 02:16:38.572673	2024-11-12 02:16:38.572673	31	ejemplo2	Lucas	Henry	\N	0	\N	0	\N	11	Hola	4.0	0	0	0	0
1	2023-01-10 00:03:20.515117	2024-12-20 03:34:20.472719	1	juanart	Juanart	Art	https://d1riey1i0e5tx2.cloudfront.net/artist/1/profile_picture_13.bin	13	https://d1riey1i0e5tx2.cloudfront.net/artist/1/studio_photo_5.jpeg	5	\N	1	Hola	3.0	0	0	0	0
12	2024-12-22 00:15:41.812323	2024-12-22 00:15:41.812323	38	gina-geinse	Gina	Galleguillos	\N	0	\N	0	\N	12	\N	0.0	0	0	0	0
9	2024-10-27 04:29:07.526119	2025-03-22 03:38:12.003193	29	jualiart	Juliano	Grande	https://d1riey1i0e5tx2.cloudfront.net/artist/9/profile_picture_2.bin	2	https://d1riey1i0e5tx2.cloudfront.net/artist/9/studio_photo_1.bin	1	\N	9	Hola	4.0	2	19	2	9
\.


--
-- Data for Name: artist_services; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.artist_services (artist_id, service_id) FROM stdin;
\.


--
-- Data for Name: artist_services_service; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.artist_services_service ("artistId", "serviceId") FROM stdin;
\.


--
-- Data for Name: artist_styles; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.artist_styles (artist_id, style_name, proficiency_level, created_at) FROM stdin;
\.


--
-- Data for Name: artist_tags; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.artist_tags (artist_id, tag_id) FROM stdin;
\.


--
-- Data for Name: contact; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.contact (id, created_at, updated_at, email, phone, phone_dial_code, phone_country_iso_code) FROM stdin;
1	2023-01-10 00:03:20.515117	2023-01-10 00:03:20.515117	juan@art.cl	+56964484712	+56	CL
2	2023-01-10 00:08:58.472946	2023-01-10 00:08:58.472946	loco@rene.cl	+56964484712	+56	CL
3	2023-01-10 00:12:53.631805	2023-01-10 00:12:53.631805	viejo@pascuero.cl	+56964484712	+56	CL
8	2023-05-05 17:01:28.776694	2023-05-05 17:01:28.776694	lucas.henryd@icloud.com	+56964484712	+56	CL
9	2024-10-27 04:29:07.526119	2024-10-27 04:29:07.526119	admin@gmail.com	+56964484712	+56	CL
10	2024-10-27 18:30:22.608751	2024-10-27 18:30:22.608751	blaadasq@gmail.com	+56964484712	+56	CL
11	2024-11-12 02:16:38.572673	2024-11-12 02:16:38.572673	lucas@gmail.com	+56964484712	+56	CL
12	2024-12-22 00:15:41.812323	2024-12-22 00:15:41.812323	ginageinse@gmail.com	+56989030326	+56	CL
\.


--
-- Data for Name: interactions; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.interactions (id, created_at, updated_at, user_id, interaction_type, entity_type, entity_id) FROM stdin;
1	2025-03-19 02:46:01.643805	2025-03-19 02:46:01.643805	29	view	stencil	19
2	2025-03-19 02:46:16.901231	2025-03-19 02:46:16.901231	29	view	stencil	19
3	2025-03-19 02:46:25.272836	2025-03-19 02:46:25.272836	29	view	stencil	19
4	2025-03-19 02:48:42.648619	2025-03-19 02:48:42.648619	29	view	stencil	17
5	2025-03-19 02:48:48.316538	2025-03-19 02:48:48.316538	29	view	stencil	33
6	2025-03-19 02:48:55.206863	2025-03-19 02:48:55.206863	29	view	stencil	16
7	2025-03-19 02:49:21.21333	2025-03-19 02:49:21.21333	29	view	stencil	16
8	2025-03-19 02:49:27.705348	2025-03-19 02:49:27.705348	29	view	stencil	17
9	2025-03-21 03:46:13.673755	2025-03-21 03:46:13.673755	29	view	work	1
10	2025-03-21 03:46:49.000699	2025-03-21 03:46:49.000699	29	view	work	1
11	2025-03-21 03:47:21.334638	2025-03-21 03:47:21.334638	29	view	work	1
12	2025-03-21 03:47:26.064764	2025-03-21 03:47:26.064764	29	view	work	1
13	2025-03-21 03:47:40.397846	2025-03-21 03:47:40.397846	29	view	work	1
14	2025-03-21 03:47:45.317672	2025-03-21 03:47:45.317672	29	view	work	1
15	2025-03-21 03:47:49.619192	2025-03-21 03:47:49.619192	29	view	work	1
16	2025-03-21 03:47:51.462123	2025-03-21 03:47:51.462123	29	view	work	1
17	2025-03-21 03:47:53.795755	2025-03-21 03:47:53.795755	29	view	work	1
18	2025-03-21 03:47:58.392281	2025-03-21 03:47:58.392281	29	view	work	1
19	2025-03-21 03:48:02.075298	2025-03-21 03:48:02.075298	29	view	work	1
20	2025-03-21 03:48:04.361732	2025-03-21 03:48:04.361732	29	view	work	1
21	2025-03-21 03:54:17.250126	2025-03-21 03:54:17.250126	29	view	work	1
22	2025-03-21 03:54:29.942769	2025-03-21 03:54:29.942769	29	view	work	1
23	2025-03-21 03:54:33.083056	2025-03-21 03:54:33.083056	29	view	work	1
24	2025-03-21 03:55:34.274477	2025-03-21 03:55:34.274477	29	view	work	1
25	2025-03-21 03:58:54.728781	2025-03-21 03:58:54.728781	29	view	work	1
26	2025-03-21 04:00:01.364206	2025-03-21 04:00:01.364206	29	view	work	1
27	2025-03-21 04:00:05.466004	2025-03-21 04:00:05.466004	29	view	work	1
28	2025-03-21 04:00:07.797046	2025-03-21 04:00:07.797046	29	view	stencil	15
29	2025-03-21 04:00:11.773051	2025-03-21 04:00:11.773051	29	view	stencil	16
30	2025-03-21 04:04:49.103822	2025-03-21 04:04:49.103822	29	view	work	1
31	2025-03-21 04:04:55.463231	2025-03-21 04:04:55.463231	29	view	work	1
32	2025-03-21 04:06:41.127672	2025-03-21 04:06:41.127672	29	view	work	1
33	2025-03-21 04:07:14.356021	2025-03-21 04:07:14.356021	29	view	work	1
34	2025-03-21 04:07:24.065235	2025-03-21 04:07:24.065235	29	view	work	1
35	2025-03-21 04:10:18.190492	2025-03-21 04:10:18.190492	29	view	work	1
36	2025-03-21 04:10:35.479435	2025-03-21 04:10:35.479435	29	view	work	1
37	2025-03-21 04:10:46.689672	2025-03-21 04:10:46.689672	29	view	work	1
38	2025-03-22 01:22:54.323206	2025-03-22 01:22:54.323206	29	view	work	1
39	2025-03-22 01:50:56.294887	2025-03-22 01:50:56.294887	29	view	work	1
40	2025-03-22 01:51:10.972587	2025-03-22 01:51:10.972587	29	view	work	1
41	2025-03-22 01:51:21.153983	2025-03-22 01:51:21.153983	29	view	work	1
42	2025-03-22 01:51:29.896494	2025-03-22 01:51:29.896494	29	view	work	1
43	2025-03-22 01:51:32.258553	2025-03-22 01:51:32.258553	29	view	work	1
44	2025-03-22 02:20:08.595369	2025-03-22 02:20:08.595369	29	view	stencil	16
45	2025-03-22 03:25:49.79889	2025-03-22 03:25:49.79889	29	view	stencil	33
46	2025-03-22 04:40:13.097583	2025-03-22 04:40:13.097583	29	view	work	1
47	2025-03-22 04:40:29.97575	2025-03-22 04:40:29.97575	29	view	stencil	15
48	2025-03-22 04:40:36.53537	2025-03-22 04:40:36.53537	29	view	stencil	33
49	2025-03-22 04:54:53.624262	2025-03-22 04:54:53.624262	29	view	work	1
50	2025-03-22 04:55:05.760931	2025-03-22 04:55:05.760931	29	view	stencil	28
51	2025-03-22 16:54:03.619819	2025-03-22 16:54:03.619819	29	view	work	1
52	2025-03-22 16:55:11.865867	2025-03-22 16:55:11.865867	29	view	work	1
53	2025-03-22 16:55:25.907958	2025-03-22 16:55:25.907958	29	view	work	4
54	2025-03-22 16:55:32.676229	2025-03-22 16:55:32.676229	29	view	stencil	16
55	2025-03-22 16:55:34.361777	2025-03-22 16:55:34.361777	29	view	stencil	15
56	2025-03-22 17:14:41.582007	2025-03-22 17:14:41.582007	29	view	work	4
57	2025-03-22 17:17:40.34421	2025-03-22 17:17:40.34421	29	view	work	4
58	2025-03-22 17:29:59.068459	2025-03-22 17:29:59.068459	29	view	work	1
59	2025-03-22 17:30:01.003798	2025-03-22 17:30:01.003798	29	view	work	1
60	2025-03-22 17:30:03.710289	2025-03-22 17:30:03.710289	29	view	work	4
61	2025-03-22 17:30:06.71717	2025-03-22 17:30:06.71717	29	view	work	1
62	2025-03-22 17:30:10.238353	2025-03-22 17:30:10.238353	29	view	stencil	15
63	2025-03-22 17:30:12.084249	2025-03-22 17:30:12.084249	29	view	stencil	16
64	2025-03-22 17:30:16.952591	2025-03-22 17:30:16.952591	29	view	stencil	15
65	2025-03-22 17:33:18.989137	2025-03-22 17:33:18.989137	29	view	work	1
66	2025-03-22 17:33:21.172295	2025-03-22 17:33:21.172295	29	view	work	4
67	2025-03-22 17:33:25.957029	2025-03-22 17:33:25.957029	29	view	stencil	15
68	2025-03-22 17:33:28.400726	2025-03-22 17:33:28.400726	29	view	stencil	16
69	2025-03-22 17:33:34.264272	2025-03-22 17:33:34.264272	29	view	stencil	33
70	2025-03-22 17:35:40.346891	2025-03-22 17:35:40.346891	29	view	stencil	15
71	2025-03-22 17:35:51.984717	2025-03-22 17:35:51.984717	29	view	stencil	15
72	2025-03-22 17:35:57.028981	2025-03-22 17:35:57.028981	29	view	stencil	16
73	2025-03-22 17:36:07.56328	2025-03-22 17:36:07.56328	29	view	stencil	25
74	2025-03-22 17:39:34.426137	2025-03-22 17:39:34.426137	29	view	work	1
75	2025-03-22 17:39:36.641371	2025-03-22 17:39:36.641371	29	view	work	1
76	2025-03-22 17:39:38.006848	2025-03-22 17:39:38.006848	29	view	work	4
77	2025-03-22 17:39:40.298942	2025-03-22 17:39:40.298942	29	view	work	4
78	2025-03-22 17:39:41.93102	2025-03-22 17:39:41.93102	29	view	work	1
79	2025-03-22 17:39:43.656627	2025-03-22 17:39:43.656627	29	view	stencil	13
80	2025-03-22 17:39:46.000793	2025-03-22 17:39:46.000793	29	view	stencil	12
81	2025-03-22 17:39:48.226158	2025-03-22 17:39:48.226158	29	view	stencil	12
82	2025-03-22 17:39:54.73525	2025-03-22 17:39:54.73525	29	view	stencil	13
83	2025-03-22 17:40:01.860733	2025-03-22 17:40:01.860733	29	view	stencil	33
84	2025-03-22 17:41:56.583465	2025-03-22 17:41:56.583465	29	view	stencil	12
85	2025-03-22 17:41:59.345878	2025-03-22 17:41:59.345878	29	view	stencil	13
86	2025-03-22 17:42:38.773078	2025-03-22 17:42:38.773078	29	view	work	4
87	2025-03-22 17:42:42.497804	2025-03-22 17:42:42.497804	29	view	stencil	15
88	2025-03-22 17:44:01.104396	2025-03-22 17:44:01.104396	29	view	work	1
89	2025-03-22 17:44:10.77834	2025-03-22 17:44:10.77834	29	view	work	4
90	2025-03-22 17:44:12.955914	2025-03-22 17:44:12.955914	29	view	work	1
91	2025-03-22 17:44:15.03178	2025-03-22 17:44:15.03178	29	view	work	1
92	2025-03-22 17:44:16.58883	2025-03-22 17:44:16.58883	29	view	work	4
93	2025-03-22 17:44:20.045209	2025-03-22 17:44:20.045209	29	view	work	4
94	2025-03-22 17:44:22.24887	2025-03-22 17:44:22.24887	29	view	work	1
95	2025-03-22 17:46:26.06604	2025-03-22 17:46:26.06604	29	view	stencil	14
96	2025-03-22 17:46:29.015281	2025-03-22 17:46:29.015281	29	view	stencil	15
97	2025-03-22 17:46:34.589139	2025-03-22 17:46:34.589139	29	view	stencil	16
98	2025-03-22 17:46:37.15467	2025-03-22 17:46:37.15467	29	view	stencil	33
99	2025-03-22 17:58:46.100033	2025-03-22 17:58:46.100033	29	view	stencil	15
100	2025-03-22 17:58:47.429052	2025-03-22 17:58:47.429052	29	view	work	1
101	2025-03-23 17:03:53.482194	2025-03-23 17:03:53.482194	28	view	stencil	20
102	2025-03-23 17:03:58.527012	2025-03-23 17:03:58.527012	28	view	stencil	28
103	2025-03-23 17:04:01.584108	2025-03-23 17:04:01.584108	28	view	stencil	28
104	2025-03-23 19:49:21.215308	2025-03-23 19:49:21.215308	28	view	stencil	33
105	2025-03-23 19:52:14.076368	2025-03-23 19:52:14.076368	28	view	stencil	13
106	2025-03-23 19:55:55.91724	2025-03-23 19:55:55.91724	28	view	work	4
107	2025-03-23 19:56:05.79629	2025-03-23 19:56:05.79629	28	view	work	4
108	2025-03-23 19:56:08.649783	2025-03-23 19:56:08.649783	28	view	work	4
109	2025-03-23 19:56:14.511953	2025-03-23 19:56:14.511953	28	view	work	4
110	2025-03-23 20:07:04.367742	2025-03-23 20:07:04.367742	28	view	stencil	33
111	2025-03-25 03:11:56.807222	2025-03-25 03:11:56.807222	29	view	stencil	15
112	2025-03-25 03:12:03.482418	2025-03-25 03:12:03.482418	29	view	stencil	18
\.


--
-- Data for Name: service; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.service (id, created_at, updated_at, name, description) FROM stdin;
1	2024-09-22 23:38:08.13827	2024-09-22 23:38:08.13827	Barber	Servicios de barbería
2	2024-09-22 23:38:08.13827	2024-09-22 23:38:08.13827	Tattoo Artist	Servicios de tatuajes
\.


--
-- Data for Name: stencil_tags; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.stencil_tags (stencil_id, tag_id) FROM stdin;
33	1
33	2
33	3
16	1
16	4
\.


--
-- Data for Name: stencils; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.stencils (id, created_at, updated_at, artist_id, title, description, image_url, image_version, thumbnail_url, thumbnail_version, price, deleted_at, tsv, is_featured, order_position, status, is_hidden, image_id, dimensions, recommended_placements, estimated_time, is_customizable, is_downloadable, license, license_url, is_available) FROM stdin;
9	2025-03-17 01:39:25.274912	2025-03-17 01:39:25.274912	9	sjjdjd	djdjs	https://d1riey1i0e5tx2.cloudfront.net/artist/9/stencils/stencil_fc8318d1444daaf457_v1.bin	1	https://d1riey1i0e5tx2.cloudfront.net/artist/9/stencils/stencil_thumbnail_fc8318d1444daaf457_v1.bin	0	\N	\N	'djdjs':2 'sjjdjd':1	t	0	AVAILABLE	t	fc8318d1444daaf457	\N	[]	\N	f	f	\N	\N	f
10	2025-03-17 01:39:52.734535	2025-03-17 01:39:52.734535	9	estencil 1	app	https://d1riey1i0e5tx2.cloudfront.net/artist/9/stencils/stencil_ea709ba32b7f38bc60_v1.bin	1	https://d1riey1i0e5tx2.cloudfront.net/artist/9/stencils/stencil_thumbnail_ea709ba32b7f38bc60_v1.bin	0	\N	\N	'1':2 'app':3 'estencil':1	t	0	AVAILABLE	t	ea709ba32b7f38bc60	\N	[]	\N	f	f	\N	\N	f
11	2025-03-17 01:40:08.107308	2025-03-17 01:43:42.773093	9	2		https://d1riey1i0e5tx2.cloudfront.net/artist/9/stencils/stencil_e0ac4f6a8e1c29fbe2_v1.bin	1	https://d1riey1i0e5tx2.cloudfront.net/artist/9/stencils/stencil_thumbnail_e0ac4f6a8e1c29fbe2_v1.bin	0	\N	\N	'2':1	f	0	AVAILABLE	f	e0ac4f6a8e1c29fbe2	\N	[]	\N	f	f	\N	\N	f
12	2025-03-18 01:35:10.544842	2025-03-18 01:35:10.544842	9	test		https://d1riey1i0e5tx2.cloudfront.net/artist/9/stencils/stencil_db2fc9fd9d019e4e40_v1.bin	1	https://d1riey1i0e5tx2.cloudfront.net/artist/9/stencils/stencil_thumbnail_db2fc9fd9d019e4e40_v1.bin	0	\N	\N	'test':1	t	0	AVAILABLE	t	db2fc9fd9d019e4e40	\N	[]	\N	f	f	\N	\N	f
13	2025-03-18 01:44:51.05793	2025-03-18 01:44:51.05793	9	test		https://d1riey1i0e5tx2.cloudfront.net/artist/9/stencils/stencil_48a45ebd5a2bfb3485_v1.bin	1	https://d1riey1i0e5tx2.cloudfront.net/artist/9/stencils/stencil_thumbnail_48a45ebd5a2bfb3485_v1.bin	0	\N	\N	'test':1	t	0	AVAILABLE	t	48a45ebd5a2bfb3485	\N	[]	\N	f	f	\N	\N	f
14	2025-03-18 01:55:11.614617	2025-03-18 01:55:11.614617	9	test		https://d1riey1i0e5tx2.cloudfront.net/artist/9/stencils/stencil_452832993ad47b02e8_v1.bin	1	https://d1riey1i0e5tx2.cloudfront.net/artist/9/stencils/stencil_thumbnail_452832993ad47b02e8_v1.bin	0	\N	\N	'test':1	t	0	AVAILABLE	t	452832993ad47b02e8	\N	[]	\N	f	f	\N	\N	f
26	2025-03-18 02:21:08.575294	2025-03-18 02:21:08.575294	9	0 1		https://d1riey1i0e5tx2.cloudfront.net/artist/9/stencils/stencil_fd98196a7696f42405_v1.bin	1	https://d1riey1i0e5tx2.cloudfront.net/artist/9/stencils/stencil_thumbnail_fd98196a7696f42405_v1.bin	0	\N	\N	'0':1 '1':2	f	0	AVAILABLE	t	fd98196a7696f42405	\N	[]	\N	f	f	\N	\N	f
15	2025-03-18 01:57:16.105623	2025-03-18 01:57:16.105623	9	y		https://d1riey1i0e5tx2.cloudfront.net/artist/9/stencils/stencil_ee25e29d38e35f35b7_v1.bin	1	https://d1riey1i0e5tx2.cloudfront.net/artist/9/stencils/stencil_thumbnail_ee25e29d38e35f35b7_v1.bin	0	\N	\N	'y':1	t	0	AVAILABLE	t	ee25e29d38e35f35b7	\N	[]	\N	f	f	\N	\N	f
18	2025-03-18 02:01:57.488462	2025-03-18 02:01:57.488462	9	h		https://d1riey1i0e5tx2.cloudfront.net/artist/9/stencils/stencil_965b9d2f177f99c372_v1.bin	1	https://d1riey1i0e5tx2.cloudfront.net/artist/9/stencils/stencil_thumbnail_965b9d2f177f99c372_v1.bin	0	\N	\N	'h':1	f	0	AVAILABLE	f	965b9d2f177f99c372	\N	[]	\N	f	f	\N	\N	f
20	2025-03-18 02:03:39.28176	2025-03-18 02:03:39.28176	9	h		https://d1riey1i0e5tx2.cloudfront.net/artist/9/stencils/stencil_c5dd8b7947da164788_v1.bin	1	https://d1riey1i0e5tx2.cloudfront.net/artist/9/stencils/stencil_thumbnail_c5dd8b7947da164788_v1.bin	0	\N	\N	'h':1	f	0	AVAILABLE	f	c5dd8b7947da164788	\N	[]	\N	f	f	\N	\N	f
21	2025-03-18 02:06:12.216648	2025-03-18 02:06:12.216648	9	no oculta no destacada		https://d1riey1i0e5tx2.cloudfront.net/artist/9/stencils/stencil_c11a6fe5638f46693b_v1.bin	1	https://d1riey1i0e5tx2.cloudfront.net/artist/9/stencils/stencil_thumbnail_c11a6fe5638f46693b_v1.bin	0	\N	\N	'destacada':4 'oculta':2	f	0	AVAILABLE	f	c11a6fe5638f46693b	\N	[]	\N	f	f	\N	\N	f
22	2025-03-18 02:07:40.177365	2025-03-18 02:07:40.177365	9	no destacada y oculta		https://d1riey1i0e5tx2.cloudfront.net/artist/9/stencils/stencil_3be769a4273aad2429_v1.bin	1	https://d1riey1i0e5tx2.cloudfront.net/artist/9/stencils/stencil_thumbnail_3be769a4273aad2429_v1.bin	0	\N	\N	'destacada':2 'oculta':4 'y':3	f	0	AVAILABLE	t	3be769a4273aad2429	\N	[]	\N	f	f	\N	\N	f
25	2025-03-18 02:20:45.695252	2025-03-18 02:20:45.695252	9	0 0		https://d1riey1i0e5tx2.cloudfront.net/artist/9/stencils/stencil_14af6ed2c61f6976b2_v1.bin	1	https://d1riey1i0e5tx2.cloudfront.net/artist/9/stencils/stencil_thumbnail_14af6ed2c61f6976b2_v1.bin	0	\N	\N	'0':1,2	f	0	AVAILABLE	f	14af6ed2c61f6976b2	\N	[]	\N	f	f	\N	\N	f
28	2025-03-18 02:21:44.119811	2025-03-18 02:26:35.402044	9	1 1	gg	https://d1riey1i0e5tx2.cloudfront.net/artist/9/stencils/stencil_30089af6b757c3cf42_v1.bin	1	https://d1riey1i0e5tx2.cloudfront.net/artist/9/stencils/stencil_thumbnail_30089af6b757c3cf42_v1.bin	0	\N	\N	'1':1,2 'gg':3	f	0	AVAILABLE	t	30089af6b757c3cf42	\N	[]	\N	f	f	\N	\N	f
27	2025-03-18 02:21:24.756681	2025-03-18 02:26:37.394248	9	1 0		https://d1riey1i0e5tx2.cloudfront.net/artist/9/stencils/stencil_32a3e07cdd11a496e8_v1.bin	1	https://d1riey1i0e5tx2.cloudfront.net/artist/9/stencils/stencil_thumbnail_32a3e07cdd11a496e8_v1.bin	0	\N	\N	'0':2 '1':1	f	0	AVAILABLE	t	32a3e07cdd11a496e8	\N	[]	\N	f	f	\N	\N	f
24	2025-03-18 02:08:31.583189	2025-03-18 02:26:41.456481	9	destacada y no oculta		https://d1riey1i0e5tx2.cloudfront.net/artist/9/stencils/stencil_063e3ab9d34f4fd1a3_v1.bin	1	https://d1riey1i0e5tx2.cloudfront.net/artist/9/stencils/stencil_thumbnail_063e3ab9d34f4fd1a3_v1.bin	0	\N	\N	'destacada':1 'oculta':4 'y':2	f	0	AVAILABLE	f	063e3ab9d34f4fd1a3	\N	[]	\N	f	f	\N	\N	f
23	2025-03-18 02:08:09.832748	2025-03-18 02:26:44.592866	9	destacada y oculta 		https://d1riey1i0e5tx2.cloudfront.net/artist/9/stencils/stencil_4e90bb6bdd2de08a3b_v1.bin	1	https://d1riey1i0e5tx2.cloudfront.net/artist/9/stencils/stencil_thumbnail_4e90bb6bdd2de08a3b_v1.bin	0	\N	\N	'destacada':1 'oculta':3 'y':2	f	0	AVAILABLE	f	4e90bb6bdd2de08a3b	\N	[]	\N	f	f	\N	\N	f
17	2025-03-18 01:59:24.611657	2025-03-19 02:49:30.356314	9	j		https://d1riey1i0e5tx2.cloudfront.net/artist/9/stencils/stencil_c5cc0655ac0a4571ce_v1.bin	1	https://d1riey1i0e5tx2.cloudfront.net/artist/9/stencils/stencil_thumbnail_c5cc0655ac0a4571ce_v1.bin	0	\N	2025-03-19 02:49:30.356314	'j':1	t	0	AVAILABLE	t	c5cc0655ac0a4571ce	\N	[]	\N	f	f	\N	\N	f
16	2025-03-18 01:58:12.304686	2025-03-22 17:30:15.036788	9	kkkkkk		https://d1riey1i0e5tx2.cloudfront.net/artist/9/stencils/stencil_cfd1a58a895259e39a_v1.bin	1	https://d1riey1i0e5tx2.cloudfront.net/artist/9/stencils/stencil_thumbnail_cfd1a58a895259e39a_v1.bin	0	\N	\N	'kkkkkk':1	f	0	AVAILABLE	f	cfd1a58a895259e39a	\N	[]	\N	f	f	\N	\N	f
33	2025-03-19 02:34:02.189536	2025-03-19 02:34:41.431152	9	test tags		https://d1riey1i0e5tx2.cloudfront.net/artist/9/stencils/stencil_c45253872bde05d9b2_v1.bin	1	https://d1riey1i0e5tx2.cloudfront.net/artist/9/stencils/stencil_thumbnail_c45253872bde05d9b2_v1.bin	0	\N	\N	'tag':2 'test':1	f	0	AVAILABLE	f	c45253872bde05d9b2	\N	[]	\N	f	f	\N	\N	f
19	2025-03-18 02:02:31.02757	2025-03-19 02:48:02.939362	9	k		https://d1riey1i0e5tx2.cloudfront.net/artist/9/stencils/stencil_25d63de8df484bf3ac_v1.bin	1	https://d1riey1i0e5tx2.cloudfront.net/artist/9/stencils/stencil_thumbnail_25d63de8df484bf3ac_v1.bin	0	\N	2025-03-19 02:48:02.939362	'k':1	t	0	AVAILABLE	f	25d63de8df484bf3ac	\N	[]	\N	f	f	\N	\N	f
\.


--
-- Data for Name: tag; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.tag (id, created_at, updated_at, name, created_by) FROM stdin;
1	2025-03-19 02:33:46.210272	2025-03-19 02:33:46.210272	hola	\N
2	2025-03-19 02:34:17.571071	2025-03-19 02:34:17.571071	nueva	\N
3	2025-03-19 02:34:37.178526	2025-03-19 02:34:37.178526	classic	\N
4	2025-03-19 02:49:13.864533	2025-03-19 02:49:13.864533	tradicional	\N
5	2025-03-22 04:28:30.050059	2025-03-22 04:28:30.050059	test	\N
6	2025-03-22 16:33:17.867329	2025-03-22 16:33:17.867329	help	\N
7	2025-03-22 16:33:19.857129	2025-03-22 16:33:19.857129	trap	\N
8	2025-03-22 16:33:19.880125	2025-03-22 16:33:19.880125	tra	\N
9	2025-03-22 16:37:35.494692	2025-03-22 16:37:35.494692	nuevo	\N
\.


--
-- Data for Name: work_tags; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.work_tags (work_id, tag_id) FROM stdin;
4	7
4	9
\.


--
-- Data for Name: works; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.works (id, created_at, updated_at, artist_id, title, description, image_url, image_version, thumbnail_url, thumbnail_version, is_featured, order_position, deleted_at, tsv, source, is_hidden, image_id) FROM stdin;
1	2025-03-21 03:46:07.311612	2025-03-22 17:18:48.78573	9	aersh h		https://d1riey1i0e5tx2.cloudfront.net/artist/9/works/work_244a13f7e5430e9d1f_v1.bin	1	https://d1riey1i0e5tx2.cloudfront.net/artist/9/works/work_thumbnail_244a13f7e5430e9d1f_v1.bin	0	f	0	\N	'aersh':1 'h':2	APP	f	work_244a13f7e5430e9d1f_v1.bin
4	2025-03-22 16:51:23.330577	2025-03-22 17:18:48.789183	9	prueba asa		https://d1riey1i0e5tx2.cloudfront.net/artist/9/works/work_d31f0752bc7c8f7459_v1.bin	1	https://d1riey1i0e5tx2.cloudfront.net/artist/9/works/work_thumbnail_d31f0752bc7c8f7459_v1.bin	0	f	0	\N	'asa':2,4 'prueb':3 'prueba':1	APP	f	work_d31f0752bc7c8f7459_v1.bin
\.


--
-- Name: artist_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.artist_id_seq', 12, true);


--
-- Name: contact_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.contact_id_seq', 12, true);


--
-- Name: interactions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.interactions_id_seq', 112, true);


--
-- Name: service_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.service_id_seq', 2, true);


--
-- Name: stencils_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.stencils_id_seq', 33, true);


--
-- Name: tag_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.tag_id_seq', 9, true);


--
-- Name: works_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.works_id_seq', 4, true);


--
-- Name: contact PK_2cbbe00f59ab6b3bb5b8d19f989; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.contact
    ADD CONSTRAINT "PK_2cbbe00f59ab6b3bb5b8d19f989" PRIMARY KEY (id);


--
-- Name: stencils PK_37b0357f453237217b664b0fe3e; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.stencils
    ADD CONSTRAINT "PK_37b0357f453237217b664b0fe3e" PRIMARY KEY (id);


--
-- Name: artist_styles PK_4a2907722f47519040b7f1e7bee; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.artist_styles
    ADD CONSTRAINT "PK_4a2907722f47519040b7f1e7bee" PRIMARY KEY (artist_id, style_name);


--
-- Name: artist PK_55b76e71568b5db4d01d3e394ed; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.artist
    ADD CONSTRAINT "PK_55b76e71568b5db4d01d3e394ed" PRIMARY KEY (id);


--
-- Name: service PK_85a21558c006647cd76fdce044b; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.service
    ADD CONSTRAINT "PK_85a21558c006647cd76fdce044b" PRIMARY KEY (id);


--
-- Name: tag PK_8e4052373c579afc1471f526760; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.tag
    ADD CONSTRAINT "PK_8e4052373c579afc1471f526760" PRIMARY KEY (id);


--
-- Name: interactions PK_911b7416a6671b4148b18c18ecb; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.interactions
    ADD CONSTRAINT "PK_911b7416a6671b4148b18c18ecb" PRIMARY KEY (id);


--
-- Name: works PK_a9ffbf516ba6e52604b29e5cce0; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.works
    ADD CONSTRAINT "PK_a9ffbf516ba6e52604b29e5cce0" PRIMARY KEY (id);


--
-- Name: artist_services PK_bff6a5f79ac2d5001a4335eb613; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.artist_services
    ADD CONSTRAINT "PK_bff6a5f79ac2d5001a4335eb613" PRIMARY KEY (artist_id, service_id);


--
-- Name: stencil_tags PK_dc74cb902062fe0d2240762eedd; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.stencil_tags
    ADD CONSTRAINT "PK_dc74cb902062fe0d2240762eedd" PRIMARY KEY (stencil_id, tag_id);


--
-- Name: work_tags PK_e2bdef324689c6f7a0f299a3c64; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.work_tags
    ADD CONSTRAINT "PK_e2bdef324689c6f7a0f299a3c64" PRIMARY KEY (work_id, tag_id);


--
-- Name: artist_tags PK_e9dd96c54c32a99d1f20131bbad; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.artist_tags
    ADD CONSTRAINT "PK_e9dd96c54c32a99d1f20131bbad" PRIMARY KEY (artist_id, tag_id);


--
-- Name: artist_services_service PK_f00052bfc04552724888fbba399; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.artist_services_service
    ADD CONSTRAINT "PK_f00052bfc04552724888fbba399" PRIMARY KEY ("artistId", "serviceId");


--
-- Name: artist REL_292e15f38dd57107d4ea27ea17; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.artist
    ADD CONSTRAINT "REL_292e15f38dd57107d4ea27ea17" UNIQUE (contact_id);


--
-- Name: service UQ_7806a14d42c3244064b4a1706ca; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.service
    ADD CONSTRAINT "UQ_7806a14d42c3244064b4a1706ca" UNIQUE (name);


--
-- Name: service unique_service_name; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.service
    ADD CONSTRAINT unique_service_name UNIQUE (name);


--
-- Name: IDX_01528141d43ba0812a1bd51f1b; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_01528141d43ba0812a1bd51f1b" ON public.artist USING btree (user_id);


--
-- Name: IDX_0865d329b903f353b0aeb61e1e; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_0865d329b903f353b0aeb61e1e" ON public.stencil_tags USING btree (tag_id);


--
-- Name: IDX_0c0233d80c8b8a29c44add2a12; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_0c0233d80c8b8a29c44add2a12" ON public.stencils USING btree (tsv);


--
-- Name: IDX_148af0166f8adf533482846777; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_148af0166f8adf533482846777" ON public.artist_services_service USING btree ("artistId");


--
-- Name: IDX_444768e1db2128d9102c64d760; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_444768e1db2128d9102c64d760" ON public.artist USING btree (deleted_at);


--
-- Name: IDX_4a43ca7b9f68dc8ed1663994d7; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_4a43ca7b9f68dc8ed1663994d7" ON public.artist USING btree (rating);


--
-- Name: IDX_4d36169d3b489ea8bfdb9f9c09; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_4d36169d3b489ea8bfdb9f9c09" ON public.works USING btree (deleted_at);


--
-- Name: IDX_50ada619efd80a6abc56401fee; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_50ada619efd80a6abc56401fee" ON public.works USING btree (tsv);


--
-- Name: IDX_55598cd484850a747685c78723; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_55598cd484850a747685c78723" ON public.work_tags USING btree (tag_id);


--
-- Name: IDX_59962fa0fe4a491273c402e93f; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_59962fa0fe4a491273c402e93f" ON public.interactions USING btree (user_id);


--
-- Name: IDX_5ca38f816304b40dd0637ef2b1; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_5ca38f816304b40dd0637ef2b1" ON public.artist USING btree (first_name, last_name, username);


--
-- Name: IDX_6a9775008add570dc3e5a0bab7; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_6a9775008add570dc3e5a0bab7" ON public.tag USING btree (name);


--
-- Name: IDX_6b9d2aa8a96d134a30f49067a8; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_6b9d2aa8a96d134a30f49067a8" ON public.works USING btree (is_featured);


--
-- Name: IDX_6dcd961b8630370e0ad0a29eed; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_6dcd961b8630370e0ad0a29eed" ON public.stencils USING btree (artist_id);


--
-- Name: IDX_7ab4a0a0efdc71ec90e1de418b; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_7ab4a0a0efdc71ec90e1de418b" ON public.works USING btree (is_hidden);


--
-- Name: IDX_7b153fe07bda01ebdb5bfdc2a7; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_7b153fe07bda01ebdb5bfdc2a7" ON public.works USING btree (source);


--
-- Name: IDX_83c59c479d292f6a03ad842b5a; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_83c59c479d292f6a03ad842b5a" ON public.artist_services_service USING btree ("serviceId");


--
-- Name: IDX_86485c4347a0a211be01b6bbe2; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_86485c4347a0a211be01b6bbe2" ON public.stencil_tags USING btree (stencil_id);


--
-- Name: IDX_887b965a6e195cb4ad42f5ec1f; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_887b965a6e195cb4ad42f5ec1f" ON public.artist_tags USING btree (artist_id);


--
-- Name: IDX_8c79246222d0cce60dbb5c44c3; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_8c79246222d0cce60dbb5c44c3" ON public.artist_tags USING btree (tag_id);


--
-- Name: IDX_9d6f665830d7610c3232592030; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_9d6f665830d7610c3232592030" ON public.artist_services USING btree (service_id);


--
-- Name: IDX_ad916e8f555df362cbde837513; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_ad916e8f555df362cbde837513" ON public.artist USING btree (username);


--
-- Name: IDX_ade287b284aee4855c7f0d16db; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_ade287b284aee4855c7f0d16db" ON public.stencils USING btree (deleted_at);


--
-- Name: IDX_ba830dda30ca54c5433c29f0d8; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_ba830dda30ca54c5433c29f0d8" ON public.artist_services USING btree (artist_id);


--
-- Name: IDX_ca9018be3cc3d0803b924c17b0; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_ca9018be3cc3d0803b924c17b0" ON public.interactions USING btree (entity_type, entity_id);


--
-- Name: IDX_ce36fbc731b2b73c1304f2ec7b; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_ce36fbc731b2b73c1304f2ec7b" ON public.works USING btree (image_id);


--
-- Name: IDX_d94b1d75c4afcee63f0e519dbb; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_d94b1d75c4afcee63f0e519dbb" ON public.interactions USING btree (interaction_type);


--
-- Name: IDX_d9652285b640595c4e10185b2a; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_d9652285b640595c4e10185b2a" ON public.work_tags USING btree (work_id);


--
-- Name: IDX_e4bf8e5897fcaf11d24a9d98df; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_e4bf8e5897fcaf11d24a9d98df" ON public.stencils USING btree (status);


--
-- Name: IDX_e901d3dbb3303edc7b5ea16073; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_e901d3dbb3303edc7b5ea16073" ON public.stencils USING btree (is_hidden);


--
-- Name: IDX_ffe01bc889cb1121850aca9a0f; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_ffe01bc889cb1121850aca9a0f" ON public.works USING btree (artist_id);


--
-- Name: stencil_tags FK_0865d329b903f353b0aeb61e1ef; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.stencil_tags
    ADD CONSTRAINT "FK_0865d329b903f353b0aeb61e1ef" FOREIGN KEY (tag_id) REFERENCES public.tag(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: artist_services_service FK_148af0166f8adf533482846777d; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.artist_services_service
    ADD CONSTRAINT "FK_148af0166f8adf533482846777d" FOREIGN KEY ("artistId") REFERENCES public.artist(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: work_tags FK_55598cd484850a747685c787234; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.work_tags
    ADD CONSTRAINT "FK_55598cd484850a747685c787234" FOREIGN KEY (tag_id) REFERENCES public.tag(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: stencils FK_6dcd961b8630370e0ad0a29eed7; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.stencils
    ADD CONSTRAINT "FK_6dcd961b8630370e0ad0a29eed7" FOREIGN KEY (artist_id) REFERENCES public.artist(id);


--
-- Name: artist_services_service FK_83c59c479d292f6a03ad842b5a0; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.artist_services_service
    ADD CONSTRAINT "FK_83c59c479d292f6a03ad842b5a0" FOREIGN KEY ("serviceId") REFERENCES public.service(id);


--
-- Name: stencil_tags FK_86485c4347a0a211be01b6bbe23; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.stencil_tags
    ADD CONSTRAINT "FK_86485c4347a0a211be01b6bbe23" FOREIGN KEY (stencil_id) REFERENCES public.stencils(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: artist_tags FK_887b965a6e195cb4ad42f5ec1f9; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.artist_tags
    ADD CONSTRAINT "FK_887b965a6e195cb4ad42f5ec1f9" FOREIGN KEY (artist_id) REFERENCES public.artist(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: artist_tags FK_8c79246222d0cce60dbb5c44c35; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.artist_tags
    ADD CONSTRAINT "FK_8c79246222d0cce60dbb5c44c35" FOREIGN KEY (tag_id) REFERENCES public.tag(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: artist_styles FK_8ce1ebc6ad11d6326df27477298; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.artist_styles
    ADD CONSTRAINT "FK_8ce1ebc6ad11d6326df27477298" FOREIGN KEY (artist_id) REFERENCES public.artist(id);


--
-- Name: artist_services FK_9d6f665830d7610c32325920304; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.artist_services
    ADD CONSTRAINT "FK_9d6f665830d7610c32325920304" FOREIGN KEY (service_id) REFERENCES public.service(id);


--
-- Name: artist_services FK_ba830dda30ca54c5433c29f0d8f; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.artist_services
    ADD CONSTRAINT "FK_ba830dda30ca54c5433c29f0d8f" FOREIGN KEY (artist_id) REFERENCES public.artist(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: work_tags FK_d9652285b640595c4e10185b2ab; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.work_tags
    ADD CONSTRAINT "FK_d9652285b640595c4e10185b2ab" FOREIGN KEY (work_id) REFERENCES public.works(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: works FK_ffe01bc889cb1121850aca9a0fd; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.works
    ADD CONSTRAINT "FK_ffe01bc889cb1121850aca9a0fd" FOREIGN KEY (artist_id) REFERENCES public.artist(id);


--
-- Name: artist fk_artist_contact; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.artist
    ADD CONSTRAINT fk_artist_contact FOREIGN KEY (contact_id) REFERENCES public.contact(id);


--
-- PostgreSQL database dump complete
--

