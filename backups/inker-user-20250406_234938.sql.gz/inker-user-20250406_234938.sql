--
-- PostgreSQL database dump
--

-- Dumped from database version 17.2 (Debian 17.2-1.pgdg110+1)
-- Dumped by pg_dump version 17.2 (Debian 17.2-1.pgdg110+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: permission; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.permission (
    id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    controller character varying NOT NULL,
    action character varying NOT NULL,
    description character varying
);


ALTER TABLE public.permission OWNER TO root;

--
-- Name: permission_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.permission_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.permission_id_seq OWNER TO root;

--
-- Name: permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.permission_id_seq OWNED BY public.permission.id;


--
-- Name: role; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.role (
    id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    name character varying NOT NULL,
    description character varying NOT NULL
);


ALTER TABLE public.role OWNER TO root;

--
-- Name: role_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.role_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.role_id_seq OWNER TO root;

--
-- Name: role_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.role_id_seq OWNED BY public.role.id;


--
-- Name: role_permission; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.role_permission (
    "roleId" integer NOT NULL,
    "permissionId" integer NOT NULL
);


ALTER TABLE public.role_permission OWNER TO root;

--
-- Name: settings; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.settings (
    id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    "userId" integer NOT NULL,
    "notificationsEnabled" boolean DEFAULT true NOT NULL,
    "locationServicesEnabled" boolean DEFAULT true NOT NULL,
    preferences jsonb,
    user_id integer
);


ALTER TABLE public.settings OWNER TO root;

--
-- Name: settings_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.settings_id_seq OWNER TO root;

--
-- Name: settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.settings_id_seq OWNED BY public.settings.id;


--
-- Name: user; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public."user" (
    id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    username character varying(100) NOT NULL,
    email character varying NOT NULL,
    password character varying NOT NULL,
    user_type character varying NOT NULL,
    active boolean DEFAULT false NOT NULL,
    deleted_at timestamp without time zone,
    "roleId" integer,
    phone_number character varying
);


ALTER TABLE public."user" OWNER TO root;

--
-- Name: user_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_id_seq OWNER TO root;

--
-- Name: user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.user_id_seq OWNED BY public."user".id;


--
-- Name: verification_hash; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.verification_hash (
    id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    user_id integer NOT NULL,
    hash character varying NOT NULL,
    tries integer NOT NULL,
    notification_type character varying NOT NULL,
    verification_type character varying NOT NULL,
    email character varying,
    phone character varying
);


ALTER TABLE public.verification_hash OWNER TO root;

--
-- Name: verification_hash_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.verification_hash_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.verification_hash_id_seq OWNER TO root;

--
-- Name: verification_hash_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.verification_hash_id_seq OWNED BY public.verification_hash.id;


--
-- Name: permission id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.permission ALTER COLUMN id SET DEFAULT nextval('public.permission_id_seq'::regclass);


--
-- Name: role id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.role ALTER COLUMN id SET DEFAULT nextval('public.role_id_seq'::regclass);


--
-- Name: settings id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.settings ALTER COLUMN id SET DEFAULT nextval('public.settings_id_seq'::regclass);


--
-- Name: user id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."user" ALTER COLUMN id SET DEFAULT nextval('public.user_id_seq'::regclass);


--
-- Name: verification_hash id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.verification_hash ALTER COLUMN id SET DEFAULT nextval('public.verification_hash_id_seq'::regclass);


--
-- Data for Name: permission; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.permission (id, created_at, updated_at, controller, action, description) FROM stdin;
1	2023-01-09 23:59:17.081812	2023-01-09 23:59:17.132398	ArtistsController	*	\N
2	2023-01-09 23:59:17.145968	2023-01-09 23:59:17.145968	AuthController	*	\N
3	2023-01-09 23:59:17.15348	2023-01-09 23:59:17.15348	CommentsController	*	\N
4	2023-01-09 23:59:17.162596	2023-01-09 23:59:17.162596	CustomersController	*	\N
5	2023-01-09 23:59:17.169444	2023-01-09 23:59:17.169444	FollowsController	*	\N
6	2023-01-09 23:59:17.176358	2023-01-09 23:59:17.176358	HealthController	*	\N
7	2023-01-09 23:59:17.184069	2023-01-09 23:59:17.184069	LocationsController	*	\N
8	2023-01-09 23:59:17.193808	2023-01-09 23:59:17.193808	MultimediasController	*	\N
9	2023-01-09 23:59:17.201409	2023-01-09 23:59:17.201409	PermissionsController	*	\N
10	2023-01-09 23:59:17.209724	2023-01-09 23:59:17.209724	PostsController	*	\N
11	2023-01-09 23:59:17.217478	2023-01-09 23:59:17.217478	ReactionsController	*	\N
12	2023-01-09 23:59:17.229055	2023-01-09 23:59:17.229055	ReviewsController	*	\N
13	2023-01-09 23:59:17.23901	2023-01-09 23:59:17.23901	RolesController	*	\N
14	2023-01-09 23:59:17.24915	2023-01-09 23:59:17.24915	UsersController	*	\N
\.


--
-- Data for Name: role; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.role (id, created_at, updated_at, name, description) FROM stdin;
1	2023-01-10 00:01:45.817096	2023-01-10 00:01:45.817096	admin	Administrator
2	2023-01-10 00:01:45.834394	2023-01-10 00:01:45.834394	customer	Customer
3	2023-01-10 00:01:45.852015	2023-01-10 00:01:45.852015	artist	Artist
4	2023-01-10 00:01:45.864666	2023-01-10 00:01:45.864666	lessor	Lessor studios or instruments
5	2023-01-10 00:01:45.876398	2023-01-10 00:01:45.876398	superuser	Superuser test
\.


--
-- Data for Name: role_permission; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.role_permission ("roleId", "permissionId") FROM stdin;
2	1
2	4
2	10
2	14
3	1
3	4
3	10
3	14
4	1
4	4
4	10
4	14
5	1
5	4
5	9
5	10
5	13
5	14
\.


--
-- Data for Name: settings; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.settings (id, created_at, updated_at, "userId", "notificationsEnabled", "locationServicesEnabled", preferences, user_id) FROM stdin;
1	2024-12-17 00:58:16.920865	2024-12-17 00:59:50.676239	4	t	t	\N	\N
2	2024-12-17 03:10:47.111334	2024-12-17 03:10:47.111334	15	t	t	\N	\N
3	2024-12-18 19:06:29.712952	2024-12-18 19:06:29.712952	31	t	t	\N	\N
4	2024-12-20 03:48:47.234111	2024-12-20 03:48:47.234111	1	t	t	\N	\N
5	2024-12-20 03:51:40.543741	2024-12-20 03:51:40.543741	6	t	t	\N	\N
7	2024-12-22 00:20:12.784531	2024-12-22 00:20:12.784531	40	t	t	\N	\N
6	2024-12-21 23:19:31.546904	2025-03-22 17:38:14.22976	29	t	t	\N	\N
\.


--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public."user" (id, created_at, updated_at, username, email, password, user_type, active, deleted_at, "roleId", phone_number) FROM stdin;
30	2024-10-27 18:30:22.551079	2024-10-27 18:30:22.551079	bla	blaadasq@gmail.com	$2a$08$KycN2SOZwoJydBFMIlusoOVk7v1u1i/s82qaBmGaQa0.5lqsewbKW	ARTIST	t	\N	3	
31	2024-11-12 02:16:38.511407	2024-12-19 00:42:53.733502	ejemplo2	lucas@gmail.com	$2a$08$tZNDMDxroptgjfVxMgRriu2MOrom6uPzGf2Kx3K/oqFZtnIptz4jC	ARTIST	t	2024-12-18 16:18:30.454	3	+56964484712
4	2023-01-10 00:58:48.938055	2024-12-20 03:24:46.641018	Henry-Lucas-43090	lucas2@gmail.com	$2a$08$zCQOnccwcshdxf6n.f4i2eY.7ZtBjxZIeoOzcTkvSGGOE.KsEN6E.	CUSTOMER	t	\N	2	
32	2024-12-21 23:20:38.257123	2024-12-21 23:20:38.257123	Likeman-Juanoo-77759	lucas1@gmail.com	$2a$08$rgAplRnTex3iXDfczhKcpe.63oeg.cjxcKYBdfkNfe4F0rRZRPoH2	CUSTOMER	f	\N	2	+56964484712
33	2024-12-21 23:30:33.007245	2024-12-21 23:30:33.007245	Henry-Lucas-84167	lucas3@gmail.com	$2a$08$CZQBp9r1Hw8ag447gt//suDUkcKzdW111G2IYikRGG3prVu0ESJnq	CUSTOMER	f	\N	2	+56964484712
34	2024-12-21 23:34:51.457986	2024-12-21 23:34:51.457986	Henry-Lucas-17871	lucas4@gmail.com	$2a$08$7dvo6uweFjH.PcbG/Es/RuCKiZfPXyxAOa6RTbwqUf5uE5VNMmm6u	CUSTOMER	f	\N	2	+56964484712
36	2024-12-22 00:03:53.23879	2024-12-22 00:03:53.23879	Carrasco-Paula-89259	paula.masiel.carrasco@gmail.com	$2a$08$rVZ7XZ8Nzrfhjj46LP3PsOE5KZ3.8kmOtTY3FxwiB9.5oUjF3UYES	CUSTOMER	t	\N	2	+56979980676
1	2023-01-10 00:03:20.44959	2023-01-10 00:05:46.533839	juanart	juan@art.cl	$2a$08$pU2Pvp9UfrWehHQezHGRfOtHC9y6kv8ljPsbd5wIiTVgzg9RR4flq	ARTIST	t	\N	3	
2	2023-01-10 00:08:58.361979	2023-01-10 00:09:14.968153	locorene	loco@rene.cl	$2a$08$sRTcP.ugWHrMfE.4gl16m.XvPvBS7Cf.nwHAkv.BCEQQ/7leN7gP2	ARTIST	t	\N	3	
3	2023-01-10 00:12:53.576949	2023-01-10 00:13:58.0232	viejopascuero	viejo@pascuero.cl	$2a$08$0yLoZI8/JIFkDkKvZ3emCuXY6UVEglRGCsq0ZOPW/UweB/gMLrhGa	ARTIST	t	\N	3	
5	2023-02-16 01:46:01.913632	2023-02-16 01:46:01.913632	Henry-Andre-43091	andre.henrydz@gmail.com	$2a$08$OAMN.ib7phH4qz.jHjmKqODDWeGiAIBMtXzJYqpUSoaq/luIYfYcm	CUSTOMER	t	\N	2	
6	2023-02-21 00:29:44.917434	2023-02-21 00:29:44.917434	paula-43091	paula@gmail.com	$2a$08$tu4s8NVtyScRkKVZtRuIeO1N7QZ8foROWP3TFdlCvd/N.2pFOhJ8q	CUSTOMER	t	\N	2	
7	2023-03-21 02:30:42.223402	2023-03-21 02:30:42.223402	test1	test1@test.com	$2a$08$xjqnbmxaZMbGs7Es6mUa9OgeubxjdHcuwjj3dMjGnKMvyJoGo88FO	CUSTOMER	f	\N	2	
8	2023-03-21 02:36:10.88077	2023-03-21 02:36:10.88077	test2	test2@test.com	$2a$08$NxBC3lI0R54RuZ4VRnz0Be11TQMn8jLYTds2B6/qvV8ifkfwL4XnC	CUSTOMER	f	\N	2	
9	2023-03-21 02:36:50.290681	2023-03-21 02:36:50.290681	test3	test3@test.com	$2a$08$8UVEjydj/04nbD5ExL9FJ.pJmVkjGhgiXldYhAPJnWRGXMCIeQ9eK	CUSTOMER	f	\N	2	
10	2023-03-21 02:38:16.198814	2023-03-21 02:38:16.198814	test4	test4@test.com	$2a$08$/w1iJqk/PQg.BTf9vPEDY.hgjtYjjXdcVL8E0bUzS6OHW6LdSQww2	CUSTOMER	f	\N	2	
28	2024-10-27 03:52:40.411622	2024-10-27 03:53:06.943299	Kefai-Luano-85357	launo@kefai.cl	$2a$08$RoOBEZgMrc/LUPygZnyyyeafExIOR8jl3Yb.tz7A8SElv2mIWlbA.	CUSTOMER	t	\N	2	
29	2024-10-27 04:29:07.458144	2024-10-27 04:29:07.458144	jualiart	admin@gmail.com	$2a$08$6TgT8pOsUsDEosbsb0KiQOiLSPEhsP/5ovYG7HKTK9579WwpI/cP.	ARTIST	t	\N	3	
37	2024-12-22 00:11:25.291946	2024-12-22 00:11:25.291946	Giuria-Catalina-26943	cataa.giuria@gmail.com	$2a$08$g9P.arVh7zV0.xbS9aUa4OU2Vm6XIo6varvdg5i5kXPMu9tyYRSOK	CUSTOMER	t	\N	2	+56992557103
38	2024-12-22 00:15:41.75895	2024-12-22 00:15:41.75895	gina-geinse	ginageinse@gmail.com	$2a$08$l5856HpWvaOYqWl3jMLHVuxSb/2/krPFkIpGxHZQfAOEMfvnCjAwm	ARTIST	t	\N	3	+56989030326
40	2024-12-22 00:17:52.204237	2024-12-22 00:17:52.204237	Urbina-Leonardo-31434	leo.urbinaa@gmail.com	$2a$08$rfThQNrERTVWr3LaEMdHTOUzQpRMWSUaDLV7DM24docV/doppfoay	CUSTOMER	t	\N	2	+56934009744
35	2024-12-21 23:44:32.033435	2024-12-21 23:44:32.033435	Henry-Lucas-10487	lucas.henrydz@gmail.com	$2a$08$mgyXPBkqjS4dP16dM15In.iIHUk98vj7.ShVCDaPhSKDYDQ/NcZdW	CUSTOMER	t	\N	2	+56964484712
\.


--
-- Data for Name: verification_hash; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.verification_hash (id, created_at, updated_at, user_id, hash, tries, notification_type, verification_type, email, phone) FROM stdin;
10	2024-10-27 04:29:12.092911	2024-10-27 04:29:12.092911	29	$2a$16$4ELGNKk3yZDP4R6wmknsluab4/vJ4MESt8YzylRoujIBPtrgG6bLe	1	SMS	ACTIVATE_ACCOUNT	\N	\N
11	2024-10-27 18:30:27.020657	2024-10-27 18:30:27.020657	30	$2a$16$/B9XC54sSJbc7jcsmF9m1.gCCfk0cjSJa1U8MQIVAI8vt8bTsM3z.	1	SMS	ACTIVATE_ACCOUNT	\N	\N
7	2023-05-05 16:52:13.897325	2024-12-18 14:37:40.287599	14	$2a$16$XwBZD7sjRQsyMkYpN9wvG.Q7Y3cgmRdXzhRScjdYfVBKhn9izCtb2	3	SMS	ACTIVATE_ACCOUNT	\N	\N
14	2024-12-18 19:26:51.449878	2024-12-18 19:46:03.190602	31	$2a$16$9sY4rRzotXYS8kSKGIO8YupNaNxgph.3og71BzNezZCe.Pr8BGvpK	1	EMAIL	ACTIVATE_ACCOUNT	\N	\N
28	2024-12-21 23:34:55.819694	2024-12-21 23:34:55.819694	34	$2a$16$OU1LCT5ciGA/QK2uPO2LSuIE0bLLewXdYtoo5aY77jo0v/ZfGXfq.	1	EMAIL	ACTIVATE_ACCOUNT	\N	\N
29	2024-12-22 00:03:57.570969	2024-12-22 00:03:57.570969	36	$2a$16$6QTx1FCdWk.sfQtUcnLBLuQNYijvVDZcdQKk.bvBgbxGRyzmX3FPW	1	SMS	ACTIVATE_ACCOUNT	\N	\N
30	2024-12-22 00:08:12.034324	2024-12-22 00:08:12.034324	36	$2a$16$m7r9OIWddKuwlLSRJg.6Gugs99BSW3RfqHJOB0fe7w6k1o9/Q0Ru2	1	EMAIL	ACTIVATE_ACCOUNT	\N	\N
31	2024-12-22 00:11:29.576897	2024-12-22 00:11:29.576897	37	$2a$16$kJiyoulBsdC.W3icwja51.tQNjld2hOdMPXD78HE6QcF5BH9x4UUe	1	SMS	ACTIVATE_ACCOUNT	\N	\N
32	2024-12-22 00:15:46.189319	2024-12-22 00:15:46.189319	38	$2a$16$U1ZpzIDqHyOXMSNedFuHLegM4Isxq4v.v0gB0cjOW/1DncqtDKo02	1	SMS	ACTIVATE_ACCOUNT	\N	\N
33	2024-12-22 00:16:04.475777	2024-12-22 00:17:56.991376	39	$2a$16$zVoCZLv3I2jDOLY7Ytw50uuI4ZIPYVWOimlYFwpNm/yh3DSyWOn6q	2	SMS	ACTIVATE_ACCOUNT	\N	\N
34	2024-12-22 00:17:59.135368	2024-12-22 00:17:59.135368	40	$2a$16$iiJwFEJx.jHp4eC0kHABM.H9/.kGbH/KO6T.VhsHDiH2SMZ.0rm6u	1	SMS	ACTIVATE_ACCOUNT	\N	\N
\.


--
-- Name: permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.permission_id_seq', 14, true);


--
-- Name: role_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.role_id_seq', 5, true);


--
-- Name: settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.settings_id_seq', 7, true);


--
-- Name: user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.user_id_seq', 40, true);


--
-- Name: verification_hash_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.verification_hash_id_seq', 34, true);


--
-- Name: settings PK_0669fe20e252eb692bf4d344975; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT "PK_0669fe20e252eb692bf4d344975" PRIMARY KEY (id);


--
-- Name: verification_hash PK_2c717c842fd23dc4f75ab5e2fbd; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.verification_hash
    ADD CONSTRAINT "PK_2c717c842fd23dc4f75ab5e2fbd" PRIMARY KEY (id);


--
-- Name: permission PK_3b8b97af9d9d8807e41e6f48362; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.permission
    ADD CONSTRAINT "PK_3b8b97af9d9d8807e41e6f48362" PRIMARY KEY (id);


--
-- Name: role PK_b36bcfe02fc8de3c57a8b2391c2; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.role
    ADD CONSTRAINT "PK_b36bcfe02fc8de3c57a8b2391c2" PRIMARY KEY (id);


--
-- Name: role_permission PK_b42bbacb8402c353df822432544; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.role_permission
    ADD CONSTRAINT "PK_b42bbacb8402c353df822432544" PRIMARY KEY ("roleId", "permissionId");


--
-- Name: user PK_cace4a159ff9f2512dd42373760; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT "PK_cace4a159ff9f2512dd42373760" PRIMARY KEY (id);


--
-- Name: settings REL_a2883eaa72b3b2e8c98e744609; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT "REL_a2883eaa72b3b2e8c98e744609" UNIQUE (user_id);


--
-- Name: permission UQ_9573e71191df070245e24255230; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.permission
    ADD CONSTRAINT "UQ_9573e71191df070245e24255230" UNIQUE (controller);


--
-- Name: IDX_60e71e288bab95a5ac05f58a84; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_60e71e288bab95a5ac05f58a84" ON public."user" USING btree (user_type);


--
-- Name: IDX_6142d018460a0f1d602dcac6cb; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_6142d018460a0f1d602dcac6cb" ON public.verification_hash USING btree (user_id);


--
-- Name: IDX_72e80be86cab0e93e67ed1a7a9; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_72e80be86cab0e93e67ed1a7a9" ON public.role_permission USING btree ("permissionId");


--
-- Name: IDX_a2fbc58df09b3f7d313b44efee; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_a2fbc58df09b3f7d313b44efee" ON public.verification_hash USING btree (phone);


--
-- Name: IDX_ae4578dcaed5adff96595e6166; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_ae4578dcaed5adff96595e6166" ON public.role USING btree (name);


--
-- Name: IDX_e3130a39c1e4a740d044e68573; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_e3130a39c1e4a740d044e68573" ON public.role_permission USING btree ("roleId");


--
-- Name: IDX_e85ede11c4408672807ea531c5; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "IDX_e85ede11c4408672807ea531c5" ON public.verification_hash USING btree (email);


--
-- Name: role_permission FK_72e80be86cab0e93e67ed1a7a9a; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.role_permission
    ADD CONSTRAINT "FK_72e80be86cab0e93e67ed1a7a9a" FOREIGN KEY ("permissionId") REFERENCES public.permission(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: settings FK_a2883eaa72b3b2e8c98e7446098; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT "FK_a2883eaa72b3b2e8c98e7446098" FOREIGN KEY (user_id) REFERENCES public."user"(id);


--
-- Name: user FK_c28e52f758e7bbc53828db92194; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT "FK_c28e52f758e7bbc53828db92194" FOREIGN KEY ("roleId") REFERENCES public.role(id);


--
-- Name: role_permission FK_e3130a39c1e4a740d044e685730; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.role_permission
    ADD CONSTRAINT "FK_e3130a39c1e4a740d044e685730" FOREIGN KEY ("roleId") REFERENCES public.role(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

