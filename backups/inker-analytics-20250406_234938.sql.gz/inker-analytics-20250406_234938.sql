--
-- PostgreSQL database dump
--

-- Dumped from database version 17.2 (Debian 17.2-1.pgdg110+1)
-- Dumped by pg_dump version 17.2 (Debian 17.2-1.pgdg110+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: content_metrics_content_type_enum; Type: TYPE; Schema: public; Owner: root
--

CREATE TYPE public.content_metrics_content_type_enum AS ENUM (
    'stencil',
    'work',
    'artist_profile'
);


ALTER TYPE public.content_metrics_content_type_enum OWNER TO root;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: artist_metrics; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.artist_metrics (
    id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    artist_id integer NOT NULL,
    metrics jsonb DEFAULT '{"views": {"count": 0, "uniqueCount": 0}}'::jsonb NOT NULL
);


ALTER TABLE public.artist_metrics OWNER TO root;

--
-- Name: artist_metrics_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.artist_metrics_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.artist_metrics_id_seq OWNER TO root;

--
-- Name: artist_metrics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.artist_metrics_id_seq OWNED BY public.artist_metrics.id;


--
-- Name: artist_metrics_viewers; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.artist_metrics_viewers (
    id integer NOT NULL,
    metrics_id integer NOT NULL,
    viewer_key character varying(100) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.artist_metrics_viewers OWNER TO root;

--
-- Name: artist_metrics_viewers_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.artist_metrics_viewers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.artist_metrics_viewers_id_seq OWNER TO root;

--
-- Name: artist_metrics_viewers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.artist_metrics_viewers_id_seq OWNED BY public.artist_metrics_viewers.id;


--
-- Name: content_metrics; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.content_metrics (
    id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    content_id integer NOT NULL,
    content_type public.content_metrics_content_type_enum NOT NULL,
    metrics jsonb DEFAULT '{"views": {"count": 0, "uniqueCount": 0}}'::jsonb NOT NULL
);


ALTER TABLE public.content_metrics OWNER TO root;

--
-- Name: content_metrics_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.content_metrics_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.content_metrics_id_seq OWNER TO root;

--
-- Name: content_metrics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.content_metrics_id_seq OWNED BY public.content_metrics.id;


--
-- Name: content_metrics_viewers; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.content_metrics_viewers (
    id integer NOT NULL,
    metrics_id integer NOT NULL,
    viewer_key character varying(100) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.content_metrics_viewers OWNER TO root;

--
-- Name: content_metrics_viewers_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.content_metrics_viewers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.content_metrics_viewers_id_seq OWNER TO root;

--
-- Name: content_metrics_viewers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.content_metrics_viewers_id_seq OWNED BY public.content_metrics_viewers.id;


--
-- Name: query-result-cache; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public."query-result-cache" (
    id integer NOT NULL,
    identifier character varying,
    "time" bigint NOT NULL,
    duration integer NOT NULL,
    query text NOT NULL,
    result text NOT NULL
);


ALTER TABLE public."query-result-cache" OWNER TO root;

--
-- Name: query-result-cache_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public."query-result-cache_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."query-result-cache_id_seq" OWNER TO root;

--
-- Name: query-result-cache_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public."query-result-cache_id_seq" OWNED BY public."query-result-cache".id;


--
-- Name: artist_metrics id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.artist_metrics ALTER COLUMN id SET DEFAULT nextval('public.artist_metrics_id_seq'::regclass);


--
-- Name: artist_metrics_viewers id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.artist_metrics_viewers ALTER COLUMN id SET DEFAULT nextval('public.artist_metrics_viewers_id_seq'::regclass);


--
-- Name: content_metrics id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.content_metrics ALTER COLUMN id SET DEFAULT nextval('public.content_metrics_id_seq'::regclass);


--
-- Name: content_metrics_viewers id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.content_metrics_viewers ALTER COLUMN id SET DEFAULT nextval('public.content_metrics_viewers_id_seq'::regclass);


--
-- Name: query-result-cache id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."query-result-cache" ALTER COLUMN id SET DEFAULT nextval('public."query-result-cache_id_seq"'::regclass);


--
-- Data for Name: artist_metrics; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.artist_metrics (id, created_at, updated_at, artist_id, metrics) FROM stdin;
1	2025-04-04 01:46:06.627396	2025-04-04 01:46:06.627396	9	{"views": {"count": 4, "uniqueCount": 1}}
\.


--
-- Data for Name: artist_metrics_viewers; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.artist_metrics_viewers (id, metrics_id, viewer_key, created_at) FROM stdin;
1	1	viewer_35	2025-04-04 01:46:06.671914
\.


--
-- Data for Name: content_metrics; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.content_metrics (id, created_at, updated_at, content_id, content_type, metrics) FROM stdin;
33	2025-04-04 01:55:44.651484	2025-04-04 01:55:44.651484	23	stencil	{"views": {"count": 1, "uniqueCount": 1}}
19	2025-04-02 02:55:51.74147	2025-04-02 02:55:51.74147	27	stencil	{"views": {"count": 4, "uniqueCount": 1}}
18	2025-04-02 02:55:49.67322	2025-04-02 02:55:49.67322	28	stencil	{"views": {"count": 11, "uniqueCount": 1}, "reactions": {"like": {"count": 1, "userIds": [35]}}, "engagementRate": 100.0000000000000000}
34	2025-04-04 01:55:45.190922	2025-04-04 01:55:45.190922	22	stencil	{"views": {"count": 1, "uniqueCount": 1}}
22	2025-04-02 02:59:40.623265	2025-04-02 02:59:40.623265	10	stencil	{"views": {"count": 8, "uniqueCount": 1}, "reactions": {"like": {"count": 1, "userIds": [35]}}, "engagementRate": 100.0000000000000000}
37	2025-04-04 02:09:03.695662	2025-04-04 02:09:03.695662	11	stencil	{"views": {"count": 4, "uniqueCount": 1}}
24	2025-04-04 01:12:32.211956	2025-04-04 01:12:32.211956	4	work	{"views": {"count": 20, "uniqueCount": 1}}
35	2025-04-04 01:55:46.144286	2025-04-04 01:55:46.144286	21	stencil	{"views": {"count": 1, "uniqueCount": 1}}
31	2025-04-04 01:12:48.704954	2025-04-04 01:12:48.704954	12	stencil	{"views": {"count": 2, "uniqueCount": 1}, "reactions": {"like": {"count": 1, "userIds": [35]}}, "engagementRate": 100.0000000000000000}
36	2025-04-04 01:55:46.708816	2025-04-04 01:55:46.708816	20	stencil	{"views": {"count": 1, "uniqueCount": 1}}
17	2025-04-02 02:36:13.378605	2025-04-02 02:36:13.378605	33	stencil	{"views": {"count": 27, "uniqueCount": 1}, "reactions": {"like": {"count": 1, "userIds": [35]}}, "engagementRate": 12.5000000000000000}
21	2025-04-02 02:55:55.234604	2025-04-02 02:55:55.234604	25	stencil	{"views": {"count": 9, "uniqueCount": 1}}
25	2025-04-04 01:12:39.963989	2025-04-04 01:12:39.963989	1	work	{"views": {"count": 8, "uniqueCount": 1}}
29	2025-04-04 01:12:47.61468	2025-04-04 01:12:47.61468	14	stencil	{"views": {"count": 1, "uniqueCount": 1}}
30	2025-04-04 01:12:48.149694	2025-04-04 01:12:48.149694	13	stencil	{"views": {"count": 1, "uniqueCount": 1}}
32	2025-04-04 01:55:44.102462	2025-04-04 01:55:44.102462	24	stencil	{"views": {"count": 1, "uniqueCount": 1}}
28	2025-04-04 01:12:47.026353	2025-04-04 01:12:47.026353	15	stencil	{"views": {"count": 2, "uniqueCount": 1}}
27	2025-04-04 01:12:45.010951	2025-04-04 01:12:45.010951	16	stencil	{"views": {"count": 6, "uniqueCount": 1}}
26	2025-04-04 01:12:44.363603	2025-04-04 01:12:44.363603	18	stencil	{"views": {"count": 5, "uniqueCount": 1}}
23	2025-04-04 01:12:27.853537	2025-04-04 01:12:27.853537	9	stencil	{"views": {"count": 7, "uniqueCount": 1}}
20	2025-04-02 02:55:52.744659	2025-04-02 02:55:52.744659	26	stencil	{"views": {"count": 7, "uniqueCount": 1}, "reactions": {"like": {"count": 0, "userIds": []}}, "engagementRate": 0.00000000000000000000}
\.


--
-- Data for Name: content_metrics_viewers; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.content_metrics_viewers (id, metrics_id, viewer_key, created_at) FROM stdin;
17	17	viewer_35	2025-04-02 02:36:13.448123
18	18	viewer_35	2025-04-02 02:55:49.714845
19	19	viewer_35	2025-04-02 02:55:51.780022
20	20	viewer_35	2025-04-02 02:55:52.775056
21	21	viewer_35	2025-04-02 02:55:55.260926
22	22	viewer_35	2025-04-02 02:59:40.661411
23	23	viewer_35	2025-04-04 01:12:27.903164
24	24	viewer_35	2025-04-04 01:12:32.238995
25	25	viewer_35	2025-04-04 01:12:39.999639
26	26	viewer_35	2025-04-04 01:12:44.390769
27	27	viewer_35	2025-04-04 01:12:45.041278
28	28	viewer_35	2025-04-04 01:12:47.05311
29	29	viewer_35	2025-04-04 01:12:47.65117
30	30	viewer_35	2025-04-04 01:12:48.175936
31	31	viewer_35	2025-04-04 01:12:48.730191
32	32	viewer_35	2025-04-04 01:55:44.146199
33	33	viewer_35	2025-04-04 01:55:44.675968
34	34	viewer_35	2025-04-04 01:55:45.223525
35	35	viewer_35	2025-04-04 01:55:46.165864
36	36	viewer_35	2025-04-04 01:55:46.740465
37	37	viewer_35	2025-04-04 02:09:03.747484
\.


--
-- Data for Name: query-result-cache; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public."query-result-cache" (id, identifier, "time", duration, query, result) FROM stdin;
8	content_metrics_batch_stencil_18_16_15_14_13_12_11_10_9	1743985445565	60000	SELECT "ContentMetrics"."id" AS "ContentMetrics_id", "ContentMetrics"."created_at" AS "ContentMetrics_created_at", "ContentMetrics"."updated_at" AS "ContentMetrics_updated_at", "ContentMetrics"."content_id" AS "ContentMetrics_content_id", "ContentMetrics"."content_type" AS "ContentMetrics_content_type", "ContentMetrics"."metrics" AS "ContentMetrics_metrics" FROM "content_metrics" "ContentMetrics" WHERE (("ContentMetrics"."content_id" = $1 AND "ContentMetrics"."content_type" = $2) OR ("ContentMetrics"."content_id" = $3 AND "ContentMetrics"."content_type" = $4) OR ("ContentMetrics"."content_id" = $5 AND "ContentMetrics"."content_type" = $6) OR ("ContentMetrics"."content_id" = $7 AND "ContentMetrics"."content_type" = $8) OR ("ContentMetrics"."content_id" = $9 AND "ContentMetrics"."content_type" = $10) OR ("ContentMetrics"."content_id" = $11 AND "ContentMetrics"."content_type" = $12) OR ("ContentMetrics"."content_id" = $13 AND "ContentMetrics"."content_type" = $14) OR ("ContentMetrics"."content_id" = $15 AND "ContentMetrics"."content_type" = $16) OR ("ContentMetrics"."content_id" = $17 AND "ContentMetrics"."content_type" = $18)) -- PARAMETERS: [18,"stencil",16,"stencil",15,"stencil",14,"stencil",13,"stencil",12,"stencil",11,"stencil",10,"stencil",9,"stencil"]	[{"ContentMetrics_id":22,"ContentMetrics_created_at":"2025-04-02T05:59:40.623Z","ContentMetrics_updated_at":"2025-04-02T05:59:40.623Z","ContentMetrics_content_id":10,"ContentMetrics_content_type":"stencil","ContentMetrics_metrics":{"views":{"count":8,"uniqueCount":1},"reactions":{"like":{"count":1,"userIds":[35]}},"engagementRate":100}},{"ContentMetrics_id":37,"ContentMetrics_created_at":"2025-04-04T05:09:03.695Z","ContentMetrics_updated_at":"2025-04-04T05:09:03.695Z","ContentMetrics_content_id":11,"ContentMetrics_content_type":"stencil","ContentMetrics_metrics":{"views":{"count":4,"uniqueCount":1}}},{"ContentMetrics_id":31,"ContentMetrics_created_at":"2025-04-04T04:12:48.704Z","ContentMetrics_updated_at":"2025-04-04T04:12:48.704Z","ContentMetrics_content_id":12,"ContentMetrics_content_type":"stencil","ContentMetrics_metrics":{"views":{"count":2,"uniqueCount":1},"reactions":{"like":{"count":1,"userIds":[35]}},"engagementRate":100}},{"ContentMetrics_id":29,"ContentMetrics_created_at":"2025-04-04T04:12:47.614Z","ContentMetrics_updated_at":"2025-04-04T04:12:47.614Z","ContentMetrics_content_id":14,"ContentMetrics_content_type":"stencil","ContentMetrics_metrics":{"views":{"count":1,"uniqueCount":1}}},{"ContentMetrics_id":30,"ContentMetrics_created_at":"2025-04-04T04:12:48.149Z","ContentMetrics_updated_at":"2025-04-04T04:12:48.149Z","ContentMetrics_content_id":13,"ContentMetrics_content_type":"stencil","ContentMetrics_metrics":{"views":{"count":1,"uniqueCount":1}}},{"ContentMetrics_id":28,"ContentMetrics_created_at":"2025-04-04T04:12:47.026Z","ContentMetrics_updated_at":"2025-04-04T04:12:47.026Z","ContentMetrics_content_id":15,"ContentMetrics_content_type":"stencil","ContentMetrics_metrics":{"views":{"count":2,"uniqueCount":1}}},{"ContentMetrics_id":27,"ContentMetrics_created_at":"2025-04-04T04:12:45.010Z","ContentMetrics_updated_at":"2025-04-04T04:12:45.010Z","ContentMetrics_content_id":16,"ContentMetrics_content_type":"stencil","ContentMetrics_metrics":{"views":{"count":6,"uniqueCount":1}}},{"ContentMetrics_id":26,"ContentMetrics_created_at":"2025-04-04T04:12:44.363Z","ContentMetrics_updated_at":"2025-04-04T04:12:44.363Z","ContentMetrics_content_id":18,"ContentMetrics_content_type":"stencil","ContentMetrics_metrics":{"views":{"count":5,"uniqueCount":1}}},{"ContentMetrics_id":23,"ContentMetrics_created_at":"2025-04-04T04:12:27.853Z","ContentMetrics_updated_at":"2025-04-04T04:12:27.853Z","ContentMetrics_content_id":9,"ContentMetrics_content_type":"stencil","ContentMetrics_metrics":{"views":{"count":7,"uniqueCount":1}}}]
9	content_metrics_batch_stencil_18_16_15_14_13_12_11_10_9	1743985445565	60000	SELECT "ContentMetrics"."id" AS "ContentMetrics_id", "ContentMetrics"."created_at" AS "ContentMetrics_created_at", "ContentMetrics"."updated_at" AS "ContentMetrics_updated_at", "ContentMetrics"."content_id" AS "ContentMetrics_content_id", "ContentMetrics"."content_type" AS "ContentMetrics_content_type", "ContentMetrics"."metrics" AS "ContentMetrics_metrics" FROM "content_metrics" "ContentMetrics" WHERE (("ContentMetrics"."content_id" = $1 AND "ContentMetrics"."content_type" = $2) OR ("ContentMetrics"."content_id" = $3 AND "ContentMetrics"."content_type" = $4) OR ("ContentMetrics"."content_id" = $5 AND "ContentMetrics"."content_type" = $6) OR ("ContentMetrics"."content_id" = $7 AND "ContentMetrics"."content_type" = $8) OR ("ContentMetrics"."content_id" = $9 AND "ContentMetrics"."content_type" = $10) OR ("ContentMetrics"."content_id" = $11 AND "ContentMetrics"."content_type" = $12) OR ("ContentMetrics"."content_id" = $13 AND "ContentMetrics"."content_type" = $14) OR ("ContentMetrics"."content_id" = $15 AND "ContentMetrics"."content_type" = $16) OR ("ContentMetrics"."content_id" = $17 AND "ContentMetrics"."content_type" = $18)) -- PARAMETERS: [18,"stencil",16,"stencil",15,"stencil",14,"stencil",13,"stencil",12,"stencil",11,"stencil",10,"stencil",9,"stencil"]	[{"ContentMetrics_id":22,"ContentMetrics_created_at":"2025-04-02T05:59:40.623Z","ContentMetrics_updated_at":"2025-04-02T05:59:40.623Z","ContentMetrics_content_id":10,"ContentMetrics_content_type":"stencil","ContentMetrics_metrics":{"views":{"count":8,"uniqueCount":1},"reactions":{"like":{"count":1,"userIds":[35]}},"engagementRate":100}},{"ContentMetrics_id":37,"ContentMetrics_created_at":"2025-04-04T05:09:03.695Z","ContentMetrics_updated_at":"2025-04-04T05:09:03.695Z","ContentMetrics_content_id":11,"ContentMetrics_content_type":"stencil","ContentMetrics_metrics":{"views":{"count":4,"uniqueCount":1}}},{"ContentMetrics_id":31,"ContentMetrics_created_at":"2025-04-04T04:12:48.704Z","ContentMetrics_updated_at":"2025-04-04T04:12:48.704Z","ContentMetrics_content_id":12,"ContentMetrics_content_type":"stencil","ContentMetrics_metrics":{"views":{"count":2,"uniqueCount":1},"reactions":{"like":{"count":1,"userIds":[35]}},"engagementRate":100}},{"ContentMetrics_id":29,"ContentMetrics_created_at":"2025-04-04T04:12:47.614Z","ContentMetrics_updated_at":"2025-04-04T04:12:47.614Z","ContentMetrics_content_id":14,"ContentMetrics_content_type":"stencil","ContentMetrics_metrics":{"views":{"count":1,"uniqueCount":1}}},{"ContentMetrics_id":30,"ContentMetrics_created_at":"2025-04-04T04:12:48.149Z","ContentMetrics_updated_at":"2025-04-04T04:12:48.149Z","ContentMetrics_content_id":13,"ContentMetrics_content_type":"stencil","ContentMetrics_metrics":{"views":{"count":1,"uniqueCount":1}}},{"ContentMetrics_id":28,"ContentMetrics_created_at":"2025-04-04T04:12:47.026Z","ContentMetrics_updated_at":"2025-04-04T04:12:47.026Z","ContentMetrics_content_id":15,"ContentMetrics_content_type":"stencil","ContentMetrics_metrics":{"views":{"count":2,"uniqueCount":1}}},{"ContentMetrics_id":27,"ContentMetrics_created_at":"2025-04-04T04:12:45.010Z","ContentMetrics_updated_at":"2025-04-04T04:12:45.010Z","ContentMetrics_content_id":16,"ContentMetrics_content_type":"stencil","ContentMetrics_metrics":{"views":{"count":6,"uniqueCount":1}}},{"ContentMetrics_id":26,"ContentMetrics_created_at":"2025-04-04T04:12:44.363Z","ContentMetrics_updated_at":"2025-04-04T04:12:44.363Z","ContentMetrics_content_id":18,"ContentMetrics_content_type":"stencil","ContentMetrics_metrics":{"views":{"count":5,"uniqueCount":1}}},{"ContentMetrics_id":23,"ContentMetrics_created_at":"2025-04-04T04:12:27.853Z","ContentMetrics_updated_at":"2025-04-04T04:12:27.853Z","ContentMetrics_content_id":9,"ContentMetrics_content_type":"stencil","ContentMetrics_metrics":{"views":{"count":7,"uniqueCount":1}}}]
6	content_metrics_batch_work_4_1	1743983010451	60000	SELECT "ContentMetrics"."id" AS "ContentMetrics_id", "ContentMetrics"."created_at" AS "ContentMetrics_created_at", "ContentMetrics"."updated_at" AS "ContentMetrics_updated_at", "ContentMetrics"."content_id" AS "ContentMetrics_content_id", "ContentMetrics"."content_type" AS "ContentMetrics_content_type", "ContentMetrics"."metrics" AS "ContentMetrics_metrics" FROM "content_metrics" "ContentMetrics" WHERE (("ContentMetrics"."content_id" = $1 AND "ContentMetrics"."content_type" = $2) OR ("ContentMetrics"."content_id" = $3 AND "ContentMetrics"."content_type" = $4)) -- PARAMETERS: [4,"work",1,"work"]	[{"ContentMetrics_id":24,"ContentMetrics_created_at":"2025-04-04T04:12:32.211Z","ContentMetrics_updated_at":"2025-04-04T04:12:32.211Z","ContentMetrics_content_id":4,"ContentMetrics_content_type":"work","ContentMetrics_metrics":{"views":{"count":20,"uniqueCount":1}}},{"ContentMetrics_id":25,"ContentMetrics_created_at":"2025-04-04T04:12:39.963Z","ContentMetrics_updated_at":"2025-04-04T04:12:39.963Z","ContentMetrics_content_id":1,"ContentMetrics_content_type":"work","ContentMetrics_metrics":{"views":{"count":8,"uniqueCount":1}}}]
7	content_metrics_batch_stencil_33_28_27_26_25	1743983011094	60000	SELECT "ContentMetrics"."id" AS "ContentMetrics_id", "ContentMetrics"."created_at" AS "ContentMetrics_created_at", "ContentMetrics"."updated_at" AS "ContentMetrics_updated_at", "ContentMetrics"."content_id" AS "ContentMetrics_content_id", "ContentMetrics"."content_type" AS "ContentMetrics_content_type", "ContentMetrics"."metrics" AS "ContentMetrics_metrics" FROM "content_metrics" "ContentMetrics" WHERE (("ContentMetrics"."content_id" = $1 AND "ContentMetrics"."content_type" = $2) OR ("ContentMetrics"."content_id" = $3 AND "ContentMetrics"."content_type" = $4) OR ("ContentMetrics"."content_id" = $5 AND "ContentMetrics"."content_type" = $6) OR ("ContentMetrics"."content_id" = $7 AND "ContentMetrics"."content_type" = $8) OR ("ContentMetrics"."content_id" = $9 AND "ContentMetrics"."content_type" = $10)) -- PARAMETERS: [33,"stencil",28,"stencil",27,"stencil",26,"stencil",25,"stencil"]	[{"ContentMetrics_id":19,"ContentMetrics_created_at":"2025-04-02T05:55:51.741Z","ContentMetrics_updated_at":"2025-04-02T05:55:51.741Z","ContentMetrics_content_id":27,"ContentMetrics_content_type":"stencil","ContentMetrics_metrics":{"views":{"count":4,"uniqueCount":1}}},{"ContentMetrics_id":18,"ContentMetrics_created_at":"2025-04-02T05:55:49.673Z","ContentMetrics_updated_at":"2025-04-02T05:55:49.673Z","ContentMetrics_content_id":28,"ContentMetrics_content_type":"stencil","ContentMetrics_metrics":{"views":{"count":11,"uniqueCount":1},"reactions":{"like":{"count":1,"userIds":[35]}},"engagementRate":100}},{"ContentMetrics_id":17,"ContentMetrics_created_at":"2025-04-02T05:36:13.378Z","ContentMetrics_updated_at":"2025-04-02T05:36:13.378Z","ContentMetrics_content_id":33,"ContentMetrics_content_type":"stencil","ContentMetrics_metrics":{"views":{"count":25,"uniqueCount":1},"reactions":{"like":{"count":1,"userIds":[35]}},"engagementRate":12.5}},{"ContentMetrics_id":21,"ContentMetrics_created_at":"2025-04-02T05:55:55.234Z","ContentMetrics_updated_at":"2025-04-02T05:55:55.234Z","ContentMetrics_content_id":25,"ContentMetrics_content_type":"stencil","ContentMetrics_metrics":{"views":{"count":8,"uniqueCount":1}}},{"ContentMetrics_id":20,"ContentMetrics_created_at":"2025-04-02T05:55:52.744Z","ContentMetrics_updated_at":"2025-04-02T05:55:52.744Z","ContentMetrics_content_id":26,"ContentMetrics_content_type":"stencil","ContentMetrics_metrics":{"views":{"count":7,"uniqueCount":1},"reactions":{"like":{"count":0,"userIds":[]}},"engagementRate":0}}]
11	content_metrics_batch_stencil_33_28_27_26_25_24_23_22_21_20_18_16_15_14_13_12_11_10_9	1743733378941	60000	SELECT "ContentMetrics"."id" AS "ContentMetrics_id", "ContentMetrics"."created_at" AS "ContentMetrics_created_at", "ContentMetrics"."updated_at" AS "ContentMetrics_updated_at", "ContentMetrics"."content_id" AS "ContentMetrics_content_id", "ContentMetrics"."content_type" AS "ContentMetrics_content_type", "ContentMetrics"."metrics" AS "ContentMetrics_metrics" FROM "content_metrics" "ContentMetrics" WHERE (("ContentMetrics"."content_id" = $1 AND "ContentMetrics"."content_type" = $2) OR ("ContentMetrics"."content_id" = $3 AND "ContentMetrics"."content_type" = $4) OR ("ContentMetrics"."content_id" = $5 AND "ContentMetrics"."content_type" = $6) OR ("ContentMetrics"."content_id" = $7 AND "ContentMetrics"."content_type" = $8) OR ("ContentMetrics"."content_id" = $9 AND "ContentMetrics"."content_type" = $10) OR ("ContentMetrics"."content_id" = $11 AND "ContentMetrics"."content_type" = $12) OR ("ContentMetrics"."content_id" = $13 AND "ContentMetrics"."content_type" = $14) OR ("ContentMetrics"."content_id" = $15 AND "ContentMetrics"."content_type" = $16) OR ("ContentMetrics"."content_id" = $17 AND "ContentMetrics"."content_type" = $18) OR ("ContentMetrics"."content_id" = $19 AND "ContentMetrics"."content_type" = $20) OR ("ContentMetrics"."content_id" = $21 AND "ContentMetrics"."content_type" = $22) OR ("ContentMetrics"."content_id" = $23 AND "ContentMetrics"."content_type" = $24) OR ("ContentMetrics"."content_id" = $25 AND "ContentMetrics"."content_type" = $26) OR ("ContentMetrics"."content_id" = $27 AND "ContentMetrics"."content_type" = $28) OR ("ContentMetrics"."content_id" = $29 AND "ContentMetrics"."content_type" = $30) OR ("ContentMetrics"."content_id" = $31 AND "ContentMetrics"."content_type" = $32) OR ("ContentMetrics"."content_id" = $33 AND "ContentMetrics"."content_type" = $34) OR ("ContentMetrics"."content_id" = $35 AND "ContentMetrics"."content_type" = $36) OR ("ContentMetrics"."content_id" = $37 AND "ContentMetrics"."content_type" = $38)) -- PARAMETERS: [33,"stencil",28,"stencil",27,"stencil",26,"stencil",25,"stencil",24,"stencil",23,"stencil",22,"stencil",21,"stencil",20,"stencil",18,"stencil",16,"stencil",15,"stencil",14,"stencil",13,"stencil",12,"stencil",11,"stencil",10,"stencil",9,"stencil"]	[{"ContentMetrics_id":33,"ContentMetrics_created_at":"2025-04-04T04:55:44.651Z","ContentMetrics_updated_at":"2025-04-04T04:55:44.651Z","ContentMetrics_content_id":23,"ContentMetrics_content_type":"stencil","ContentMetrics_metrics":{"views":{"count":1,"uniqueCount":1}}},{"ContentMetrics_id":31,"ContentMetrics_created_at":"2025-04-04T04:12:48.704Z","ContentMetrics_updated_at":"2025-04-04T04:12:48.704Z","ContentMetrics_content_id":12,"ContentMetrics_content_type":"stencil","ContentMetrics_metrics":{"views":{"count":1,"uniqueCount":1},"reactions":{"like":{"count":1,"userIds":[35]}},"engagementRate":100}},{"ContentMetrics_id":34,"ContentMetrics_created_at":"2025-04-04T04:55:45.190Z","ContentMetrics_updated_at":"2025-04-04T04:55:45.190Z","ContentMetrics_content_id":22,"ContentMetrics_content_type":"stencil","ContentMetrics_metrics":{"views":{"count":1,"uniqueCount":1}}},{"ContentMetrics_id":21,"ContentMetrics_created_at":"2025-04-02T05:55:55.234Z","ContentMetrics_updated_at":"2025-04-02T05:55:55.234Z","ContentMetrics_content_id":25,"ContentMetrics_content_type":"stencil","ContentMetrics_metrics":{"views":{"count":5,"uniqueCount":1}}},{"ContentMetrics_id":35,"ContentMetrics_created_at":"2025-04-04T04:55:46.144Z","ContentMetrics_updated_at":"2025-04-04T04:55:46.144Z","ContentMetrics_content_id":21,"ContentMetrics_content_type":"stencil","ContentMetrics_metrics":{"views":{"count":1,"uniqueCount":1}}},{"ContentMetrics_id":36,"ContentMetrics_created_at":"2025-04-04T04:55:46.708Z","ContentMetrics_updated_at":"2025-04-04T04:55:46.708Z","ContentMetrics_content_id":20,"ContentMetrics_content_type":"stencil","ContentMetrics_metrics":{"views":{"count":1,"uniqueCount":1}}},{"ContentMetrics_id":26,"ContentMetrics_created_at":"2025-04-04T04:12:44.363Z","ContentMetrics_updated_at":"2025-04-04T04:12:44.363Z","ContentMetrics_content_id":18,"ContentMetrics_content_type":"stencil","ContentMetrics_metrics":{"views":{"count":2,"uniqueCount":1}}},{"ContentMetrics_id":27,"ContentMetrics_created_at":"2025-04-04T04:12:45.010Z","ContentMetrics_updated_at":"2025-04-04T04:12:45.010Z","ContentMetrics_content_id":16,"ContentMetrics_content_type":"stencil","ContentMetrics_metrics":{"views":{"count":3,"uniqueCount":1}}},{"ContentMetrics_id":20,"ContentMetrics_created_at":"2025-04-02T05:55:52.744Z","ContentMetrics_updated_at":"2025-04-02T05:55:52.744Z","ContentMetrics_content_id":26,"ContentMetrics_content_type":"stencil","ContentMetrics_metrics":{"views":{"count":6,"uniqueCount":1},"reactions":{"like":{"count":0,"userIds":[]}},"engagementRate":0}},{"ContentMetrics_id":28,"ContentMetrics_created_at":"2025-04-04T04:12:47.026Z","ContentMetrics_updated_at":"2025-04-04T04:12:47.026Z","ContentMetrics_content_id":15,"ContentMetrics_content_type":"stencil","ContentMetrics_metrics":{"views":{"count":1,"uniqueCount":1}}},{"ContentMetrics_id":29,"ContentMetrics_created_at":"2025-04-04T04:12:47.614Z","ContentMetrics_updated_at":"2025-04-04T04:12:47.614Z","ContentMetrics_content_id":14,"ContentMetrics_content_type":"stencil","ContentMetrics_metrics":{"views":{"count":1,"uniqueCount":1}}},{"ContentMetrics_id":30,"ContentMetrics_created_at":"2025-04-04T04:12:48.149Z","ContentMetrics_updated_at":"2025-04-04T04:12:48.149Z","ContentMetrics_content_id":13,"ContentMetrics_content_type":"stencil","ContentMetrics_metrics":{"views":{"count":1,"uniqueCount":1}}},{"ContentMetrics_id":22,"ContentMetrics_created_at":"2025-04-02T05:59:40.623Z","ContentMetrics_updated_at":"2025-04-02T05:59:40.623Z","ContentMetrics_content_id":10,"ContentMetrics_content_type":"stencil","ContentMetrics_metrics":{"views":{"count":6,"uniqueCount":1},"reactions":{"like":{"count":1,"userIds":[35]}},"engagementRate":100}},{"ContentMetrics_id":37,"ContentMetrics_created_at":"2025-04-04T05:09:03.695Z","ContentMetrics_updated_at":"2025-04-04T05:09:03.695Z","ContentMetrics_content_id":11,"ContentMetrics_content_type":"stencil","ContentMetrics_metrics":{"views":{"count":2,"uniqueCount":1}}},{"ContentMetrics_id":32,"ContentMetrics_created_at":"2025-04-04T04:55:44.102Z","ContentMetrics_updated_at":"2025-04-04T04:55:44.102Z","ContentMetrics_content_id":24,"ContentMetrics_content_type":"stencil","ContentMetrics_metrics":{"views":{"count":1,"uniqueCount":1}}},{"ContentMetrics_id":23,"ContentMetrics_created_at":"2025-04-04T04:12:27.853Z","ContentMetrics_updated_at":"2025-04-04T04:12:27.853Z","ContentMetrics_content_id":9,"ContentMetrics_content_type":"stencil","ContentMetrics_metrics":{"views":{"count":6,"uniqueCount":1}}},{"ContentMetrics_id":17,"ContentMetrics_created_at":"2025-04-02T05:36:13.378Z","ContentMetrics_updated_at":"2025-04-02T05:36:13.378Z","ContentMetrics_content_id":33,"ContentMetrics_content_type":"stencil","ContentMetrics_metrics":{"views":{"count":22,"uniqueCount":1},"reactions":{"like":{"count":1,"userIds":[35]}},"engagementRate":12.5}},{"ContentMetrics_id":19,"ContentMetrics_created_at":"2025-04-02T05:55:51.741Z","ContentMetrics_updated_at":"2025-04-02T05:55:51.741Z","ContentMetrics_content_id":27,"ContentMetrics_content_type":"stencil","ContentMetrics_metrics":{"views":{"count":3,"uniqueCount":1}}},{"ContentMetrics_id":18,"ContentMetrics_created_at":"2025-04-02T05:55:49.673Z","ContentMetrics_updated_at":"2025-04-02T05:55:49.673Z","ContentMetrics_content_id":28,"ContentMetrics_content_type":"stencil","ContentMetrics_metrics":{"views":{"count":9,"uniqueCount":1},"reactions":{"like":{"count":1,"userIds":[35]}},"engagementRate":100}}]
10	content_metrics_batch_stencil_18_16_15_14_13_12_11_10_9	1743985445565	60000	SELECT "ContentMetrics"."id" AS "ContentMetrics_id", "ContentMetrics"."created_at" AS "ContentMetrics_created_at", "ContentMetrics"."updated_at" AS "ContentMetrics_updated_at", "ContentMetrics"."content_id" AS "ContentMetrics_content_id", "ContentMetrics"."content_type" AS "ContentMetrics_content_type", "ContentMetrics"."metrics" AS "ContentMetrics_metrics" FROM "content_metrics" "ContentMetrics" WHERE (("ContentMetrics"."content_id" = $1 AND "ContentMetrics"."content_type" = $2) OR ("ContentMetrics"."content_id" = $3 AND "ContentMetrics"."content_type" = $4) OR ("ContentMetrics"."content_id" = $5 AND "ContentMetrics"."content_type" = $6) OR ("ContentMetrics"."content_id" = $7 AND "ContentMetrics"."content_type" = $8) OR ("ContentMetrics"."content_id" = $9 AND "ContentMetrics"."content_type" = $10) OR ("ContentMetrics"."content_id" = $11 AND "ContentMetrics"."content_type" = $12) OR ("ContentMetrics"."content_id" = $13 AND "ContentMetrics"."content_type" = $14) OR ("ContentMetrics"."content_id" = $15 AND "ContentMetrics"."content_type" = $16) OR ("ContentMetrics"."content_id" = $17 AND "ContentMetrics"."content_type" = $18)) -- PARAMETERS: [18,"stencil",16,"stencil",15,"stencil",14,"stencil",13,"stencil",12,"stencil",11,"stencil",10,"stencil",9,"stencil"]	[{"ContentMetrics_id":22,"ContentMetrics_created_at":"2025-04-02T05:59:40.623Z","ContentMetrics_updated_at":"2025-04-02T05:59:40.623Z","ContentMetrics_content_id":10,"ContentMetrics_content_type":"stencil","ContentMetrics_metrics":{"views":{"count":8,"uniqueCount":1},"reactions":{"like":{"count":1,"userIds":[35]}},"engagementRate":100}},{"ContentMetrics_id":37,"ContentMetrics_created_at":"2025-04-04T05:09:03.695Z","ContentMetrics_updated_at":"2025-04-04T05:09:03.695Z","ContentMetrics_content_id":11,"ContentMetrics_content_type":"stencil","ContentMetrics_metrics":{"views":{"count":4,"uniqueCount":1}}},{"ContentMetrics_id":31,"ContentMetrics_created_at":"2025-04-04T04:12:48.704Z","ContentMetrics_updated_at":"2025-04-04T04:12:48.704Z","ContentMetrics_content_id":12,"ContentMetrics_content_type":"stencil","ContentMetrics_metrics":{"views":{"count":2,"uniqueCount":1},"reactions":{"like":{"count":1,"userIds":[35]}},"engagementRate":100}},{"ContentMetrics_id":29,"ContentMetrics_created_at":"2025-04-04T04:12:47.614Z","ContentMetrics_updated_at":"2025-04-04T04:12:47.614Z","ContentMetrics_content_id":14,"ContentMetrics_content_type":"stencil","ContentMetrics_metrics":{"views":{"count":1,"uniqueCount":1}}},{"ContentMetrics_id":30,"ContentMetrics_created_at":"2025-04-04T04:12:48.149Z","ContentMetrics_updated_at":"2025-04-04T04:12:48.149Z","ContentMetrics_content_id":13,"ContentMetrics_content_type":"stencil","ContentMetrics_metrics":{"views":{"count":1,"uniqueCount":1}}},{"ContentMetrics_id":28,"ContentMetrics_created_at":"2025-04-04T04:12:47.026Z","ContentMetrics_updated_at":"2025-04-04T04:12:47.026Z","ContentMetrics_content_id":15,"ContentMetrics_content_type":"stencil","ContentMetrics_metrics":{"views":{"count":2,"uniqueCount":1}}},{"ContentMetrics_id":27,"ContentMetrics_created_at":"2025-04-04T04:12:45.010Z","ContentMetrics_updated_at":"2025-04-04T04:12:45.010Z","ContentMetrics_content_id":16,"ContentMetrics_content_type":"stencil","ContentMetrics_metrics":{"views":{"count":6,"uniqueCount":1}}},{"ContentMetrics_id":26,"ContentMetrics_created_at":"2025-04-04T04:12:44.363Z","ContentMetrics_updated_at":"2025-04-04T04:12:44.363Z","ContentMetrics_content_id":18,"ContentMetrics_content_type":"stencil","ContentMetrics_metrics":{"views":{"count":5,"uniqueCount":1}}},{"ContentMetrics_id":23,"ContentMetrics_created_at":"2025-04-04T04:12:27.853Z","ContentMetrics_updated_at":"2025-04-04T04:12:27.853Z","ContentMetrics_content_id":9,"ContentMetrics_content_type":"stencil","ContentMetrics_metrics":{"views":{"count":7,"uniqueCount":1}}}]
\.


--
-- Name: artist_metrics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.artist_metrics_id_seq', 1, true);


--
-- Name: artist_metrics_viewers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.artist_metrics_viewers_id_seq', 1, true);


--
-- Name: content_metrics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.content_metrics_id_seq', 37, true);


--
-- Name: content_metrics_viewers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.content_metrics_viewers_id_seq', 37, true);


--
-- Name: query-result-cache_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public."query-result-cache_id_seq"', 11, true);


--
-- Name: artist_metrics PK_078efd97d1462740448f8b7ef22; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.artist_metrics
    ADD CONSTRAINT "PK_078efd97d1462740448f8b7ef22" PRIMARY KEY (id);


--
-- Name: content_metrics_viewers PK_0fc8d51af82bd3a8c78d3af155e; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.content_metrics_viewers
    ADD CONSTRAINT "PK_0fc8d51af82bd3a8c78d3af155e" PRIMARY KEY (id);


--
-- Name: artist_metrics_viewers PK_66335507e24927bf9ef744cb6b4; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.artist_metrics_viewers
    ADD CONSTRAINT "PK_66335507e24927bf9ef744cb6b4" PRIMARY KEY (id);


--
-- Name: query-result-cache PK_6a98f758d8bfd010e7e10ffd3d3; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."query-result-cache"
    ADD CONSTRAINT "PK_6a98f758d8bfd010e7e10ffd3d3" PRIMARY KEY (id);


--
-- Name: content_metrics PK_ae4a61c74a5142e2ec754147141; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.content_metrics
    ADD CONSTRAINT "PK_ae4a61c74a5142e2ec754147141" PRIMARY KEY (id);


--
-- Name: IDX_1d457c048def92e36e7368b10f; Type: INDEX; Schema: public; Owner: root
--

CREATE UNIQUE INDEX "IDX_1d457c048def92e36e7368b10f" ON public.artist_metrics_viewers USING btree (metrics_id, viewer_key);


--
-- Name: IDX_45549bf4dbca82611ce8c94804; Type: INDEX; Schema: public; Owner: root
--

CREATE UNIQUE INDEX "IDX_45549bf4dbca82611ce8c94804" ON public.content_metrics USING btree (content_id, content_type);


--
-- Name: IDX_6acfaaaf9428a46acea202825b; Type: INDEX; Schema: public; Owner: root
--

CREATE UNIQUE INDEX "IDX_6acfaaaf9428a46acea202825b" ON public.content_metrics_viewers USING btree (metrics_id, viewer_key);


--
-- Name: IDX_f96f80047970cd4d6cb8e9ddb0; Type: INDEX; Schema: public; Owner: root
--

CREATE UNIQUE INDEX "IDX_f96f80047970cd4d6cb8e9ddb0" ON public.artist_metrics USING btree (artist_id);


--
-- Name: content_metrics_viewers FK_0e40fda1c79da2bb9edd3e818b5; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.content_metrics_viewers
    ADD CONSTRAINT "FK_0e40fda1c79da2bb9edd3e818b5" FOREIGN KEY (metrics_id) REFERENCES public.content_metrics(id) ON DELETE CASCADE;


--
-- Name: artist_metrics_viewers FK_b7b49edbf1b02ccbee4d82868df; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.artist_metrics_viewers
    ADD CONSTRAINT "FK_b7b49edbf1b02ccbee4d82868df" FOREIGN KEY (metrics_id) REFERENCES public.artist_metrics(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

